#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 19:03:36 2024

@author: asmat
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json
import ollama
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow all origins (useful for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)
# Define the input model
class TextRequest(BaseModel):
    text: str

@app.post("/summarize_text")
async def summarize_text(text_request: TextRequest):
    text = text_request.text
    print(" YA aa raha hay",text)
    
    # Define the narrative generation prompt
    narrative_prompt = f"""
    You are a highly skilled summarization expert with deep knowledge in extracting key ideas from complex texts. Your task is to carefully read and analyze the provided content, identifying all salient features, important arguments, and supporting details. Your summary should be:

    Comprehensive – capture the key themes and essential points without missing important nuances.
    Clear and Coherent – ensure the summary is structured logically, flows smoothly, and remains easy to understand.
    Insightful – highlight the most impactful insights, draw attention to major findings or conclusions, and explain the significance of the information where appropriate.
    The provided text is as follows:
    {text}
    
    Based on this text, generate a well-organized and insightful summary that reflects all key ideas and themes while maintaining brevity and clarity.
    
    Answer:
        """
    
    # Use LLM to generate a summary from the input text
    try:
        result = ollama.chat(
            model='llama3.1:8b-instruct-fp16',
            messages=[{"role": 'user', 'content': narrative_prompt}],
            options={'temperature': 0.2, "num_ctx": 32768, "max_tokens": 32768},
            stream=False
        )
        summary = result['message']['content'].strip()
        print("\n ya jaa rah hay",summary)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred while generating the summary: {str(e)}")
    
    # Return the summary as plain text
    # Return the summary as a JSON object
    return json.dumps({"summary": summary})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
