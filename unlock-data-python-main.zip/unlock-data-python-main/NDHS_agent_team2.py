#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 17:17:00 2024

@author: asmat
"""

#!/usr/bin/env python3


from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
import os

# load_dotenv()  # Load environment variables from .env file

# api_key = os.getenv("OPENAI_API_KEY")

# llm_openai = ChatOpenAI(model="gpt-4-1106-preview")

#################################################################################################
# we developed create_text2sql_agent
#################################################################################################
from pydantic import BaseModel
import pymysql
import pandas as pd
from sqlalchemy import create_engine
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
from langchain import LLMChain
from langchain_community.utilities.sql_database import SQLDatabase

# Initialize the language model
llm_codestral = ChatOllama(model="codestral", temperature=0, host="http://localhost:11434")

# Set environment variables if needed
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# Define the prompt template for clarification
clarification_template = """

You are a clarification query expert. Your task is to rephrase the given natural language query into a single, clear sentence that aligns precisely with the database schema and accurately represents the relevant indicator information.

### Instructions:

1. **Correct Spelling and Grammar**: Address any spelling mistakes or grammatical errors in the original query.

2. **Use Exact Schema Terms**:
   - **Tables and Columns**: Ensure that your rephrased query uses the exact names of tables, columns, and row values from the database schema. Replace similar but incorrect terms with the precise schema terms.
   - **Indicators**: Replace general terms with the specific indicator names from the available indicators list.

3. **Match Keywords with Schema Elements**:
   - **Table Names**: Verify that table names are correctly used. Replace closely resembling terms with exact table names.
   - **Column Names**: Ensure column names are accurately reflected. Replace similar terms with the correct column names.
   - **Row Values**: Match any values in the rows with those mentioned in the query. Replace any non-matching values with the closest available match.

4. **Use Indicator Information**: Reference the indicators provided and ensure the query uses the exact indicator names. Replace general terms with specific indicators like **Total Fertility Rate**, **Current use of any method of family planning**, etc.

5. **Replace Incorrect Terms**: If a term doesn’t match any schema elements, use the most appropriate term based on the schema and indicator information. For instance:
   - Replace "infinite mortality rate" with "Infant mortality" or "Under-five mortality."
   - Replace "urban valus" with "Urban" or "Rural."
   - Replace "golas" with "Goals."

6. **Clarify Intent**: Clearly articulate the intent of the query to ensure that the user’s objective is precise and understandable.

7. **Simplify Language**: Use straightforward language to avoid confusion. Eliminate jargon or complex terminology where possible.

8. **Include Relevant Details**: Add any context or details that might be missing in the original query. Ensure all important aspects are covered.

9. **Avoid Redundancy**: Remove redundant or unnecessary information. Focus on the core message.

### Example Transformation:

**Original Query**: "What is the recent data on mental health symptoms in men?"

**Rephrased Query**: "What is the recent data on `Men aged 15-49 with anxiety symptoms` and `Men aged 15-49 with depression symptoms`?"

**Original Query**: "Show me the stats for children who are underweight in Pokhara."

**Rephrased Query**: "Show me the `Underweight` statistics for children under age five in `Pokhara`."

---

### Database Schema

1. **Table: `countries`**
   - **Purpose**: Stores information about countries.
   - **Columns**:
     - `country_id`: Integer, Primary Key, Auto-increment.
     - `country`: Name of the country, stored as a variable-length string.

2. **Table: `provinces`**
   - **Purpose**: Stores information about provinces within countries.
   - **Columns**:
     - `province_id`: Integer, Primary Key, Auto-increment.
     - `province`: Name of the province, stored as a variable-length string.
     - `country_id`: Foreign Key referencing `countries.country_id`, linking provinces to countries.

3. **Table: `survey_source`**
   - **Purpose**: Contains the sources from which survey data is collected.
   - **Columns**:
     - `survey_source_id`: Integer, Primary Key, Auto-increment.
     - `survey_source`: Name of the survey source, stored as a variable-length string.

4. **Table: `sections`**
   - **Purpose**: Contains different sections or categories of indicators.
   - **Columns**:
     - `section_id`: Integer, Primary Key, Auto-increment.
     - `section`: Name or description of the section, stored as a variable-length string.

5. **Table: `indicators`**
   - **Purpose**: Contains various health or demographic indicators.
   - **Columns**:
     - `indicator_id`: Integer, Primary Key, Auto-increment.
     - `indicator`: Name or type of the indicator, stored as a variable-length string.
     - `section_id`: Foreign Key referencing `sections.section_id`, linking indicators to sections.
     - `survey_source_id`: Foreign Key referencing `survey_source.survey_source_id`, linking indicators to their source.
     - `indicator_definition`: Detailed description or definition of the indicator, stored as text.

6. **Table: `lookup_groups`**
   - **Purpose**: Contains different groups for lookup values, such as ethnic groups, residence types, etc.
   - **Columns**:
     - `lookup_group_id`: Integer, Primary Key, Auto-increment.
     - `lookup_group`: Name of the lookup group, stored as a variable-length string.

7. **Table: `lookups`**
   - **Purpose**: Contains specific lookup values within each lookup group.
   - **Columns**:
     - `id`: Integer, Primary Key, Auto-increment.
     - `lookup_group_id`: Foreign Key referencing `lookup_groups.lookup_group_id`, linking lookups to lookup groups.
     - `lookup_id`: Integer, unique within each lookup group.
     - `lookup`: Specific value in the lookup group, stored as a variable-length string.

8. **Table: `indicators_data`**
   - **Purpose**: Contains the actual data for various indicators, associated with provinces, lookup groups, and specific lookups.
   - **Columns**:
     - `id`: Integer, Primary Key, Auto-increment.
     - `indicator_id`: Foreign Key referencing `indicators.indicator_id`, linking data to specific indicators.
     - `province_id`: Foreign Key referencing `provinces.province_id`, linking data to specific provinces.
     - `lookup_group_id`: Foreign Key referencing `lookup_groups.lookup_group_id`, linking data to specific lookup groups.
     - `lookup_id`: Foreign Key referencing `lookups.id`, linking data to specific lookup values.
     - `indicator_data`: Numeric data for the indicator, stored as a double precision floating-point number.
     - `survey_source_id`: Foreign Key referencing `survey_source.survey_source_id`, linking data to the survey source.
     - `country_id`: Foreign Key referencing `countries.country_id`, linking data to the country.
     - `year`: Year of the data, stored as an integer.

### Indicator Information

- **Total Fertility Rate** (number of children per woman)
- **Median Age at First Birth** (women aged 25-49, in years)
- **Pregnancy Among Women Aged 15-19** (%)
- **Family Planning** (for married women aged 15-49):
  - Current use of any method of family planning (%)
  - Current use of a modern method of family planning (%)
  - Demand satisfied by modern methods of family planning (%)
  - Unmet need for family planning
- **Infant and Child Mortality** (per 1,000 live births):
  - Infant mortality
  - Under-five mortality
- **Maternal and Newborn Health Care**:
  - Antenatal care (ANC) from a skilled provider
  - Births delivered in a health facility (%)
  - Births assisted by a skilled provider (%)
- **Child Health** (children aged 12-23 months):
  - Fully vaccinated against all basic antigens (%)
  - Fully vaccinated according to the national schedule (%)
- **Nutritional Status** (children under age five):
  - Stunted (%)
  - Wasted (%)
  - Underweight (%)
- **Dietary Diversity**:
  - Children aged 6-23 months living with their mother fed a minimum acceptable diet (%)
  - Women aged 15-49 who achieved minimum dietary diversity (%)
- **Household Water, Sanitation, and Hygiene**:
  - Access to basic drinking water service (%)
  - Access to basic sanitation service (%)
- **Financial Inclusion**:
  - Women aged 15-49 with a bank account or used mobile phone for financial transactions in the last 12 months (%)
  - Men aged 15-49 with a bank account or used mobile phone for financial transactions in the last 12 months (%)
- **Household Decision-Making**:
  - Married women aged 15-49 participating in household decisions (%)
- **Violence Against Women**:
  - Physical violence since age 15 (%)
  - Experienced violence by a husband/intimate partner in the last 12 months (%)
- **Awareness of COVID-19**:
  - Women aged 15-49 who have heard of COVID-19 (%)
  - Men aged 15-49 who have heard of COVID-19 (%)
- **Hypertension**:
  - Women aged 15-49 with hypertension (%)
  - Men aged 15-49 with hypertension (%)
- **Disability**:
  - Women aged 15+ with significant difficulty in at least one domain (%)
  - Men aged 15+ with significant difficulty in at least one domain (%)
- **Mental Health**:
  - Women aged 15-49 with anxiety symptoms (%)
  - Men aged 15-49 with anxiety symptoms (%)
  - Women aged 15-49 with depression symptoms (%)
  - Men aged 15-49 with depression symptoms (%)

---

**Original Query:**

{query}

**Rephrased Query:**

Based on the provided database schema for tables and columns along with the indicator information, rephrase the query as a single, clear sentence.

"""

clarification_prompt_template = PromptTemplate(
    input_variables=["query", "context"],
    template=clarification_template
)

# Define the prompt template for extracting intent and entities
intent_template = """

As an expert in intent detection and entity recognition, your task is to identify the intent and extract relevant entities from the given natural language query using the provided database schema. The intent will always be `"SELECT"`. Your job is to extract and categorize the entities as specified below:

- **Columns**: Identify specific columns matching the database schema that need to be used for the SQL query.
- **Tables**: Identify tables matching the database schema that need to be referenced.
- **Joins**: Identify the types of joins to be used (e.g., `INNER JOIN`, `LEFT OUTER JOIN`).
- **Filters**: Identify conditions or filters to be applied.
- **Aggregations**: Identify any aggregate functions to be used to summarize data (if applicable, e.g., `SUM`, `COUNT`).
- **Group By**: Identify columns to be used for grouping results (if applicable).
- **Order By**: Identify columns to be used for sorting results (if applicable).
- **Aliases**: Identify any aliases for tables or columns used in the query (if applicable).
- **Case Statements**: Identify any CASE statements used for conditional logic (if applicable).
- **Concatenation**: Identify any string concatenations used in the query (if applicable).
- **Subqueries**: Identify any subqueries used (if applicable).
- **Indicators**: Identify specific indicators mayching with the indicator information below.

### Context

The 2022 Nepal Demographic and Health Survey (2022 NDHS) is the sixth survey of its kind following the 1996 Nepal Family Health Survey and the 2001, 2006, 2011, and 2016 NDHS surveys. The 2022 NDHS incorporated a nationally representative sample of 14,280 households from 476 clusters. The principal objective of the NDHS is to provide current and reliable data on fertility and family planning behavior, child mortality, adult and maternal mortality, children’s nutritional status, the utilization of maternal and child health services, and knowledge of HIV/AIDS.

### Database Schema

#### Table: `countries`
- **Purpose**: Stores information about countries.
- **Columns**:
    - `country_id`: Identifies each country uniquely.
    - `country`: Name of the country.

#### Table: `provinces`
- **Purpose**: Stores information about provinces within countries.
- **Columns**:
    - `province_id`: Identifies each province uniquely.
    - `province`: Name of the province.
    - `country_id`: Links the province to a country.

#### Table: `survey_source`
- **Purpose**: Contains the sources from which survey data is collected.
- **Columns**:
    - `survey_source_id`: Identifies each survey source uniquely.
    - `survey_source`: Name of the survey source.

#### Table: `sections`
- **Purpose**: Contains different sections or categories of indicators.
- **Columns**:
    - `section_id`: Identifies each section uniquely.
    - `section`: Name or description of the section.

#### Table: `indicators`
- **Purpose**: Contains various health or demographic indicators.
- **Columns**:
    - `indicator_id`: Identifies each indicator uniquely.
    - `indicator`: Name or type of the indicator.
    - `section_id`: Links the indicator to a section.
    - `survey_source_id`: Links the indicator to a survey source.
    - `indicator_definition`: Detailed description or definition of the indicator.

#### Table: `lookup_groups`
- **Purpose**: Contains different groups for lookup values, such as ethnic groups, residence types, etc.
- **Columns**:
    - `lookup_group_id`: Identifies each lookup group uniquely.
    - `lookup_group`: Name of the lookup group.

#### Table: `lookups`
- **Purpose**: Contains specific lookup values within each lookup group.
- **Columns**:
    - `id`: Identifies each lookup value uniquely.
    - `lookup_group_id`: Links the lookup to a lookup group.
    - `lookup_id`: Unique identifier for the lookup value within its group.
    - `lookup`: Specific value in the lookup group.

#### Table: `indicators_data`
- **Purpose**: Contains the actual data for various indicators, associated with provinces, lookup groups, and specific lookups.
- **Columns**:
    - `id`: Identifies each data entry uniquely.
    - `indicator_id`: Links the data to a specific indicator.
    - `province_id`: Links the data to a specific province.
    - `lookup_group_id`: Links the data to a specific lookup group.
    - `lookup_id`: Links the data to a specific lookup value.
    - `indicator_data`: Numeric data for the indicator.
    - `survey_source_id`: Links the data to the survey source.
    - `country_id`: Links the data to the country.
    - `year`: Year of the data.

### Summary of Relationships:
- **`countries`** and **`provinces`**: A one-to-many relationship where each country can have multiple provinces.
- **`indicators`**: Linked to `sections` and `survey_source`, where each indicator belongs to a specific section and is associated with a specific survey source.
- **`lookup_groups`** and **`lookups`**: A one-to-many relationship where each lookup group can have multiple lookup values.
- **`indicators_data`**: Central table linking `indicators`, `provinces`, `lookup_groups`, `lookups`, `survey_source`, and `countries` together, storing the actual indicator data.

### Indicator Information

- Total Fertility Rate (number of children per woman)
- Median age at first birth women age 25-49 (years)
- Women age 15-19 who have ever been pregnant (%)
- Current use of any method of family planning (%)
- Current use of a modern method of family planning (%)
- Demand satisfied by modern methods of family planning (%)
- Unmet need for family planning
- Neonatal mortality
- Infant mortality
- Under-five mortality
- Births delivered in a health facility (%)
- Births assisted by a skilled provider3 (%)
- Children who are fully vaccinated against all basic antigens4 (%)
- Children who are fully vaccinated according to the national schedule5 (%)
- Children under age five who are stunted (%)
- Children under age five who are wasted (%)
- Children under age five who are underweight (%)
- Children age 6-23 months living with their mother fed a minimum acceptable diet6 (%)
- Women age 15-49 who achieved minimum dietary diversity7 (%)
- Household population with access to at least basic drinking water service (%)
- Household population with access to at least basic sanitation service8 (%)
- Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
- Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
- Married women age 15-49 who participate in household decisions9 (%)
- Women age 15-49 who have experienced physical violence since age 15 (%)
- Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months10 (%)
- Women age 15-49 who have heard of COVID-19 (%)
- Men age 15-49 who have heard of COVID-19 (%)
- Women age 15-49 with hypertension11 (%)
- Men age 15-49 with hypertension11 (%)
- Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
- Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
- Women age 15-49 with symptoms of anxiety according to international cutoffs12 (%)
- Men age 15-49 with symptoms of anxiety according to international cutoffs12 (%)
- Women age 15-49 with symptoms of depression according to international cutoffs13 (%)
- Men age 15-49 with symptoms of depression according to international cutoffs13 (%)
- Antenatal care (ANC) from a skilled provider



### Examples

#### Example 1:
**Query**: "List the fully vaccinated according to the national schedule for the section 'Child Health' and the source 'Survey XYZ'."

**Response**:
- **Intent**: The intent is `"SELECT"`, focusing on data retrieval.
- **Columns**: The columns are `indicators.indicator` and `indicators.indicator_definition`.
- **Tables**: The tables involved are `indicators`, `sections`, and `survey_source`.
- **Joins**: An `INNER JOIN` is required between `indicators` and `sections` on `indicators.section_id = sections.section_id`, and between `indicators` and `survey_source` on `indicators.survey_source_id = survey_source.survey_source_id`.
- **Filters**: The filters applied are `sections.section = 'Child Health'` and `survey_source.survey_source = 'Survey XYZ'`.
- **Aggregations**: No aggregations are needed.
- **Group By**: Not applicable.
- **Order By**: Not specified.
- **Aliases**: Not specified.
- **Case Statements**: Not used.
- **Concatenation**: Not used.
- **Subqueries**: Not used.
- **Indicators**: 'fully vaccinated according to the national schedule'

#### Example 2:
**Query**: "Find the average 'Under-five mortality' data for each country for the year 2022."

**Response**:
- **Intent**: The intent is `"SELECT"`, focusing on data retrieval with aggregation.
- **Columns**: The columns are `countries.country` and `AVG(indicators_data.indicator_data)`.
- **Tables**: The tables involved are `indicators_data`, `indicators`, and `countries`.
- **Joins**: An `INNER JOIN` is needed between `indicators_data` and `indicators` on `indicators_data.indicator_id = indicators.indicator_id`, and between `indicators_data` and `countries` on `indicators_data.country_id = countries.country_id`.
- **Filters**: The filters applied are `indicators.indicator = 'Under-five mortality'` and `indicators_data.year = 2022`.
- **Aggregations**: The aggregation used is `AVG`.
- **Group By**: Group by `countries.country`.
- **Order By**: Not specified.
- **Aliases**: Not specified.
- **Case Statements**: Not used.
- **Concatenation**: Not used.
- **Subqueries**: Not used.
- **Indicators**: 'Under-five mortality'

#### Example 3:
**Query**: "Retrieve the unmet need for family planning by lookup group for 2021, and sort the results by the number of indicators."

**Response**:
- **Intent**: The intent is `"SELECT"`, focusing on data retrieval with aggregation and sorting.
- **Columns**: The columns are `lookup_groups.lookup_group` and `COUNT(indicators.indicator_id)`.
- **Tables**: The tables involved are `indicators`, `indicators_data`, and `lookup_groups`.
- **Joins**: An `INNER JOIN` is required between `indicators_data` and `indicators` on `indicators_data.indicator_id = indicators.indicator_id`, and between `indicators_data` and `lookup_groups` on `indicators_data.lookup_group_id = lookup_groups.lookup_group_id`.
- **Filters**: The filters applied are `indicators.indicator LIKE '%Family Planning%'` and `indicators_data.year = 2021`.
- **Aggregations**: The aggregation used is `COUNT`.
- **Group By**: Group by `lookup_groups.lookup_group`.
- **Order By**: Order by `COUNT(indicators.indicator_id) DESC`.
- **Aliases**: Not specified.
- **Case Statements**: Not used.
- **Concatenation**: Not used.
- **Subqueries**: Not used.
- **Indicators**: `unmet need for family planning`


# Query

{query}

# Response

Discuss the intent and entities present in the natural query based on tables and their columns present in the database schema, identify the matching indicator from the  indicator information, and relationship details from the relationship summary section, including specifics about columns, tables, joins, filters, aggregations, and any other relevant SQL components.

"""

intent_prompt_template = PromptTemplate(
    input_variables=["query", "context"],
    template=intent_template
)

# Define the few-shot prompt template for SQL generation
sql_generation_template = """
Based on the clarified query and extracted entities, generate a standard PostgreSQL query using the provided database schema, indicator information and few-shot examples.

#### Context:
   The 2022 Nepal Demographic and Health Survey (2022 NDHS) is the sixth survey of its kind following the 1996 Nepal Family Health Survey and the 2001, 2006, 2011, and 2016 NDHS surveys. The 2022 NDHS incorporated a nationally representative sample of 14,280 households from 476 clusters.
   The principal objective of the 2006 Nepal Demographic and Health Survey (NDHS) is to provide current and reliable data on fertility and family planning behavior, child mortality, adult and maternal mortality, children’s nutritional status, the utilization of maternal and child health services, and knowledge of HIV/AIDS. 
   


# #### Instructions:
    
#     Follow these guidelines to ensure clarity, accuracy, and efficiency, while avoiding common pitfalls:

# 1. **Understanding and Clarifying the Query**:
#    - Ensure you fully understand the user's natural language query before attempting to write the SQL. Seek clarification if there are any ambiguities.

# 2. **Accurate Schema Reference**:
#    - Always refer to the provided database schema to identify the correct tables and columns. Misidentifying tables or columns can lead to incorrect or incomplete queries.
#    - Understand the relationships between tables, including primary keys and foreign keys, to construct accurate JOIN operations.

# 3. **JOIN Operations**:
#    - When combining data from multiple tables, use appropriate JOIN operations (INNER JOIN, LEFT JOIN, etc.). Ensure you understand the nature of the data relationships to choose the correct type of join.

# 4. **Filtering with WHERE Clauses**:
#    - Use WHERE clauses to filter data based on specified conditions accurately. Be careful with the data types and formats to avoid mismatches and errors.
#    - Employ the `LIKE` operator for handling variations in names and partial matches within the database.

# 5. **Handling Column Names**:
#    - Enclose column names in backticks (`) to prevent errors caused by reserved words or special characters.
#    - Select only the columns necessary to answer the query, optimizing the performance and readability of the query.

# 6. **Managing Data Types and Formats**:
#    - Be mindful of data types, especially when dealing with numerical and date values. Ensure the query logic aligns with the data types defined in the schema.
#    - Address potential warnings and errors related to data type conversions or mismatches.

# 7. **Limiting Results**:
#    - Use the LIMIT clause to restrict the number of rows returned by the query, especially when the user has not specified the desired amount of data.
#    - Ensure the limit is reasonable to provide a concise and manageable result set.

# 8. **Grouping Data**:
#    - Use the GROUP BY clause only when it is clear and necessary to aggregate data based on specific columns.
#    - Include all non-aggregated columns from the SELECT list in the GROUP BY clause to avoid errors with `ONLY_FULL_GROUP_BY` SQL mode in MySQL.
#    - When using aggregate functions, ensure that non-aggregated columns in the SELECT clause are included in the GROUP BY clause. This avoids issues with the `ONLY_FULL_GROUP_BY` SQL mode in MySQL.

# 9. **Verify Columns and Aliases**:
#    - Verify that all columns used in the query exist in the specified tables and are correctly referenced. Use `DESCRIBE` statements to check table structures.
#    - Ensure that aliases are properly defined and used consistently throughout the query.

# 10. **Changing SQL Mode**:
#     - If there are multiple queries affected by `ONLY_FULL_GROUP_BY`, consider changing the SQL mode by running the following command:
#       ```
#       SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));
#       ```
#     - This change should be done with caution and only if the database configuration allows it.

# 11. **Example Queries**:
#     - When applicable, leverage example SQL queries provided as part of the schema documentation or previous successful queries. Modify these examples to fit the specific details of the new query.
#     - Ensure that the modified queries still follow best practices and avoid the common mistakes mentioned.

# 12. **Best Practices**:
#     - Write clean and readable SQL code with proper formatting and indentation.
#     - Test queries where possible to verify they return the expected results before finalizing.
#     - Comment on complex parts of the query to explain the logic and make it easier to understand.

# By adhering to these guidelines, you can ensure that the SQL queries you construct from natural language inputs are accurate, efficient, and free from common mistakes.

# ### Database Schema:

# ## 1. **Table: `countries`**
# - **Purpose**: Stores information about countries.
# - **Schema**:
#     ```sql
#     CREATE TABLE countries (
#         country_id SERIAL NOT NULL, 
#         country VARCHAR(50) NOT NULL, 
#         CONSTRAINT countries_pkey PRIMARY KEY (country_id)
#     );
#     ```
# - **Columns**:
#     - `country_id`: Integer, Primary Key, Auto-increment.
#     - `country`: Name of the country, stored as a variable-length string.

# ## 2. **Table: `provinces`**
# - **Purpose**: Stores information about provinces within countries.
# - **Schema**:
#     ```sql
#     CREATE TABLE provinces (
#         province_id SERIAL NOT NULL, 
#         province VARCHAR(50) NOT NULL, 
#         country_id INTEGER DEFAULT 1 NOT NULL, 
#         CONSTRAINT provinces_pkey PRIMARY KEY (province_id), 
#         CONSTRAINT provinces_country_fk FOREIGN KEY(country_id) REFERENCES countries (country_id)
#     );
#     ```
# - **Columns**:
#     - `province_id`: Integer, Primary Key, Auto-increment.
#     - `province`: Name of the province, stored as a variable-length string.
#     - `country_id`: Foreign Key referencing `countries.country_id`, linking provinces to countries.

# ## 3. **Table: `survey_source`**
# - **Purpose**: Contains the sources from which survey data is collected.
# - **Schema**:
#     ```sql
#     CREATE TABLE survey_source (
#         survey_source_id SERIAL NOT NULL, 
#         survey_source VARCHAR(30) NOT NULL, 
#         CONSTRAINT survey_source_pkey PRIMARY KEY (survey_source_id)
#     );
#     ```
# - **Columns**:
#     - `survey_source_id`: Integer, Primary Key, Auto-increment.
#     - `survey_source`: Name of the survey source, stored as a variable-length string.

# ## 4. **Table: `sections`**
# - **Purpose**: Contains different sections or categories of indicators.
# - **Schema**:
#     ```sql
#     CREATE TABLE sections (
#         section_id SERIAL NOT NULL, 
#         section VARCHAR(100) NOT NULL, 
#         CONSTRAINT sections_pkey PRIMARY KEY (section_id)
#     );
#     ```
# - **Columns**:
#     - `section_id`: Integer, Primary Key, Auto-increment.
#     - `section`: Name or description of the section, stored as a variable-length string.

# ## 5. **Table: `indicators`**
# - **Purpose**: Contains various health or demographic indicators.
# - **Schema**:
#     ```sql
#     CREATE TABLE indicators (
#         indicator_id SERIAL NOT NULL, 
#         indicator VARCHAR(200) NOT NULL, 
#         section_id INTEGER, 
#         survey_source_id INTEGER DEFAULT 1 NOT NULL, 
#         indicator_definition TEXT, 
#         CONSTRAINT indicators_pkey PRIMARY KEY (indicator_id), 
#         CONSTRAINT indicators_sections_fk FOREIGN KEY(section_id) REFERENCES sections (section_id), 
#         CONSTRAINT indicators_survey_source_fk FOREIGN KEY(survey_source_id) REFERENCES survey_source (survey_source_id)
#     );
#     ```
# - **Columns**:
#     - `indicator_id`: Integer, Primary Key, Auto-increment.
#     - `indicator`: Name or type of the indicator, stored as a variable-length string.
#     - `section_id`: Foreign Key referencing `sections.section_id`, linking indicators to sections.
#     - `survey_source_id`: Foreign Key referencing `survey_source.survey_source_id`, linking indicators to their source.
#     - `indicator_definition`: Detailed description or definition of the indicator, stored as text.

# ## 6. **Table: `lookup_groups`**
# - **Purpose**: Contains different groups for lookup values, such as ethnic groups, residence types, etc.
# - **Schema**:
#     ```sql
#     CREATE TABLE lookup_groups (
#         lookup_group_id SERIAL NOT NULL, 
#         lookup_group VARCHAR(100) NOT NULL, 
#         CONSTRAINT lookup_groups_pkey PRIMARY KEY (lookup_group_id)
#     );
#     ```
# - **Columns**:
#     - `lookup_group_id`: Integer, Primary Key, Auto-increment.
#     - `lookup_group`: Name of the lookup group, stored as a variable-length string.

# ## 7. **Table: `lookups`**
# - **Purpose**: Contains specific lookup values within each lookup group.
# - **Schema**:
#     ```sql
#     CREATE TABLE lookups (
#         id SERIAL NOT NULL, 
#         lookup_group_id INTEGER NOT NULL, 
#         lookup_id INTEGER NOT NULL, 
#         lookup VARCHAR(100) NOT NULL, 
#         CONSTRAINT lookups_pkey PRIMARY KEY (id), 
#         CONSTRAINT lookups_lookups_groups_fk FOREIGN KEY(lookup_group_id) REFERENCES lookup_groups (lookup_group_id), 
#         CONSTRAINT lookup_lookup_group_uk UNIQUE (lookup_group_id, lookup_id)
#     );
#     ```
# - **Columns**:
#     - `id`: Integer, Primary Key, Auto-increment.
#     - `lookup_group_id`: Foreign Key referencing `lookup_groups.lookup_group_id`, linking lookups to lookup groups.
#     - `lookup_id`: Integer, unique within each lookup group.
#     - `lookup`: Specific value in the lookup group, stored as a variable-length string.

# ## 8. **Table: `indicators_data`**
# - **Purpose**: Contains the actual data for various indicators, associated with provinces, lookup groups, and specific lookups.
# - **Schema**:
#     ```sql
#     CREATE TABLE indicators_data (
#         id SERIAL NOT NULL, 
#         indicator_id INTEGER NOT NULL, 
#         province_id INTEGER, 
#         lookup_group_id INTEGER, 
#         lookup_id INTEGER, 
#         indicator_data DOUBLE PRECISION NOT NULL, 
#         survey_source_id INTEGER DEFAULT 1 NOT NULL, 
#         country_id INTEGER DEFAULT 1 NOT NULL, 
#         year INTEGER DEFAULT 2022 NOT NULL, 
#         CONSTRAINT indicators_data_pkey PRIMARY KEY (id), 
#         CONSTRAINT indicator_data_country_fk FOREIGN KEY(country_id) REFERENCES countries (country_id), 
#         CONSTRAINT indicator_data_lookup_fk FOREIGN KEY(lookup_group_id, lookup_id) REFERENCES lookups (lookup_group_id, lookup_id), 
#         CONSTRAINT indicator_data_lookup_group_fk FOREIGN KEY(lookup_group_id) REFERENCES lookup_groups (lookup_group_id), 
#         CONSTRAINT indicator_data_province_fk FOREIGN KEY(province_id) REFERENCES provinces (province_id), 
#         CONSTRAINT indicator_data_survey_source_fk FOREIGN KEY(survey_source_id) REFERENCES survey_source (survey_source_id), 
#         CONSTRAINT indicators_data_indicators_fk FOREIGN KEY(indicator_id) REFERENCES indicators (indicator_id)
#     );
#     ```
# - **Columns**:
#     - `id`: Integer, Primary Key, Auto-increment.
#     - `indicator_id`: Foreign Key referencing `indicators.indicator_id`, linking data to specific indicators.
#     - `province_id`: Foreign Key referencing `provinces.province_id`, linking data to specific provinces.
#     - `lookup_group_id`: Foreign Key referencing `lookup_groups.lookup_group_id`, linking data to specific lookup groups.
#     - `lookup_id`: Foreign Key referencing `lookups.id`, linking data to specific lookup values.
#     - `indicator_data`: Numeric data for the indicator, stored as a double precision floating-point number.
#     - `survey_source_id`: Foreign Key referencing `survey_source.survey_source_id`, linking data to the survey source.
#     - `country_id`: Foreign Key referencing `countries.country_id`, linking data to the country.
#     - `year`: Year of the data, stored as an integer.

# ## Summary of Relationships:
# - **`countries`** and **`provinces`**: A one-to-many relationship where each country can have multiple provinces.
# - **`indicators`**: Linked to `sections` and `survey_source`, where each indicator belongs to a specific section and is associated with a specific survey source.
# - **`lookup_groups`** and **`lookups`**: A one-to-many relationship where each lookup group can have multiple lookup values.
# - **`indicators_data`**: Central table linking `indicators`, `provinces`, `lookup_groups`, `lookups`, `survey_source`, and `countries` together, storing the actual indicator data.

# SQL Query Examples

## 1. **Basic `JOIN` Example:**
   - **Query**: Retrieve all indicators along with their respective province names, country names, and data for the year 2022.
   - **SQL**:
     ```sql
     SELECT 
      "i"."indicator", 
      "p"."province", 
      "c"."country", 
      "id"."indicator_data", 
      "id"."year"
      FROM 
          "public"."indicators_data" AS "id"
      JOIN 
          "public"."indicators" AS "i" ON "id"."indicator_id" = "i"."indicator_id"
      JOIN 
          "public"."provinces" AS "p" ON "id"."province_id" = "p"."province_id"
      JOIN 
          "public"."countries" AS "c" ON "p"."country_id" = "c"."country_id"
      WHERE 
          "id"."year" = 2022;
     ```

## 2. **`INNER JOIN` Example:**
   - **Query**: Retrieve all lookup values along with their respective lookup group names.
   - **SQL**:
     ```sql
     SELECT 
    "lg"."lookup_group", 
    "l"."lookup"
    FROM 
        "public"."lookups" AS "l"
    INNER JOIN 
        "public"."lookup_groups" AS "lg" ON "l"."lookup_group_id" = "lg"."lookup_group_id";

     ```

## 3. **Using `LIKE` for Pattern Matching:**
   - **Query**: Retrieve all indicators that contain the word "mortality" in their name.
   - **SQL**:
     ```sql
     SELECT 
    "indicator" 
    FROM 
        "public"."indicators" 
    WHERE 
        "indicator" LIKE '%mortality%';

     ```

## 4. **`WHERE` Clause with Multiple Conditions:**
   - **Query**: Retrieve indicators data for the province "Ontario" and year 2021.
   - **SQL**:
     ```sql
     SELECT 
    "i"."indicator", 
    "id"."indicator_data"
    FROM 
        "public"."indicators_data" AS "id"
    JOIN 
        "public"."indicators" AS "i" ON "id"."indicator_id" = "i"."indicator_id"
    JOIN 
        "public"."provinces" AS "p" ON "id"."province_id" = "p"."province_id"
    WHERE 
        "p"."province" LIKE 'Ontario' 
        AND "id"."year" = 2021;

     ```

## 5. **`LEFT JOIN` to Include All Records from One Table:**
   - **Query**: Retrieve all provinces with their respective indicators data, even if no data is available for some provinces.
   - **SQL**:
     ```sql
     SELECT 
    "p"."province", 
    "i"."indicator", 
    "id"."indicator_data"
    FROM 
        "public"."provinces" AS "p"
    LEFT JOIN 
        "public"."indicators_data" AS "id" ON "p"."province_id" = "id"."province_id"
    LEFT JOIN 
        "public"."indicators" AS "i" ON "id"."indicator_id" = "i"."indicator_id";

     ```

## 6. **Complex Query with `CASE`, `COALESCE`, and Multiple Joins:**
   - **Query**: Retrieve data for a specific indicator with province, group, and group type information. If a province is `NULL`, display "National" instead.
   - **SQL**:
     ```sql
     SELECT 
    "b"."indicator", 
    CASE 
        WHEN "c"."province" IS NULL THEN 'National' 
        ELSE "c"."province" || ' Province' 
    END AS "province", 
    COALESCE("d"."lookup_group", '') AS "Group", 
    COALESCE("e"."lookup", '') AS "Group Type", 
    "a"."indicator_data" AS "Value"
    FROM 
        "public"."indicators_data" AS "a" 
    INNER JOIN 
        "public"."indicators" AS "b" ON "a"."indicator_id" = "b"."indicator_id" 
    LEFT OUTER JOIN 
        "public"."provinces" AS "c" ON "a"."province_id" = "c"."province_id" 
    LEFT OUTER JOIN 
        "public"."lookup_groups" AS "d" ON "a"."lookup_group_id" = "d"."lookup_group_id" 
    LEFT OUTER JOIN 
        "public"."lookups" AS "e" ON "a"."lookup_id" = "e"."lookup_id" 
        AND "a"."lookup_group_id" = "e"."lookup_group_id" 
    WHERE 
        "a"."indicator_id" = 1;

     ```

This detailed breakdown should help in understanding the relationships between tables and how to write PostgreSQL queries based on this schema.



#### Intent and Entities:
{intent_entities}

## Write the standard  PostgreSQL-specific query for a natural language query. 
PostgreSQL uses double quotes (") to denote identifiers (e.g., table names, column names). 
Also, retrieve data from a table within the "public" schema.



### Query:
    {query}
### PostgreSQL:
"""



sql_generation_prompt_template = PromptTemplate(
    input_variables=["query", "context", "intent_entities"],
    template=sql_generation_template
)



# Initialize the LLMChain for each step
clarification_chain = LLMChain(llm=llm_codestral, prompt=clarification_prompt_template)
intent_chain = LLMChain(llm=llm_codestral, prompt=intent_prompt_template)
sql_generation_chain = LLMChain(llm=llm_codestral, prompt=sql_generation_prompt_template)






# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name


# Initialize the database object
# Create the SQLDatabase instance from the URI
db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20
)

import psycopg2
from psycopg2.extras import DictCursor

def create_text2sql_agent(query):
    # Step 1: Fetch the database schema as context
    context = db.get_context()

    # Step 2: Clarify the query
    clarified_query = clarification_chain.run(query=query, context=context)

    # Step 3: Extract intent and entities
    intent_entities = intent_chain.run(query=clarified_query, context=context)

    # Step 4: Generate the SQL query, including intent_entities in the input
    result = sql_generation_chain.run(query=clarified_query, context=context, intent_entities=intent_entities)
    
    
    generated_sql_query = result.strip().split('```sql')[1].split('```')[0].strip()

    # Step 5: Execute the SQL query
    
    # Establish a connection to the PostgreSQL database
    connection = psycopg2.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        dbname=db_name,        # Use 'dbname' instead of 'db'
        cursor_factory=DictCursor  # Optional: For dictionary-like cursor
    )
    
    with connection.cursor() as cursor:
        cursor.execute(generated_sql_query)
        result = cursor.fetchall()

    # Convert result to DataFrame
    result_df = pd.DataFrame(result)

    # Convert DataFrame to the desired JSON format
    result_json = {
        "sql_query": generated_sql_query,
        "dataframe": {
            "headers": list(result_df.columns),
            "data": result_df.values.tolist()
        }
    }
    
    # Return the result as JSON
    return result_json

# Example Usage
query = "How many children under age 15 have lost both parents?"
result = create_text2sql_agent(query)
print(result)








#ResearchTeam tools

#The research team can use a search engine and url scraper to find information on the web. Feel free to add additional functionality below to boost the team performance!

from typing import Annotated, List

from langchain_community.document_loaders import WebBaseLoader
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.tools import tool

tavily_tool = TavilySearchResults(max_results=5)


@tool
def scrape_webpages(urls: List[str]) -> str:
    """Use requests and bs4 to scrape the provided web pages for detailed information."""
    loader = WebBaseLoader(urls)
    docs = loader.load()
    return "\n\n".join(
        [
            f'<Document name="{doc.metadata.get("title", "")}">\n{doc.page_content}\n</Document>'
            for doc in docs
        ]
    )


#Document Writing Team tools
#Next up, we will give some tools for the doc writing team to use. We define some bare-bones file-access tools below.

#Note that this gives the agents access to your file-system, which can be unsafe. We also haven't optimized the tool descriptions for performance.

from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Dict, Optional

from langchain_experimental.utilities import PythonREPL
from typing_extensions import TypedDict

_TEMP_DIRECTORY = TemporaryDirectory()
WORKING_DIRECTORY = Path(_TEMP_DIRECTORY.name)


@tool
def create_outline(
    points: Annotated[List[str], "List of main points or sections."],
    file_name: Annotated[str, "File path to save the outline."],
) -> Annotated[str, "Path of the saved outline file."]:
    """Create and save an outline."""
    with (WORKING_DIRECTORY / file_name).open("w") as file:
        for i, point in enumerate(points):
            file.write(f"{i + 1}. {point}\n")
    return f"Outline saved to {file_name}"


@tool
def read_document(
    file_name: Annotated[str, "File path to save the document."],
    start: Annotated[Optional[int], "The start line. Default is 0"] = None,
    end: Annotated[Optional[int], "The end line. Default is None"] = None,
) -> str:
    """Read the specified document."""
    with (WORKING_DIRECTORY / file_name).open("r") as file:
        lines = file.readlines()
    if start is not None:
        start = 0
    return "\n".join(lines[start:end])


@tool
def write_document(
    content: Annotated[str, "Text content to be written into the document."],
    file_name: Annotated[str, "File path to save the document."],
) -> Annotated[str, "Path of the saved document file."]:
    """Create and save a text document."""
    with (WORKING_DIRECTORY / file_name).open("w") as file:
        file.write(content)
    return f"Document saved to {file_name}"


@tool
def edit_document(
    file_name: Annotated[str, "Path of the document to be edited."],
    inserts: Annotated[
        Dict[int, str],
        "Dictionary where key is the line number (1-indexed) and value is the text to be inserted at that line.",
    ],
) -> Annotated[str, "Path of the edited document file."]:
    """Edit a document by inserting text at specific line numbers."""

    with (WORKING_DIRECTORY / file_name).open("r") as file:
        lines = file.readlines()

    sorted_inserts = sorted(inserts.items())

    for line_number, text in sorted_inserts:
        if 1 <= line_number <= len(lines) + 1:
            lines.insert(line_number - 1, text + "\n")
        else:
            return f"Error: Line number {line_number} is out of range."

    with (WORKING_DIRECTORY / file_name).open("w") as file:
        file.writelines(lines)

    return f"Document edited and saved to {file_name}"


# Warning: This executes code locally, which can be unsafe when not sandboxed

repl = PythonREPL()


@tool
def python_repl(
    code: Annotated[str, "The python code to execute to generate your chart."],
):
    """Use this to execute python code. If you want to see the output of a value,
    you should print it out with `print(...)`. This is visible to the user."""
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    return f"Successfully executed:\n```python\n{code}\n```\nStdout: {result}"


# Helper Utilities
# We are going to create a few utility functions to make it more concise when we want to:

# Create a worker agent.
# Create a supervisor for the sub-graph.
# These will simplify the graph compositional code at the end for us so it's easier to see what's going on.

from typing import List, Optional

from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain.output_parsers.openai_functions import JsonOutputFunctionsParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI

from langgraph.graph import END, StateGraph, START


def create_agent(
    llm: ChatOpenAI,
    tools: list,
    system_prompt: str,
) -> str:
    """Create a function-calling agent and add it to the graph."""
    system_prompt += "\nWork autonomously according to your specialty, using the tools available to you."
    " Do not ask for clarification."
    " Your other team members (and other teams) will collaborate with you with their own specialties."
    " You are chosen for a reason! You are one of the following team members: {team_members}."
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                system_prompt,
            ),
            MessagesPlaceholder(variable_name="messages"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )
    agent = create_openai_functions_agent(llm, tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools)
    return executor

from langchain_core.messages import  HumanMessage
def agent_node(state, agent, name):
    result = agent.invoke(state)
    return {"messages": [HumanMessage(content=result["output"], name=name)]}


def create_team_supervisor(llm: ChatOpenAI, system_prompt, members) -> str:
    """An LLM-based router."""
    options = ["FINISH"] + members
    function_def = {
        "name": "route",
        "description": "Select the next role.",
        "parameters": {
            "title": "routeSchema",
            "type": "object",
            "properties": {
                "next": {
                    "title": "Next",
                    "anyOf": [
                        {"enum": options},
                    ],
                },
            },
            "required": ["next"],
        },
    }
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="messages"),
            (
                "system",
                "Given the conversation above, who should act next?"
                " Or should we FINISH? Select one of: {options}",
            ),
        ]
    ).partial(options=str(options), team_members=", ".join(members))
    return (
        prompt
        | llm.bind_functions(functions=[function_def], function_call="route")
        | JsonOutputFunctionsParser()
    )


# Define Agent Teams
# Now we can get to define our hierarchical teams. "Choose your player!"

# Research Team
# The research team will have a search agent and a web scraping "research_agent" as the two worker nodes. Let's create those, as well as the team supervisor.

import functools
import operator

from langchain_core.messages import BaseMessage, HumanMessage
from langchain_openai.chat_models import ChatOpenAI


# ResearchTeam graph state
class ResearchTeamState(TypedDict):
    # A message is added after each team member finishes
    messages: Annotated[List[BaseMessage], operator.add]
    # The team members are tracked so they are aware of
    # the others' skill-sets
    team_members: List[str]
    # Used to route work. The supervisor calls a function
    # that will update this every time it makes a decision
    next: str


llm = ChatOpenAI(model="gpt-4-1106-preview")

search_agent = create_agent(
    llm,
    [tavily_tool],
    "You are a research assistant who can search for up-to-date info using the tavily search engine.",
)
search_node = functools.partial(agent_node, agent=search_agent, name="Search")

research_agent = create_agent(
    llm,
    [scrape_webpages],
    "You are a research assistant who can scrape specified urls for more detailed information using the scrape_webpages function.",
)
research_node = functools.partial(agent_node, agent=research_agent, name="WebScraper")

supervisor_agent = create_team_supervisor(
    llm,
    "You are a supervisor tasked with managing a conversation between the"
    " following workers:  Search, WebScraper. Given the following user request,"
    " respond with the worker to act next. Each worker will perform a"
    " task and respond with their results and status. When finished,"
    " respond with FINISH.",
    ["Search", "WebScraper"],
)
# Now that we've created the necessary components, defining their interactions is easy. Add the nodes to the team graph, and define the edges, which determine the transition criteria.

research_graph = StateGraph(ResearchTeamState)
research_graph.add_node("Search", search_node)
research_graph.add_node("WebScraper", research_node)
research_graph.add_node("supervisor", supervisor_agent)

# Define the control flow
research_graph.add_edge("Search", "supervisor")
research_graph.add_edge("WebScraper", "supervisor")
research_graph.add_conditional_edges(
    "supervisor",
    lambda x: x["next"],
    {"Search": "Search", "WebScraper": "WebScraper", "FINISH": END},
)


research_graph.add_edge(START, "supervisor")
chain = research_graph.compile()

# The following functions interoperate between the top level graph state
# and the state of the research sub-graph
# this makes it so that the states of each graph don't get intermixed
def enter_chain(message: str):
    results = {
        "messages": [HumanMessage(content=message)],
    }
    return results


research_chain = enter_chain | chain

# We can give this team work directly. Try it out below.

for s in research_chain.stream(
    "when is Taylor Swift's next tour?", {"recursion_limit": 100}
):
    if "__end__" not in s:
        print(s)
        print("---")


# The following functions interoperate between the top level graph state
# and the state of the research sub-graph
# this makes it so that the states of each graph don't get intermixed
def enter_chain(message: str):
    results = {
        "messages": [HumanMessage(content=message)],
    }
    return results


research_chain = enter_chain | chain


# Document Writing Team
# Create the document writing team below using a similar approach. This time, we will give each agent access to different file-writing tools.

# Note that we are giving file-system access to our agent here, which is not safe in all cases.

import operator
from pathlib import Path


# Document writing team graph state
class DocWritingState(TypedDict):
    # This tracks the team's conversation internally
    messages: Annotated[List[BaseMessage], operator.add]
    # This provides each worker with context on the others' skill sets
    team_members: str
    # This is how the supervisor tells langgraph who to work next
    next: str
    # This tracks the shared directory state
    current_files: str


# This will be run before each worker agent begins work
# It makes it so they are more aware of the current state
# of the working directory.
def prelude(state):
    written_files = []
    if not WORKING_DIRECTORY.exists():
        WORKING_DIRECTORY.mkdir()
    try:
        written_files = [
            f.relative_to(WORKING_DIRECTORY) for f in WORKING_DIRECTORY.rglob("*")
        ]
    except Exception:
        pass
    if not written_files:
        return {**state, "current_files": "No files written."}
    return {
        **state,
        "current_files": "\nBelow are files your team has written to the directory:\n"
        + "\n".join([f" - {f}" for f in written_files]),
    }


llm = ChatOpenAI(model="gpt-4-1106-preview")

doc_writer_agent = create_agent(
    llm,
    [write_document, edit_document, read_document],
    "You are an expert writing a research document.\n"
    # The {current_files} value is populated automatically by the graph state
    "Below are files currently in your directory:\n{current_files}",
)
# Injects current directory working state before each call
context_aware_doc_writer_agent = prelude | doc_writer_agent
doc_writing_node = functools.partial(
    agent_node, agent=context_aware_doc_writer_agent, name="DocWriter"
)

note_taking_agent = create_agent(
    llm,
    [create_outline, read_document],
    "You are an expert senior researcher tasked with writing a paper outline and"
    " taking notes to craft a perfect paper.{current_files}",
)
context_aware_note_taking_agent = prelude | note_taking_agent
note_taking_node = functools.partial(
    agent_node, agent=context_aware_note_taking_agent, name="NoteTaker"
)

chart_generating_agent = create_agent(
    llm,
    [read_document, python_repl],
    "You are a data viz expert tasked with generating charts for a research project."
    "{current_files}",
)
context_aware_chart_generating_agent = prelude | chart_generating_agent
chart_generating_node = functools.partial(
    agent_node, agent=context_aware_note_taking_agent, name="ChartGenerator"
)

doc_writing_supervisor = create_team_supervisor(
    llm,
    "You are a supervisor tasked with managing a conversation between the"
    " following workers:  {team_members}. Given the following user request,"
    " respond with the worker to act next. Each worker will perform a"
    " task and respond with their results and status. When finished,"
    " respond with FINISH.",
    ["DocWriter", "NoteTaker", "ChartGenerator"],
)

#With the objects themselves created, we can form the graph.

# Create the graph here:
# Note that we have unrolled the loop for the sake of this doc
authoring_graph = StateGraph(DocWritingState)
authoring_graph.add_node("DocWriter", doc_writing_node)
authoring_graph.add_node("NoteTaker", note_taking_node)
authoring_graph.add_node("ChartGenerator", chart_generating_node)
authoring_graph.add_node("supervisor", doc_writing_supervisor)

# Add the edges that always occur
authoring_graph.add_edge("DocWriter", "supervisor")
authoring_graph.add_edge("NoteTaker", "supervisor")
authoring_graph.add_edge("ChartGenerator", "supervisor")

# Add the edges where routing applies
authoring_graph.add_conditional_edges(
    "supervisor",
    lambda x: x["next"],
    {
        "DocWriter": "DocWriter",
        "NoteTaker": "NoteTaker",
        "ChartGenerator": "ChartGenerator",
        "FINISH": END,
    },
)

authoring_graph.add_edge(START, "supervisor")
chain = authoring_graph.compile()


# The following functions interoperate between the top level graph state
# and the state of the research sub-graph
# this makes it so that the states of each graph don't get intermixed
def enter_chain(message: str, members: List[str]):
    results = {
        "messages": [HumanMessage(content=message)],
        "team_members": ", ".join(members),
    }
    return results


# We reuse the enter/exit functions to wrap the graph
authoring_chain = (
    functools.partial(enter_chain, members=authoring_graph.nodes)
    | authoring_graph.compile()
)

for s in authoring_chain.stream(
    "Write an outline for poem and then write the poem to disk.",
    {"recursion_limit": 100},
):
    if "__end__" not in s:
        print(s)
        print("---")
        
# Add Layers
# In this design, we are enforcing a top-down planning policy. We've created two graphs already, but we have to decide how to route work between the two.

# We'll create a third graph to orchestrate the previous two, and add some connectors to define how this top-level state is shared between the different graphs.

from langchain_core.messages import BaseMessage
from langchain_openai.chat_models import ChatOpenAI

llm = ChatOpenAI(model="gpt-4-1106-preview")

supervisor_node = create_team_supervisor(
    llm,
    "You are a supervisor tasked with managing a conversation between the"
    " following teams: {team_members}. Given the following user request,"
    " respond with the worker to act next. Each worker will perform a"
    " task and respond with their results and status. When finished,"
    " respond with FINISH.",
    ["ResearchTeam", "PaperWritingTeam"],
)
# Top-level graph state
class State(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    next: str


def get_last_message(state: State) -> str:
    return state["messages"][-1].content


def join_graph(response: dict):
    return {"messages": [response["messages"][-1]]}


# Define the graph.
super_graph = StateGraph(State)
# First add the nodes, which will do the work
super_graph.add_node("ResearchTeam", get_last_message | research_chain | join_graph)
super_graph.add_node(
    "PaperWritingTeam", get_last_message | authoring_chain | join_graph
)
super_graph.add_node("supervisor", supervisor_node)

# Define the graph connections, which controls how the logic
# propagates through the program
super_graph.add_edge("ResearchTeam", "supervisor")
super_graph.add_edge("PaperWritingTeam", "supervisor")
super_graph.add_conditional_edges(
    "supervisor",
    lambda x: x["next"],
    {
        "PaperWritingTeam": "PaperWritingTeam",
        "ResearchTeam": "ResearchTeam",
        "FINISH": END,
    },
)
super_graph.add_edge(START, "supervisor")
super_graph = super_graph.compile()

for s in super_graph.stream(
    {
        "messages": [
            HumanMessage(
                content="Write a brief research report on the North American sturgeon. Include a chart."
            )
        ],
    },
    {"recursion_limit": 150},
):
    if "__end__" not in s:
        print(s)
        print("---")