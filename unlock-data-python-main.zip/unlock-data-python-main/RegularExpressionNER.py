#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 11:19:51 2024

HEre we are using RegularExpression for matching.

@author: asmat
"""

import re
import nltk
from nltk.corpus import wordnet 
from difflib import SequenceMatcher
from langchain_community.utilities.sql_database import SQLDatabase
import psycopg2
from psycopg2.extras import DictCursor
import pandas as pd
# nltk.download('punkt') as it is already installed 
# nltk.download('wordnet') if once installed comment it 



# Example query text
query_text = "how many Married women age 15-49 who participate in household decisions in hill region?"

#########################################################
##### First do matching for indicator ###################
#########################################################
    
indicator_list = [
        "Total Fertility Rate (number of children per woman)",
        "Median age at first birth women age 25-49 (years)",
        "Women age 15-19 who have ever been pregnant",
        "Current use of any method of family planning",
        "Current use of a modern method of family planning",
        "Demand satisfied by modern methods of family planning",
        "Unmet need for family planning",
        "Neonatal mortality",
        "Infant mortality",
        "Under-five mortality",
        "Antenatal care (ANC) from a skilled provider",
        "Births delivered in a health facility",
        "Births assisted by a skilled provider",
        "Children who are fully vaccinated against all basic antigens",
        "Children who are fully vaccinated according to the national schedule",
        "Children under age five who are stunted",
        "Children under age five who are wasted",
        "Children under age five who are underweight",
        "Children age 6-23 months living with their mother fed a minimum acceptable diet",
        "Women age 15-49 who achieved minimum dietary diversity",
        "Household population with access to at least basic drinking water service",
        "Household population with access to at least basic sanitation service",
        "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months",
        "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months",
        "Married women age 15-49 who participate in household decisions",
        "Women age 15-49 who have experienced physical violence since age 15",
        "Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months",
        "Women age 15-49 who have heard of COVID-19",
        "Men age 15-49 who have heard of COVID-19",
        "Women age 15 and above with hypertension",
        "Men age 15 and above with hypertension",
        "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability",
        "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability",
        "Women age 15-49 with symptoms of anxiety according to international cutoffs",
        "Men age 15-49 with symptoms of anxiety according to international cutoffs",
        "Women age 15-49 with symptoms of depression according to international cutoffs",
        "Men age 15-49 with symptoms of depression according to international cutoffs"
]


indicators_with_percentage_list = [
        "Total Fertility Rate (number of children per woman)",
        "Median age at first birth women age 25-49 (years)",
        "Women age 15-19 who have ever been pregnant (%)",
        "Current use of any method of family planning (%)",
        "Current use of a modern method of family planning (%)",
        "Demand satisfied by modern methods of family planning (%)",
        "Unmet need for family planning",
        "Neonatal mortality",
        "Infant mortality",
        "Under-five mortality",
        "Antenatal care (ANC) from a skilled provider",
        "Births delivered in a health facility (%)",
        "Births assisted by a skilled provider (%)",
        "Children who are fully vaccinated against all basic antigens (%)",
        "Children who are fully vaccinated according to the national schedule (%)",
        "Children under age five who are stunted (%)",
        "Children under age five who are wasted (%)",
        "Children under age five who are underweight (%)",
        "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
        "Women age 15-49 who achieved minimum dietary diversity (%)",
        "Household population with access to at least basic drinking water service (%)",
        "Household population with access to at least basic sanitation service (%)",
        "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
        "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
        "Married women age 15-49 who participate in household decisions (%)",
        "Women age 15-49 who have experienced physical violence since age 15 (%)",
        "Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months (%)",
        "Women age 15-49 who have heard of COVID-19 (%)",
        "Men age 15-49 who have heard of COVID-19 (%)",
        "Women age 15 and above with hypertension (%)",
        "Men age 15 and above with hypertension (%)",
        "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
        "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
        "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
        "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
        "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
        "Men age 15-49 with symptoms of depression according to international cutoffs (%)"
   
    
    ]


def custom_tokenize(text):
    # Regular expression to match words, numbers, and special numeric patterns
    token_pattern = r'\b(?:\d+\+|\d+-\d+|\d+|\w+)\b'
    return re.findall(token_pattern, text)




from fuzzywuzzy import fuzz


# Define stop words
STOP_WORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
    'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
    'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was',
    'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
    'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
    'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on',
    'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
    'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
    'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
])





### This method is finding indicator using  sentence transformer
from sentence_transformers import SentenceTransformer, util
from sklearn.metrics.pairwise import cosine_similarity
import nltk
from nltk.corpus import wordnet

# Load the sentence transformer model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Function to calculate cosine similarity using sentence transformers
def calculate_cosine_similarity(vector1, vector2):
    return cosine_similarity([vector1], [vector2])[0][0]



nltk.download('wordnet')

from nltk.corpus import wordnet

def get_synonyms(word):
    """
    Find synonyms of a given word using WordNet.

    Args:
    - word (str): The word to find synonyms for.

    Returns:
    - set: A set of synonyms for the given word.
    """
    synonyms = []

    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.append(lemma.name())

    return set(synonyms)


# # Function to get synonyms using WordNet
# def get_synonyms(word):
#     synonyms = set()
#     for syn in wordnet.synsets(word):
#         for lemma in syn.lemmas():
#             synonyms.add(lemma.name().replace("_", " "))
#     return synonyms

# Function to remove matched parts based on tokens and synonyms


import textdistance
import nltk
from nltk.corpus import wordnet



# Function to check if two words are similar enough (for spell checking)
def are_similar(word1, word2, threshold=0.8):
    return textdistance.jaro_winkler(word1, word2) > threshold

# Function to remove matched parts from the query, accounting for synonyms and misspellings
def remove_matched_parts(query, indicator, similarity_threshold=0.8):
    # Tokenize the query
    query_tokens = query.lower().split()
   
    # Tokenize the matched indicator
    indicator_tokens = set(indicator.lower().split())
    
    # Get synonyms for each token in the indicator
    indicator_synonyms = set()
    for token in indicator_tokens:
        indicator_synonyms.update(get_synonyms(token))
    indicator_tokens.update(indicator_synonyms)
    
    # Remove matched tokens or their synonyms (or similar words) from the query
    filtered_tokens = []
    for token in query_tokens:
        if not any(are_similar(token, ind_token, similarity_threshold) for ind_token in indicator_tokens):
            filtered_tokens.append(token)
    
    query_tokens = filtered_tokens
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return modified_query.strip()





# Function to process query and indicators using sentence transformers
def process_query_with_transformer(query, indicators, similarity_threshold=0.3):
    # Convert query and indicators into vectors using the sentence transformer
    query_vec = model.encode(query)
    indicator_vectors = model.encode(indicators)

    highest_similarity = similarity_threshold
    percentage_indicators_index = -1
    for i, indicator in enumerate(indicators):
        sim = util.pytorch_cos_sim(query_vec, indicator_vectors[i]).item()
        if sim > highest_similarity:
            highest_similarity = sim
            percentage_indicators_index=i

    # # Pick elements from the indicators list using the indices
    # matched_indicators = [indicators_with_percentage_list[i] for i in percentage_indicators_index]
    matched_indicators = indicators_with_percentage_list[percentage_indicators_index]
    # Remove matched indicator phrases from the query using tokens and synonyms
    modified_query = remove_matched_parts(query, matched_indicators)
    return matched_indicators, modified_query

matched_indicators, modified_query = process_query_with_transformer(query_text, indicator_list)



print("Matched Indicators:", matched_indicators)
print("Modified Query:", modified_query)

##### Now modified_query is again modified to remove the STOPWORDS
# Define stop words
STOP_WORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
    'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
    'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was',
    'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
    'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
    'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on',
    'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
    'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
    'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
])

# Function to remove stop words from a text
def remove_stop_words(text):
    tokens = text.lower().split()  # Tokenize and convert to lowercase
    filtered_tokens = [word for word in tokens if word not in STOP_WORDS]  # Filter out stop words
    return " ".join(filtered_tokens)


modified_query = remove_stop_words(modified_query)


################################################################
##### Now we do matching for the provinces #####################
################################################################
import textdistance


province_list = [
    "National"
    "Bagmati",
    "Gandaki",
    "Karnali",
    "Koshi",
    "Lumbini",
    "Madhesh",
    "Sudurpashchim"
]

# Function to check if two words are similar enough (for spell checking)
def are_similar(word1, word2, threshold=0.8):
    return textdistance.jaro_winkler(word1, word2) > threshold

# Function to find and remove matched provinces from the query
def find_and_remove_matched_provinces(query, province_list, similarity_threshold=0.8):
    query_tokens = query.lower().split()
    matched_provinces = []
    
    for province in province_list:
        province_tokens = province.lower().split()
        
        for token in query_tokens:
            if any(are_similar(token, province_token, similarity_threshold) for province_token in province_tokens):
                matched_provinces.append(province)
                
                # Remove all tokens related to the matched province from the query
                query_tokens = [t for t in query_tokens if not any(are_similar(t, province_token, similarity_threshold) for province_token in province_tokens)]
                break  # Move to the next province once a match is found
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return matched_provinces, modified_query.strip()



matched_provinces, modified_query = find_and_remove_matched_provinces(modified_query, province_list)

# Output matched provinces
print("Matched Provinces:")
for province in matched_provinces:
    print(province)

# Output the modified query
print("Modified Query:", modified_query)





############################################################################
################# Let us match lookup group based on lookup ################
############################################################################
import json
from fuzzywuzzy import fuzz
from fuzzywuzzy import fuzz
from nltk.corpus import wordnet
import nltk
from fuzzywuzzy import fuzz
from nltk.corpus import wordnet
from nltk.corpus import stopwords
import nltk
import string

nltk.download('stopwords')
# Ensure NLTK resources are downloaded
nltk.download('wordnet')
# Define stop words
STOP_WORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
    'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
    'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was',
    'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
    'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
    'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on',
    'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
    'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
    'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
])    

def find_matched_groups_and_lookups(text, lookup_groups):
    """Find and return matched lookup groups and lookups based on fuzzy matching and synonyms."""
    



    def normalize_text(text):
        """Normalize text by converting to lowercase, stripping punctuation, and removing stop words."""
        
        
        # Convert to lowercase
        text = text.lower()
        # Remove punctuation
        text = text.translate(str.maketrans('', '', string.punctuation))
        
        words = text.split()
        filtered_words = [word for word in words if word not in STOP_WORDS]
        return ' '.join(filtered_words)


    

    
    def get_synonyms(word):
        """Retrieve synonyms for a given word."""
        synonyms = set()
        for syn in wordnet.synsets(word):
            for lemma in syn.lemmas():
                synonyms.add(lemma.name())
        return synonyms
    
    def find_best_match(token, lookups):
        """Find the best match for a token from a list of lookups using fuzzy matching and synonyms."""
        token_normalized = normalize_text(token)
        
        # Create an extended token list with synonyms
        extended_tokens = set([token_normalized])
        extended_tokens.update(get_synonyms(token_normalized))
        
        best_match = None
        highest_ratio = 0
        
        for lookup in lookups:
            for extended_token in extended_tokens:
                ratio = fuzz.ratio(extended_token, lookup)
                if ratio > highest_ratio:
                    highest_ratio = ratio
                    best_match = lookup
    
        return best_match if highest_ratio > 70 else None




    # Tokenize and normalize text
    filtered_tokens = custom_tokenize(text)
    
    filtered_tokens = [token for token in filtered_tokens if token.lower() not in STOP_WORDS]
    
    matched_lookup_groups = set()
    matched_lookups = set()

    for group in lookup_groups:
        group_name = group['group']
        lookups = [lookup for lookup in group.get('lookups', [])]

        for token in filtered_tokens:
            # Check for the best match for the token
            matched_lookup = find_best_match(token, lookups)
            if matched_lookup:
                matched_lookups.add(matched_lookup)
                matched_lookup_groups.add(group_name)
                

    return list(matched_lookup_groups), list(matched_lookups)

# Define your lookup groups as a nested JSON
lookup_groups_json = '''
{
  "lookup_groups": [
    {
      "group": "Ecological zone",
      "lookups": [
        "Mountain",
        "Hill",
        "Terai"
      ]
    },
    {
      "group": "Residence",
      "lookups": [
        "Urban",
        "Rural"
      ]
    },
    {
      "group": "Wealth Quintile",
      "lookups": [
        "Lowest",
        "Second",
        "Middle",
        "Fourth",
        "Highest"
      ]
    },
    {
      "group": "Age",
      "lookups": [
        "<5",
        "5-9",
        "10-14",
        "15-19",
        "20–24",
        "25–29",
        "30–34",
        "35–39",
        "40–44",
        "45–49",
        "50–54",
        "55–59",
        "60–64",
        "65–69",
        "70–74",
        "75–79",
        "80+"
      ]
    },
    {
      "group": "Education",
      "lookups": [
        "No education",
        "Basic education (1-8)",
        "Secondary Education (9-12)",
        "More than secondary (13 and above)"
      ]
    },
    {
      "group": "Ethnic Group",
      "lookups": [
        "Brahmin/Chhetri",
        "Dalit",
        "Janajati",
        "Madhesi",
        "Muslim"
      ]
    },
    {
      "group": "Mothers Education",
      "lookups": [
        "No education",
        "Basic education",
        "Secondary education",
        "More than secondary"
      ]
    },
    {
      "group": "Child Sex",
      "lookups": [
        "Male",
        "Female"
      ]
    },
    {
      "group": "Mother's Age",
      "lookups": [
        "<20",
        "20-34",
        "35-49"
      ]
    },
    {
      "group": "Birth Order",
      "lookups": [
        "1",
        "2-3",
        "4-5",
        "6+"
      ]
    },
    {
      "group": "Antenatal Care Visits",
      "lookups": [
        "None",
        "1-3",
        "4+"
      ]
    },
    {
      "group": "Sex",
      "lookups": [
        "Male",
        "Female"
      ]
    },
    {
      "group": "Seen",
      "lookups": [
        "Seen",
        "Not seen or no longer has"
      ]
    },
    {
      "group": "Age Group",
      "lookups": [
        "15-49",
        "20-29",
        "30-39",
        "40-49"
      ]
    },
    {
      "group": "Age in Month",
      "lookups": [
        "<6",
        "6-11",
        "6-8",
        "9-11",
        "12-23",
        "12-18",
        "18-23",
        "24-35",
        "36-47",
        "48-59"
      ]
    },
    {
      "group": "Birth Interval in Months",
      "lookups": [
        "<24",
        "24-47",
        "48+"
      ]
    },
    {
      "group": "Size at Birth",
      "lookups": [
        "Very small",
        "Small",
        "Average or larger"
      ]
    },
    {
      "group": "Mother's Nutritional Status",
      "lookups": [
        "Thin",
        "Normal",
        "Overweight/Obese"
      ]
    },
    {
      "group": "Maternity Status",
      "lookups": [
        "Pregnant",
        "Not pregnant"
      ]
    },
    {
      "group": "Employment (Last 12 Months)",
      "lookups": [
        "Not employed",
        "Employed for cash",
        "Employed not for cash"
      ]
    },
    {
      "group": "Number of Living Children",
      "lookups": [
        "0",
        "1-2",
        "3-4",
        "5+"
      ]
    },
    {
      "group": "Marital Status",
      "lookups": [
        "Never married",
        "Never had intimate partner",
        "Ever had intimate partner",
        "Ever married",
        "Married/living together",
        "Divorced/separated/widowed",
        "Divorced",
        "Widowed"
      ]
    },
    {
      "group": "Nutritional Status",
      "lookups": [
        "Thin",
        "Normal",
        "Overweight",
        "Obese",
        "Not weighed or measured"
      ]
    }
  ]
}
'''

# Load lookup groups from JSON
lookup_groups = json.loads(lookup_groups_json)['lookup_groups']



# Find matched lookup groups and lookups
matched_lookup_groups, matched_lookups = find_matched_groups_and_lookups(modified_query, lookup_groups)

# Output matched lookup groups and lookups
print("Matched Lookup Groups:")
for group in matched_lookup_groups:
    print(group)

print("\nMatched Lookups:")
for lookup in matched_lookups:
    print(lookup)

######################### NER job finished.####################################

def format_for_sql(names_list):
    if names_list:
        return ', '.join(f"'{name}'" for name in names_list)
    return ''  # Return an empty string if the list is empty

# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name

db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20)
    
    
    
# Create a dictionary with the specified keys and lists as values
matched_entities = {
    'indicators': matched_indicators,
    'provinces': matched_provinces,
    'lookup_groups': matched_lookup_groups,
    'lookups': matched_lookups
}


# Extract values from the dictionary
indicator_names = matched_entities.get('indicators', [])
province_names = matched_entities.get('provinces', [])
lookup_group_names = matched_entities.get('lookup_groups', [])
lookup_names = matched_entities.get('lookups', [])


# Construct SQL conditions with handling for empty lists
# = f"i.indicator IN ({format_for_sql(indicator_names)})" if indicator_names else "1=1"
indicator_condition = f"i.indicator = '{indicator_names}'" if indicator_names else "1=1"
province_condition = f"p.province IN ({format_for_sql(province_names)})" if province_names else "1=1"
lookup_group_condition = f"lg.lookup_group IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
lookup_condition = f"l.lookup IN ({format_for_sql(lookup_names)}) AND lg.lookup_group_id = l.lookup_group_id" if lookup_names else "1=1"

# Construct the final SQL query using f-strings
sql_query = f"""
WITH filtered_data AS (
    SELECT 
        id.* 
    FROM 
        indicators_data id
    LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
    LEFT JOIN provinces p ON id.province_id = p.province_id
    LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
    LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
    WHERE 
        {indicator_condition} AND
        ({province_condition}) AND
        ({lookup_group_condition}) AND
        ({lookup_condition})
)
SELECT 
    i.indicator,
    COALESCE(p.province, 'National') AS province,
    COALESCE(lg.lookup_group, 'N/A') AS lookup_group,
    COALESCE(l.lookup, 'N/A') AS lookup,
    id.indicator_data AS value,
    id.survey_source_id,
    id.year
    
FROM 
    filtered_data id
LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
LEFT JOIN provinces p ON id.province_id = p.province_id
LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
ORDER BY 
    i.indicator,
    p.province,
    lg.lookup_group,
    l.lookup;
"""

print(sql_query)

generated_sql_query = sql_query


connection = psycopg2.connect(
host=db_host,
user=db_user,
password=db_password,
dbname=db_name,
cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
)

with connection.cursor() as cursor:
    cursor.execute(generated_sql_query)
    result = cursor.fetchall()

# Convert result to DataFrame
result_df = pd.DataFrame(result)

# Convert DataFrame to the desired JSON format
result_json = {
    "sql_query": generated_sql_query,
    "dataframe": {
        "headers": list(result_df.columns),
        "data": result_df.values.tolist()
    }
}