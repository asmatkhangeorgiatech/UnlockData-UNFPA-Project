#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 17:21:24 2024

Cross-Attention mechanoism

@author: asmat
"""

import torch
from transformers import T5Tokenizer, T5ForConditionalGeneration, BertTokenizer, BertModel



# Define the small phrase and list of paragraphs
phrase = "women age 15-49 who have experienced physical violence since age 15 "

paragraphs = [
    "This heighlights the children who have completed the full set of vaccinations for basic diseases as recommended by standard immunization schedules. It ensures that children are protected from common infectious diseases through timely vaccinations.",
    "This heighlights tracking the children who are up-to-date with their country's national immunization schedule. It highlights the effectiveness of vaccination programs in preventing disease and ensuring comprehensive immunization coverage.",
    "The concept of unmet need for family planning refers to women who wish to avoid or delay pregnancy but are not using contraception. This gap between their reproductive desires and current contraceptive practices reveals the challenges in accessing or utilizing family planning services.",
    "This indicator evaluates the nutritional practices for children aged 6 to 23 months, focusing on dietary diversity and meal frequency. It identifies gaps in adherence to recommended feeding practices, stressing the need for improved nutrition to prevent malnutrition and support healthy growth.",
    "This text examines the nutritional status of women, highlighting metrics like height, weight, and body mass index, alongside their dietary habits. It underscores the need for dietary diversity to prevent health issues, revealing that less than half of women meet optimal nutritional standards, especially in less developed regions.",
    "The report emphasizes the near-universal access to basic drinking water in Nepal, which is crucial for preventing waterborne diseases. It highlights the benefits of clean water access for health and economic development, noting the role of gender equality in improving water and sanitation services.",
    "This survey report provides detailed insights into household water, sanitation, and hygiene access. It breaks down service availability by region and socioeconomic status, highlighting disparities and providing essential information for improving public health and sanitation infrastructure.",
    "This measures the women aged 15 to 49 who either have a bank account or have used a mobile phone for financial transactions in the past year.",
    "The text reveals gender disparities in accessing banking and financial services, with more men having and using bank accounts and mobile phones for transactions. This inequality affects economic opportunities and financial inclusion, highlighting the need for targeted interventions to address these gaps.",
    "Domestic violence against women remains prevalent, affecting many who have had intimate partners. The report details the incidence of physical, sexual, or emotional abuse, highlighting the urgent need for effective support systems and interventions to address this significant societal issue.",
    "The analysis of women's involvement in household decisions reveals varying degrees of participation in areas like health care, major purchases, and family visits. It highlights gender role disparities and the impact of such dynamics on gender equality and women's empowerment.",
    "This  focuses on mortality rates among children, including neonatal, infant, child, and under-five mortality. It underscores neonatal mortality as a critical healthcare indicator and highlights disparities by age, gender, and location, stressing the need for improved healthcare services.",
    "This highlights the decline in infant mortality rates, noting progress in reducing these rates while addressing persistent gender and regional disparities. It emphasizes the importance of enhancing healthcare access and education to continue improving infant health outcomes.",
    "Under-five mortality rates are a key measure of child health, with variations by gender, location, and healthcare access. Despite overall declines, disparities remain, particularly in rural areas and among children of younger or older mothers, highlighting the need for targeted healthcare improvements.",
    "The highlights essential antenatal care services, such as monitoring blood pressure and offering dietary guidance, that contribute to safe childbirth and improved maternal and newborn health. It emphasizes the importance of skilled care and timely interventions during pregnancy.",
    "The increasing trend of institutional births reflects improvements in maternal and newborn care. While most deliveries occur in health facilities, challenges like cost and transportation barriers remain, impacting some women's access to institutional deliveries.",
    "The highlights the role of skilled healthcare providers in ensuring safe childbirth, showing that most deliveries are attended by professionals. This is crucial for reducing mortality rates and emphasizes the importance of antenatal care in improving maternal and child health.",
    "This shows widespread awareness of COVID-19 among people aged 15 to 49, with variations by age group. It highlights the role of media and social networks in disseminating information about the virus, which is essential for effective public health responses.",
    "The report reveals that men in Nepal primarily rely on family, friends, and media for information about COVID-19. It highlights their awareness of the virus and its prevention, emphasizing the influence of personal networks and media in health communication strategies.",
    "The passage examines the reproductive history and fertility planning among women aged 15-49, noting trends in total fertility rate and age-specific fertility rates. It highlights progress in reducing unwanted births and variations across demographic groups, reflecting changes in reproductive behaviors.",
    "This text discusses human fertility trends, focusing on the median age of first birth, family size, and the impact of delayed childbirth on women's health and opportunities. It underscores the importance of understanding these factors for effective family planning and reproductive health services.",
    "The passage addresses adolescent reproductive health, noting high pregnancy rates among 15-19-year-olds. It discusses the median age at first birth and challenges related to early pregnancies, emphasizing the need for targeted policies and education to address early childbearing issues.",
    "This indicator highlights the prevalence of stunting, underweight, wasting, and overweight among children under five. It emphasizes stunting as a serious growth issue and calls for urgent interventions to address malnutrition and improve children's health outcomes.",
    "The data shows a significant decrease in childhood wasting rates, reflecting progress in addressing acute undernutrition. It provides insights into stunting and underweight trends, stressing the need for continued efforts to improve nutrition and healthcare access.",
    "The report highlights ongoing concerns about undernutrition among children under five, noting improvements in stunting and underweight rates but emphasizing the need for further action to enhance nutrition and health outcomes for children.",
    "This text focuses on the prevalence of mental health issues among women aged 15 and older, including anxiety and depression. It highlights the disparities based on age, education, and socioeconomic status, underscoring the need for targeted mental health interventions.",
    "It examines the women aged 15 and above who experience significant disabilities affecting essential activities. This highlights the impact of disabilities on women's daily lives and the need for improved support and accessibility.",
    "This indicator reveals that many adult men in Nepal face significant challenges with basic functions like seeing, hearing, and walking. It emphasizes the need for targeted programs to improve quality of life and address these disabilities in the male population.",
    "The text addresses high prevalence of anxiety symptoms among women aged 15-49, based on international benchmarks. It underscores the importance of mental health awareness and targeted interventions to address this issue effectively.",
    "This entry reveals a high prevalence of anxiety among men aged 15-49, highlighting its severity and the need for comprehensive mental health management and support. It emphasizes the importance of addressing anxiety to improve overall well-being in this demographic.",
    "It discusses the prevalence of depression among men aged 15 and older, emphasizing the need for consistent definitions and better management strategies. This highlights the importance of addressing depression through targeted support and interventions.",
    "It deals with family planning services where  many women express a desire to avoid or delay pregnancy, only small number of women use modern contraceptives. It underscores the need for improved access to family planning services.",
    "It highlights the married women who have the ongoing challenges, barriers and the needs for expanded access to effective contraceptive methods.",
    "This measures the women aged 15 to 49 who  reveals a critical gap in meeting family planning needs. Despite many wanting to delay or limit childbirth, only just over half use modern contraceptives, highlighting the need for better access and awareness of family planning services.",
    "it deals with women aged 15 to 49 who suffered physical violence from teenage years and notes variations in abuse rates by ethnicity and region.",
    "It highlights the prevalence of hypertension among men aged 15 and older, which increases the risk of serious health issues such as cardiovascular diseases and stroke. This underscores the importance of managing hypertension to reduce associated health risks."
]


indicators_with_percentage_list=[
    "children who are fully vaccinated against all basic antigens (%)",
    "children who are fully vaccinated according to the national schedule (%)",
    "unmet needs for family planning",
    "children age 6 to 23 months living with their mother fed a minimum acceptable diet (%)",
    "women age 15 to 49 who achieved minimum dietary diversity(%)",
    "household population with access to at least basic drinking water service:(%)",
    "household population with access to at least basic sanitation service(%)",
    "women age 15 to 49 who have and use a bank account or used a mobile phone for financial transaction in the last 12 months (%)",
    "men age 14 to 49 who have and use a bank account or used a mobile phone for financial transaction in the last 12 months (%)",
    "women age 15 to 49 who have ever had a husband or intimate partner who have experienced violence by any husband or intimate partner in the last 12 months (%)",
    "married women age 15 to 49 who participate in household decision(%)",
    "neonatal mortality",
    "infant mortality",
    "Under-five mortality",
    "Antenatal care (ANC) from a skilled provider",
    "births delivered in a health facility (%)",
    "Births assisted by a skilled provider (%)",
    "Women age 15-49 who have heard of COVID-19 (%)",
    "Men age 15-49 who have heard of COVID-19 (%)",
    "Total Fertility Rate (number of children per woman)",
    "Median age at first birth women age 25-49 (years)",
    "Women age 15-19 who have ever been pregnant (%)",
    "Children under age five who are stunted (%)",
    "Children under age five who are wasted (%)",
    "Children under age five who are underweight (%)",
    "Women age 15 and above with hypertension (%)",
    "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "men age 15 to 49 with symptoms of depression according to international cutoffs13(%)",
    "current use of any method of family planning(%)",
    "current use of a modern methods of family planning(%)",
    "Demand satisfied by modern methods of family planning(%)",
    "women age 15-49 who have experienced physical violence since age 15(%)",
    "Men age 15 and above with hypertension"
    ]

# Load the T5 model and tokenizer for cross-attention
t5_tokenizer = T5Tokenizer.from_pretrained("t5-small")
t5_model = T5ForConditionalGeneration.from_pretrained("t5-small")

# Load a character-level embedding model (BERT)
bert_tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
bert_model = BertModel.from_pretrained("bert-base-uncased")

# Function to get embeddings using BERT
def get_embeddings(text, tokenizer, model):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1)

# Compute cosine similarity between vectors
def cosine_similarity(vec1, vec2):
    return torch.nn.functional.cosine_similarity(vec1, vec2).item()

# Compute embeddings for the phrase and paragraphs using self-attention (BERT)
phrase_embedding = get_embeddings(phrase, bert_tokenizer, bert_model)
paragraph_embeddings = [get_embeddings(paragraph, bert_tokenizer, bert_model) for paragraph in paragraphs]

# Compute similarity scores
similarity_scores = [cosine_similarity(phrase_embedding, paragraph_embedding) for paragraph_embedding in paragraph_embeddings]

# Find the paragraph with the highest similarity score for self-attention
best_self_attention_idx = similarity_scores.index(max(similarity_scores))
best_self_attention_paragraph = paragraphs[best_self_attention_idx]

# Cross-attention step with T5
cross_attention_scores = []
for paragraph in paragraphs:
    input_text = f"match: {phrase} context: {paragraph}"
    input_ids = t5_tokenizer.encode(input_text, return_tensors="pt")
    output = t5_model.generate(input_ids, max_length=50, return_dict_in_generate=True, output_scores=True)
    
    # Using the mean of output scores as the cross-attention score
    cross_attention_score = torch.mean(output.scores[0]).item()
    cross_attention_scores.append(cross_attention_score)

# Normalize the self-attention and cross-attention scores
max_self_attention_score = max(similarity_scores)
max_cross_attention_score = max(cross_attention_scores)

normalized_self_attention_scores = [score / max_self_attention_score for score in similarity_scores]
normalized_cross_attention_scores = [score / max_cross_attention_score for score in cross_attention_scores]

# Assign weights to each score type
weight_self_attention = 0.5
weight_cross_attention = 0.5

# Combine the normalized scores
combined_scores = [
    (weight_self_attention * norm_self) + (weight_cross_attention * norm_cross)
    for norm_self, norm_cross in zip(normalized_self_attention_scores, normalized_cross_attention_scores)
]

# Find the index of the best combined score
best_combined_index = combined_scores.index(max(combined_scores))
best_paragraph = paragraphs[best_combined_index]

# Output results
print("Original Phrase:", phrase)
print("Best Matching Paragraph:", best_paragraph)
print("Best Combined Score:", max(combined_scores))
