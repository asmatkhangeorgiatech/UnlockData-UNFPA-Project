#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 15:35:29 2024
This is the API for Nepal UNFPA Project.

@author: asmat
"""


from langchain.output_parsers import ResponseSchema, StructuredOutputParser
import json
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
import re
## This is another Asmat Attempt
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pymysql
import pandas as pd
from sqlalchemy import create_engine
from fastapi.middleware.cors import CORSMiddleware
import os
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
from langchain import LLMChain




# # Set environment variables if needed
# os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# Initialize the language model
llm = ChatOllama(model="codestral", temperature=0, host="http://localhost:11434")

# Define the entities
indicator_field = ResponseSchema(
    name="indicator", 
    description="""An indicator is a specific metric used to measure and track the health, economic, or demographic characteristics\
        of a population. Indicators are used in surveys and data collection to provide insights into various aspects of public health,\
            socioeconomic status, and population dynamics. They are crucial for assessing the performance and impact of policies\
                and programs, identifying trends, and making data-driven decisions.\

The following indicators are used to gauge these aspects:

Antenatal care (ANC) from a skilled provider
Births assisted by a skilled provider (%)
Births delivered in a health facility (%)
Children age 6-23 months living with their mother fed a minimum acceptable diet (%)
Children under age five who are stunted (%)
Children under age five who are underweight (%)
Children under age five who are wasted (%)
Children who are fully vaccinated according to the national schedule (%)
Children who are fully vaccinated against all basic antigens (%)
Current use of a modern method of family planning (%)
Current use of any method of family planning (%)
Demand satisfied by modern methods of family planning (%)
Household population with access to at least basic drinking water service (%)
Household population with access to at least basic sanitation service (%)
Infant mortality
Married women age 15-49 who participate in household decisions (%)
Median age at first birth women age 25-49 (years)
Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
Men age 15-49 who have heard of COVID-19 (%)
Men age 15-49 with hypertension (%)
Men age 15-49 with symptoms of anxiety according to international cutoffs (%)
Men age 15-49 with symptoms of depression according to international cutoffs (%)
Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
Neonatal mortality
Total Fertility Rate (number of children per woman)
Under-five mortality
Unmet need for family planning
Women age 15-19 who have ever been pregnant (%)
Women age 15-49 who achieved minimum dietary diversity (%)
Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months (%)
Women age 15-49 who have experienced physical violence since age 15 (%)
Women age 15-49 who have heard of COVID-19 (%)
Women age 15-49 with hypertension (%)
Women age 15-49 with symptoms of anxiety according to international cutoffs (%)
Women age 15-49 with symptoms of depression according to international cutoffs (%)
Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
These indicators help to monitor and evaluate the effectiveness of health and socioeconomic interventions and to inform policy decisions. """
)
province_field = ResponseSchema(
    name="province", 
    description="a province is one of the seven administrative divisions of the country. \
        These provinces are key administrative units responsible for coordinating regional governance,\
            development, and public services. Each province has its own government, which is tasked with \
                implementing national policies and managing local affairs within its jurisdiction. \
                    The province list includes seven distinct regions:\
Bagmati: Known for its vibrant culture and bustling capital city.\
Gandaki: A region celebrated for its beautiful landscapes and trekking opportunities.\
Karnali: Renowned for its remote and rugged terrain, offering pristine natural beauty.\
Koshi: Famous for its fertile plains and diverse ecosystems.\
Lumbini: The birthplace of Buddha, a place of historical and spiritual significance.\
Madhesh: Characterized by its flat terrain and rich agricultural land.\
Sudurpashchim: The far-western region known for its unique cultural heritage and natural resources.\
These provinces collectively represent the diverse geographical and cultural landscape of the area."
)
lookup_field = ResponseSchema(
    name="lookup", 
    description="Lookups are the specific items or values within each lookup group.\
        They represent the individual elements or choices that fall under each category of \
            a lookup group.Under the lookup group Residence, the lookups might include Urban and Rural. \
                Under  the lookup group Ecological zone, the lookups are Mountain, Hill, Terai,Under the \
                    lookup group Residence, the lookups are Urban, Rural,nder the lookup group Wealth Quintile, \
                        the lookups are Lowest, Second, Middle, Fourth, Highest,Under the lookup group Age,\
                        the lookups are <5, 5-9, 10-14, 15-19,20–24, 25–29, 30–34, 35–39, 40–44, 45–49, 50–54, \
                            55–59, 60–64, 65–69, 70–74, 75–79, 80+, Under the lookup group Education, the lookups\
                                are No education, Basic education(1-8), Secondary Education(9-12), More than secondary(13 and above),\
                                    Under the lookup group of Ethnic Group, the lookups are Brahmin/Chhetri, Dalit, Janajati, Madhesi,\
                                        Muslim. LUnder the lookup group of Mother's Education, the lookups are No education,\
    Basic education, Secondary education, More than secondary. Under the lookup group of Child Sex, the lookups are Male, Female. \
        Under the lookup group of Mother's Age, the lookups are <20, 20-34, 35-49. Under the lookup group of Birth Order, \
            the lookups are 1, 2-3, 4-5, 6+. Under the lookup group of Antenatal Care Visits, the lookups are None, 1-3, 4+. \
                Under the lookup group of Sex, the lookups are Male, Female. Under the lookup group of Vaccination card, the \
                    lookups are seen, not seen or no longer has. Under the lookup group of Age Group, the lookups are 15-49,\
                        20-29, 30-39, 40-49. Under the lookup group of Age in month, the lookups are <6, 6-11, 6-8, 9-11, 12-23, \
                            12-18, 18-23, 24-35, 36-47, 48-59. For the lookup groups of birth interval in months, the\
                                lookups are <24, 24-47, 48+. Under the lookup groups of size at birth, the lookups are very small,\
   small, average or larger. under the lookup groups of  Mothers nutritional status, the lookups are thin, normal,\
       overweigth/obese. Under lookup groups of Maternity status the lookups are pregnant, not pregnant.\
           Under the lookup groups under Employment (last 12 months), the lookups are Not employeed, Employeed for cash, \
               Employeed not for cash. Under the lookup groups of Number of living children, the lookups are 0, 1-2, 3-4, 5+.\
                   Under the lookup groups of Marital status, the lookup groups are never married, never had untimate partner, \
                       Ever had intimate partner, Ever married, married/ living together, Divorced/separated/widowed,\
                           Divorced, Widowed. Under the lookup groups of Nutritional status, the lookups are Thin, Normal, \
                               Overweight, Obese, Not weighed or measured."
 
)
lookup_group_field = ResponseSchema(
    name="lookup_group", 
    description="Lookup groups are categories or classifications that help organize related items or characteristics. They act as a high-level grouping for different types of data or attributes.\
such as Ethnic group,Residence,Ecological zone,Education,Wealth quintile,Age Group,Mothers Education,Child Sex, Birth order, Mothers Age at birth, Antenatal care visits, Sex, Vaccination card are examples of lookup groups."
)

# Schema with all entities to be extracted
ner_output_schema_parser = StructuredOutputParser.from_response_schemas(
    [indicator_field, province_field, lookup_field, lookup_group_field]
)
ner_output_schema = ner_output_schema_parser.get_format_instructions()






prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Given the text below, identify the entities according to the following categories:\
            Entities to identify: Indicator, Province, Lookup, Lookup Group\
\
            << FORMATTING >>\
            {format_instructions}\
\
            << OUTPUT >>\
            indicaor:[],\
            province:[],\
            lookup_group:[],\
            lookup:[]"
        ),
        ("human", "{input}"),
    ]
)

chain = prompt | llm
response = chain.invoke(
    {
        "format_instructions": ner_output_schema,
        "input": "What is the infant mortality rate in the last decay at Gandaki province?",
    }
)




def extract_json(text):
    # Find the JSON part in the text using a regular expression
    json_match = re.search(r'\{.*?\}', text, re.DOTALL)
    if json_match:
        return json_match.group()
    else:
        raise ValueError("No JSON object found in the text")



def clean_json(text):
    # Convert the input to a string if it's not already
    if not isinstance(text, str):
        text = json.dumps(text)
    
    # Remove any unwanted SQL wrappers if present
    if text.lstrip().startswith("```json"):
        text = text.lstrip()[len("```json"):].strip()
    
    if text.rstrip().endswith("```"):
        text = text.rstrip()[:-len("```")].strip()
    
    # Remove comments (if any)
    text = re.sub(r'//.*', '', text)  # Removes single-line comments
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)  # Removes multi-line comments
    
    # Remove trailing commas before closing braces or brackets
    text = re.sub(r',\s*([}\]])', r'\1', text)
    
    # Ensure property names and string values are enclosed in double quotes
    text = re.sub(r"(\w+):", r'"\1":', text)  # Convert unquoted property names to quoted names
    text = re.sub(r"(\s\w+)\s*:", r'"\1":', text)  # Handle property names with leading whitespace

    # Attempt to load the cleaned text as JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON format: {e}")





# Extract the JSON from the input text
json_text = extract_json(response.content)

# Clean and validate the extracted JSON
try:
    valid_json = clean_json(json_text)
    print("Successfully cleaned and validated JSON:")
    print(json.dumps(valid_json, indent=4))  # Print formatted JSON
except ValueError as e:
    print(e)


import json


def remove_sql_wrappers(text):
    # Check if the input is a string
    if isinstance(text, str):
        # Remove the ```json wrapper from the beginning (with optional spaces)
        if text.lstrip().startswith("```json"):
            text = text.lstrip()[len("```json"):].strip()

        # Remove the ``` wrapper from the end (with optional spaces)
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-len("```")].strip()
    else:
        # If the input is a dictionary, convert it to a JSON string
        text = json.dumps(text)

    return text

def clean_invalid_json(text):
    # Remove comments (any text after // or /* */)
    text = re.sub(r'//.*', '', text)  # Removes single-line comments
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)  # Removes multi-line comments
    
    # Remove trailing commas before closing braces or brackets
    text = re.sub(r',\s*([}\]])', r'\1', text)

    return text

# Get the cleaned text without SQL wrappers
cleaned_text = remove_sql_wrappers(valid_json)

# Further clean the JSON text for invalid `null` cases and general JSON format issues
cleaned_text = clean_invalid_json(cleaned_text)

print('cleaned text:', cleaned_text)

# Convert JSON string to dictionary
try:
    extracted_entities = json.loads(cleaned_text)
    print("Successfully decoded JSON")
    print(extracted_entities)
except json.JSONDecodeError as e:
    print(f"Error decoding JSON: {e}")
    extracted_entities = {}



# Predefined lists for entity matching
indicators_list = [
    "Antenatal care (ANC) from a skilled provider",
    "Births assisted by a skilled provider (%)",
    "Births delivered in a health facility (%)",
    "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
    "Children under age five who are stunted (%)",
    "Children under age five who are underweight (%)",
    "Children under age five who are wasted (%)",
    "Children who are fully vaccinated according to the national schedule (%)",
    "Children who are fully vaccinated against all basic antigens (%)",
    "Current use of a modern method of family planning (%)",
    "Current use of any method of family planning (%)",
    "Demand satisfied by modern methods of family planning (%)",
    "Household population with access to at least basic drinking water service (%)",
    "Household population with access to at least basic sanitation service (%)",
    "Infant mortality",
    "Married women age 15-49 who participate in household decisions (%)",
    "Median age at first birth women age 25-49 (years)",
    "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
    "Men age 15-49 who have heard of COVID-19 (%)",
    "Men age 15-49 with hypertension (%)",
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Men age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Neonatal mortality",
    "Total Fertility Rate (number of children per woman)",
    "Under-five mortality",
    "Unmet need for family planning",
    "Women age 15-19 who have ever been pregnant (%)",
    "Women age 15-49 who achieved minimum dietary diversity (%)",
    "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
    "Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)",
    "Women age 15-49 who have experienced physical violence since age 15 (%)",
    "Women age 15-49 who have heard of COVID-19 (%)",
    "Women age 15-49 with hypertension (%)",
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Antenatal care (ANC) from a skilled provider",
    "Births assisted by a skilled provider (%)",
    "Children who are fully vaccinated against all basic antigens (%)",
    "Children who are fully vaccinated according to the national schedule (%)",
    "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
    "Women age 15-49 who achieved minimum dietary diversity (%)",
    "Household population with access to at least basic sanitation service (%)",
    "Married women age 15-49 who participate in household decisions (%)",
    "Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)",
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Men age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Women age 15 and above with hypertension (%)",
    "Men age 15 and above with hypertension (%)"
]

province_list = [
    "Bagmati",
    "Gandaki",
    "Karnali",
    "Koshi",
    "Lumbini",
    "Madhesh",
    "Sudurpashchim"
]


lookup_groups_list = [
    "Ethnic group",
    "Residence",
    "Ecological zone",
    "Education",
    "Wealth quintile",
    "5-Year Age Group",
    "Mothers Education",
    "Child Sex",
    "Birth order",
    "Mothers Age at birth",
    "Antenatal care visits",
    "Sex",
    "Vaccination card"
]

lookups_list = [
    "Brahmin/Chhetri",
    "Dalit",
    "Janajati",
    "Madhesi",
    "Muslim",
    "Urban",
    "Rural",
    "Mountain",
    "Hill",
    "Terai",
    "No education",
    "Basic education (1–8)",
    "Secondary (9–12)",
    "More than secondary (13 and above)",
    "Lowest",
    "Second",
    "Middle",
    "Fourth",
    "Highest",
    "<5",
    "5–9",
    "10–14",
    "15–19",
    "20–24",
    "25–29",
    "30–34",
    "35–39",
    "40–44",
    "45–49",
    "50–54",
    
]

{
  "lookup_groups": [
    {
      "group": "Ecological zone",
      "lookups": [
        "Mountain",
        "Hill",
        "Terai"
      ]
    },
    {
      "group": "Residence",
      "lookups": [
        "Urban",
        "Rural"
      ]
    },
    {
      "group": "Wealth Quintile",
      "lookups": [
        "Lowest",
        "Second",
        "Middle",
        "Fourth",
        "Highest"
      ]
    },
    {
      "group": "Age",
      "lookups": [
        "<5",
        "5-9",
        "10-14",
        "15-19",
        "20–24",
        "25–29",
        "30–34",
        "35–39",
        "40–44",
        "45–49",
        "50–54",
        "55–59",
        "60–64",
        "65–69",
        "70–74",
        "75–79",
        "80+"
      ]
    },
    {
      "group": "Education",
      "lookups": [
        "No education",
        "Basic education (1-8)",
        "Secondary Education (9-12)",
        "More than secondary (13 and above)"
      ]
      
    },
    {
     "group": "Residence",
     "lookups": [
       "Urban",
       "Rural"
     ]
   },
   {
     "group": "Ethnic Group",
     "lookups": [
       "Brahmin/Chhetri",
       "Dalit",
       "Janajati",
       "Madhesi",
       "Muslim"
     ]
   },
   {
     "group": "Mother's Education",
     "lookups": [
       "No education",
       "Basic education",
       "Secondary education",
       "More than secondary"
     ]
   },
   {
     "group": "Child Sex",
     "lookups": [
       "Male",
       "Female"
     ]
   },
   {
     "group": "Mother's Age",
     "lookups": [
       "<20",
       "20-34",
       "35-49"
     ]
   },
   {
     "group": "Birth Order",
     "lookups": [
       "1",
       "2-3",
       "4-5",
       "6+"
     ]
   },
   {
     "group": "Antenatal Care Visits",
     "lookups": [
       "None",
       "1-3",
       "4+"
     ]
   },
   {
     "group": "Sex",
     "lookups": [
       "Male",
       "Female"
     ]
   },
   {
     "group": "    ",
     "lookups": [
       "Seen",
       "Not seen or no longer has"
     ]
   },
   {
     "group": "Age Group",
     "lookups": [
       "15-49",
       "20-29",
       "30-39",
       "40-49"
     ]
   },
   {
     "group": "Age in Month",
     "lookups": [
       "<6",
       "6-11",
       "6-8",
       "9-11",
       "12-23",
       "12-18",
       "18-23",
       "24-35",
       "36-47",
       "48-59"
     ]
   },
   {
     "group": "Birth Interval in Months",
     "lookups": [
       "<24",
       "24-47",
       "48+"
     ]
   },
   {
     "group": "Size at Birth",
     "lookups": [
       "Very small",
       "Small",
       "Average or larger"
     ]
   },
   {
     "group": "Mother's Nutritional Status",
     "lookups": [
       "Thin",
       "Normal",
       "Overweight/Obese"
     ]
   },
   {
     "group": "Maternity Status",
     "lookups": [
       "Pregnant",
       "Not pregnant"
     ]
   },
   {
     "group": "Employment (Last 12 Months)",
     "lookups": [
       "Not employed",
       "Employed for cash",
       "Employed not for cash"
     ]
   },
   {
     "group": "Number of Living Children",
     "lookups": [
       "0",
       "1-2",
       "3-4",
       "5+"
     ]
   },
   {
     "group": "Marital Status",
     "lookups": [
       "Never married",
       "Never had intimate partner",
       "Ever had intimate partner",
       "Ever married",
       "Married/living together",
       "Divorced/separated/widowed",
       "Divorced",
       "Widowed"
     ]
   },
   {
     "group": "Nutritional Status",
     "lookups": [
       "Thin",
       "Normal",
       "Overweight",
       "Obese",
       "Not weighed or measured"
     ]
   }
  ]
}


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


# Vectorizer
vectorizer = TfidfVectorizer()

# Fit the vectorizer on combined predefined lists
all_lists = indicators_list + province_list + lookups_list + lookup_groups_list
vectorizer.fit(all_lists)

# Transform the predefined lists
indicator_vectors = vectorizer.transform(indicators_list)
province_vectors = vectorizer.transform(province_list)
lookup_vectors = vectorizer.transform(lookups_list)
lookup_group_vectors = vectorizer.transform(lookup_groups_list)

def match_entities(extracted_entities):
    matched_entities = {
        "Indicators": [],
        "Provinces": [],
        "Lookups": [],
        "Lookup_groups": []
    }
    
    def get_best_match(entity, vectors, list_items):
        if not entity:
            return None, 0
        entity_vector = vectorizer.transform([entity])
        similarities = cosine_similarity(entity_vector, vectors)
        max_sim_index = np.argmax(similarities)
        max_sim_value = similarities[0, max_sim_index]
        return list_items[max_sim_index], max_sim_value

    # Initialize a dictionary to keep track of the best match for each entity type
    best_matches = {
        "Indicators": (None, -1),  # Tuple of (best match, highest similarity score)
        "Provinces": (None, -1),
        "Lookups": (None, -1),
        "Lookup_groups": (None, -1)
    }

    for entity_type, entity_list in extracted_entities.items():
        for entity in entity_list:
            if entity_type == "indicator":
                matched, sim = get_best_match(entity, indicator_vectors, indicators_list)
                if sim > best_matches["Indicators"][1]:  # Update if this is the best match so far
                    best_matches["Indicators"] = (matched, sim)
            elif entity_type == "province":
                matched, sim = get_best_match(entity, province_vectors, province_list)
                if sim > best_matches["Provinces"][1]:
                    best_matches["Provinces"] = (matched, sim)
            elif entity_type == "lookup":
                matched, sim = get_best_match(entity, lookup_vectors, lookups_list)
                if sim > best_matches["Lookups"][1]:
                    best_matches["Lookups"] = (matched, sim)
            elif entity_type == "lookup_group":
                matched, sim = get_best_match(entity, lookup_group_vectors, lookup_groups_list)
                if sim > best_matches["Lookup_groups"][1]:
                    best_matches["Lookup_groups"] = (matched, sim)

    # Only add the best matches to matched_entities if they have a score above 0.7
    for entity_type, (best_match, best_sim) in best_matches.items():
        if best_sim > 0.7:
            matched_entities[entity_type].append(best_match)
                    
    return matched_entities



# Match entities with the predefined lists
def convert_to_lists(extracted_entities):
    converted_entities = {}
    for key, value in extracted_entities.items():
        if value is None:
            # Handle None values as empty lists
            converted_entities[key] = []
        elif isinstance(value, list):
            # If it's already a list, use it as is
            converted_entities[key] = value
        else:
            # Convert single values to a list
            converted_entities[key] = [value]
    return converted_entities



converted_entities = convert_to_lists(extracted_entities)
print('converted entities',converted_entities)

matched_entities = match_entities(converted_entities)
print('matched entities',matched_entities)




# Extract values from the dictionary
indicator_names = matched_entities.get('indicators', [])
province_names = matched_entities.get('provinces', [])
lookup_group_names = matched_entities.get('lookup_groups', [])
lookup_names = matched_entities.get('lookups', [])

# Helper function to format lists for SQL IN clause
def format_for_sql(names_list):
    if names_list:
        return ', '.join(f"'{name}'" for name in names_list)
    return ''  # Return an empty string if the list is empty

# Construct SQL conditions with handling for empty lists
indicator_condition = f"i.indicator IN ({format_for_sql(indicator_names)})" if indicator_names else "1=1"
province_condition = f"p.province IN ({format_for_sql(province_names)})" if province_names else "1=1"
lookup_group_condition = f"lg.lookup_group IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
lookup_condition = f"l.lookup IN ({format_for_sql(lookup_names)}) AND lg.lookup_group_id = l.lookup_group_id" if lookup_names else "1=1"

# Construct the final SQL query using f-strings
sql_query = f"""
WITH filtered_data AS (
    SELECT 
        id.* 
    FROM 
        indicators_data id
    LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
    LEFT JOIN provinces p ON id.province_id = p.province_id
    LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
    LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
    WHERE 
        {indicator_condition} AND
        ({province_condition}) AND
        ({lookup_group_condition}) AND
        ({lookup_condition})
)
SELECT 
    i.indicator,
    COALESCE(p.province, 'National') AS province,
    COALESCE(lg.lookup_group, 'N/A') AS lookup_group,
    COALESCE(l.lookup, 'N/A') AS lookup,
    id.indicator_data AS value,
    id.survey_source_id,
    id.year
    
FROM 
    filtered_data id
LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
LEFT JOIN provinces p ON id.province_id = p.province_id
LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
ORDER BY 
    i.indicator,
    p.province,
    lg.lookup_group,
    l.lookup;
"""

print(sql_query)
