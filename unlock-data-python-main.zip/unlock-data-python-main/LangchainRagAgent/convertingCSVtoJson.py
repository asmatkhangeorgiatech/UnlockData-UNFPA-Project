#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 19:37:14 2024

@author: asmat
"""

import csv
import json
import pandas as pd

def csv_to_json(csv_file_path):
   # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file_path)

    # Convert DataFrame to a list of dictionaries (JSON format)
    data = df.to_dict(orient='records')
    
    return data



csv_file_path = 'DomesticVoilance.csv'
json_data = csv_to_json(csv_file_path)

json_file_path = 'query_request_data.json'
with open(json_file_path, 'w') as json_file:
        json.dump(json_data, json_file, indent=4)