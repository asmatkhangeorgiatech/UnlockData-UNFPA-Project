#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 16:32:41 2024

@author: asmat
"""

import pandas as pd

# Read data from CSV file
df = pd.read_csv('assets/9_470/1728635859_All_columns_dv_2.csv')

# Function to calculate percentages independently for each variable
def calc_independent_percentages(df, cell_vars, col_vars, weight):
    results = {}
    
    # Loop through each variable in col_vars to calculate percentages independently
    for col_var in col_vars:
        # Create a pivot table for the current column
        pivot_table = df.pivot_table(
            values=weight,
            index=cell_vars,
            columns=col_var,
            aggfunc='sum',
            margins=True,
            margins_name='All'
        )
        
        # Calculate row totals for each specific column, excluding 'All'
        row_totals = pivot_table.loc[:, pivot_table.columns != 'All'].sum(axis=1).drop('All')
        
        # Calculate percentages for the current column (independently)
        percentages = pivot_table.loc[:, pivot_table.columns != 'All'].div(row_totals, axis=0) * 100
        
        # Calculate overall percentage for the 'All' row
        overall_totals = pivot_table.loc['All', pivot_table.columns != 'All']
        overall_percentages = (overall_totals / overall_totals.sum() * 100).values
        
        # Insert the 'All' row correctly
        percentages.loc['All'] = overall_percentages

        # Store the result for the current column
        results[col_var] = percentages.round(1)
    
    # Combine the results for all columns
    combined = pd.concat(results, axis=1)
    
    return combined


# Define the variables
cell_vars = ['province']
col_vars = ['dv_phy', 'dv_phy_12m', 'dv_phy_preg', 'dv_viol_type']  # You can add more columns here if needed
weight = 'dwt'

# Calculate the custom table with independent percentages
custom_table = calc_independent_percentages(df, cell_vars, col_vars, weight)

# Print the table (or save it to a file)
print(custom_table['dv_viol_type']['Physical only'])
#print(custom_table['dv_phy_12m'][1])
#print("Physical Violence during pregnancy - Rural:", custom_table['dv_phy_preg'][1]['rural'])