#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 11:41:56 2024

This is a Langchain Rag Agent built for NEpal Unlocking Data Project.
This is the First text version.

@author: asmat
"""

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import SKLearnVectorStore
from langchain_nomic.embeddings import NomicEmbeddings
from langchain_community.document_loaders import CSVLoader
from langchain_core.messages import HumanMessage, SystemMessage
from langchain.vectorstores import Chroma

#from langchain_community.document_loaders.csv_loader import CSVLoader



import pandas as pd
import glob

#### Open API key
import openai
from langchain.output_parsers import StructuredOutputParser
from langchain.output_parsers import ResponseSchema
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv
import os
from langchain.chat_models import ChatOpenAI

# # Initialize ChatOpenAI with OpenAI model
# load_dotenv()  # Load environment variables from .env file
# openai.api_key = os.getenv("OPENAI_API_KEY")
# llm = ChatOpenAI(model="gpt-4", temperature=0)

# function to call OpenAI APIs

### LLM
from langchain_ollama import ChatOllama
local_llm = 'llama3.2:3b'
llm = ChatOllama(model=local_llm, temperature=0)
llm_json_mode = ChatOllama(model=local_llm, temperature=0, format='json')






# # List of CSV file paths
# csv_files = [
#     'path_to_csv_file1.csv',
#     'path_to_csv_file2.csv',
#     'path_to_csv_file3.csv',
# ]
csv_files = [
   './new_modified.csv',
    ]

# Load documents from all CSV files
all_documents = []
for csv_file in csv_files:
    loader = CSVLoader(file_path=csv_file)
    print("I am after loader")
    documents = loader.load()
   
    print(" I am after documents")
    all_documents.extend(documents)

print("I am here")

# Create a vector store using ChromaDB
vectorstore = Chroma.from_documents(
    documents=all_documents,
    embedding=NomicEmbeddings(model="nomic-embed-text-v1.5", inference_mode="local"),
)




# # Now we have a vector store containing the embeddings of each row from the CSV

# # Create a retriever from the vector store
# retriever = vectorstore.as_retriever(k=3)  # `k` specifies how many results to retrieve

# # Example natural language query
# query = "What is the percentage of women who experienced violence in the last 12 months?"

# # Retrieve the most relevant documents (rows) from the vector store
# retrieved_docs = retriever.get_relevant_documents(query)

# # Display the retrieved documents (rows)
# for doc in retrieved_docs:
#     print(doc.page_content)




from langchain.chains.query_constructor.base import AttributeInfo
from langchain.retrievers.self_query.base import SelfQueryRetriever
from langchain_openai import ChatOpenAI
from langchain.retrievers.self_query.chroma import ChromaTranslator

# residence: STRING# residence of the study participants. Urban or Rural.
# dv_phy: BOOLEAN# experience of physical violence by the participants.
# dv_phy_Yes2m: BOOLEAN# experience of physical violence by the participants in the last 12 months.
# dv_phy_preg: STRING# experience of physical violence during pregnancy
# dv_sex: BOOLEAN# experience of sexual violence by the participants. 
# dv_sex_Yes2m: BOOLEAN# experience of sexualviolence by the participants in the last 12 months.
# agegroup: STRING# age groups of the study participants
# province: STRING# province where study participants reside
# edulevel: STRING# educational level of study participants
# dweight: FLOAT# sample weights. Any calculation should be preceded by weighting.

metadata_field_info = [
    AttributeInfo(
        name="﻿CASEID",
        description="Case number for identification",
        type="integer",
    ),
    AttributeInfo(
        name="residence",
        description="residence of the study participants. Urban or Rural.",
        type="string",
    ),
    AttributeInfo(
        name="dv_phy",
        description="experience of physical violence by the participants.",
        type="boolean",
    ),
    AttributeInfo(
        name="dv_phy_12m",
        description="experience of physical violence by the participants in the last 12 months.",
        type="boolean",
    ),
    AttributeInfo(
        name="dv_phy_preg",
        description="experience of physical violence during pregnancy",
        type="string",
    ),
    AttributeInfo(
        name="dv_sex",
        description="experience of sexual violence by the participants.",
        type="boolean",
    ),
    AttributeInfo(
        name="dv_sex_12m",
        description="experience of sexualviolence by the participants in the last 12 months.",
        type="boolean",
    ),
    AttributeInfo(
        name="agegroup",
        description="age groups of the study participants",
        type="string",
    ),
    AttributeInfo(
        name="province",
        description="province where study participants reside",
        type="string",
    ),
    AttributeInfo(
        name="edulevel",
        description="educational level of study participants",
        type="string",
    ),
    AttributeInfo(
        name="dweight",
        description="sample weights. Any calculation should be preceded by weighting.",
        type="float",
    )
    
]

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# Augmented
# TEMPLATE = """\
# You are happy assistant. Use the context provided below to answer the question.

# If you do not know the answer, or are unsure, say you don't know.

# Query:
# {question}

# Context:
# {context}
# """

TEMPLATE = """You are a helpful assistant. Use the context provided below to answer the question.

**Special Instructions for Analysis**:
1. **Simplicity**: Ensure all output is succinct and easy to comprehend for non-technical users. Avoid unnecessary complexity or jargon.
   
2. **Weighting**: Always apply the `dweight` field when calculating statistics to ensure the results are accurate. All statistics must be rounded to two decimal places.

3. **Visual Representation**: Whenever possible, present the results in the form of charts. Ensure charts are clearly labeled, and if percentages are involved, include a `%` sign in the labels.

4. **Descriptive Analysis**: Accompany each chart with a brief, descriptive analysis to explain the insights in plain language, focusing on key takeaways.

5. **Statistical Testing**: When statistical tests are requested, explain the results without technical jargon, keeping the explanation simple and accessible. Only provide in-depth technical details if specifically asked.

6. **Output Formatting**: If you are unsure about the answer, or do not have enough information, clearly state that you don't know.

Query:
{question}

Context:
{context}
"""

rag_prompt = ChatPromptTemplate.from_template(TEMPLATE)

document_content_desription = """The Nepal Demographic and Health Survey (NDHS) is a national survey conducted to collect data on a wide range of health and demographic indicators. The primary goal of the NDHS is to provide detailed information on topics such as population, family planning, maternal and child health, nutrition, and disease prevalence, particularly focusing on HIV/AIDS and malaria.
The NDHS is part of the Demographic and Health Surveys (DHS) Program, which is funded by agencies like the United States Agency for International Development (USAID) and conducted in collaboration with local governmental bodies, typically the Ministry of Health.

Key Objectives of NDHS:
Population & Household Characteristics: Gather information on fertility rates, mortality rates, and migration.
Maternal and Child Health: Assess the availability and quality of maternal care services, vaccination coverage, child nutrition, and infant mortality rates.
Family Planning: Measure the use and unmet need for contraceptives, as well as public knowledge and attitudes towards family planning.
Nutrition: Assess malnutrition and anemia levels, especially among women and children.
HIV/AIDS & Other Diseases: Track knowledge, prevention, and prevalence of diseases like HIV/AIDS and malaria.
Water, Sanitation & Hygiene (WASH): Analyze access to clean drinking water and sanitation facilities.
The data collected through NDHS serves as an important resource for policymakers, researchers, and international agencies to design and implement public health programs, monitor progress towards health-related goals, and inform policy decisions in Nepal.
"""






#embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
#chat_model = ChatOpenAI()

self_query_retriever = SelfQueryRetriever.from_llm(
    llm=llm,
    vectorstore =vectorstore,
    document_contents = document_content_desription,
    metadata_field_info =metadata_field_info,
    verbose = True,
    use_original_query=True,
    structured_query_translator = ChromaTranslator(),
    search_kwargs={'k': 6000}
)
query = "prevalence of physical violence??"
retrieved_docs = self_query_retriever.get_relevant_documents(query)

# Display the retrieved documents (rows)
for doc in retrieved_docs:
    print(doc.page_content)

from langchain_core.runnables import RunnablePassthrough, RunnableParallel
from operator import itemgetter
from langchain_core.output_parsers import StrOutputParser

setup_and_retrieval = RunnableParallel({"question": RunnablePassthrough(), "context": self_query_retriever })
output_parser = StrOutputParser()


self_retrieval_chain = setup_and_retrieval | rag_prompt | llm 


response = self_retrieval_chain.invoke( "prevalence of physical violence?")
print(response)


# ### Generate

# # Prompt
# rag_prompt = """You are an assistant for question-answering tasks. 

# Here is the context to use to answer the question:

# {context} 

# Think carefully about the above context. 

# Now, review the user question:

# {question}

# Provide an answer to this questions using only the above context. 

# Use three sentences maximum and keep the answer concise.

# Answer:"""


# # Post-processing
# def format_docs(docs):
#     return "\n\n".join(doc.page_content for doc in docs)

# # Test
# docs = retriever.invoke(query)
# docs_txt = format_docs(docs)
# rag_prompt_formatted = rag_prompt.format(context=docs_txt, question=query)
# generation = llm.invoke([HumanMessage(content=rag_prompt_formatted)])
# print(generation.content)
