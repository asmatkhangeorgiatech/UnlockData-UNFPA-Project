#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 15:23:46 2024

@author: asmat
"""
import os
import openai
from langchain.agents.agent_types import AgentType
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import pandas as pd
from langchain_openai import OpenAI
from langchain_experimental.llms.ollama_functions import OllamaFunctions



# Initialize ChatOpenAI with OpenAI model
load_dotenv()  # Load environment variables from .env file
openai.api_key = os.getenv("OPENAI_API_KEY")

### LLM
from langchain_ollama import ChatOllama
local_llm = 'qwen2.5-coder:7b'
llm = ChatOllama(model=local_llm, temperature=0.0,num_ctx=16384)
llm_json_mode = ChatOllama(model=local_llm, temperature=0, format='json')


df = pd.read_csv("/home/asmat/LangchainRagAgent/Subset2.csv")

# Define your custom prefix and suffix
custom_prefix = """You are working with a pandas dataframe in Python. The name of the dataframe is df. You should use the tools below to answer the question posed of you:

python_repl_ast: A Python shell. Use this to execute python commands. Input should be a valid python command. When using this tool, sometimes output is abbreviated - make sure it does not look abbreviated before using it in your answer.





**Schema of the dataset:**

residence: STRING# residence of the study participants. Urban or Rural.
dv_phy: BOOLEAN# experience of physical violence by the participants.
dv_phy_12m: BOOLEAN# experience of physical violence by the participants in the last 12 months.
dv_phy_preg: STRING# experience of physical violence during pregnancy
dv_sex: BOOLEAN# experience of sexual violence by the participants. 
dv_sex_12m: BOOLEAN# experience of sexualviolence by the participants in the last 12 months.
agegroup: STRING# age groups of the study participants
province: STRING# province where study participants reside
edulevel: STRING# educational level of study participants
dweight: FLOAT# sample weights. Any calculation should be preceded by weighting.



"""
#custom_prefix = """Answer the following questions as best you can. You have access to the following tools:"""
custom_suffix = """Begin!

Question: {input}
{agent_scratchpad}
Answer:"""





#agent = create_pandas_dataframe_agent(OpenAI(temperature=0), df, verbose=True)
from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import Tool
from langchain_experimental.tools import PythonAstREPLTool
# Initialize the Python REPL Tool
python_repl = PythonREPL()
# You can create the tool to pass to an agent
PythonREPLTool = Tool(
    name="python_repl",
    description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
    func=python_repl.run,
)
agent = create_pandas_dataframe_agent(
    #ChatOpenAI(temperature=0, model="gpt-4"),
    #ChatOllama(model=local_llm, temperature=0),
    #OllamaFunctions(model=local_llm, temperature=0,format="json"),
    ChatOllama(model=local_llm, temperature=0),
    df=df,
    agent_type=AgentType.OPENAI_FUNCTIONS,
    prefix=custom_prefix,
    suffix=custom_suffix,
    include_df_in_prompt=None,
    allow_dangerous_code=True,
    return_intermediate_steps=False,
    verbose=True,
    agent_executor_kwargs={"handle_parsing_errors": True},
    
    
    
)

result = agent.invoke("prevalence of physical violence?")
print(result)



#### We are testing another method
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_experimental.tools import PythonAstREPLTool
# from langchain_core.output_parsers.openai_tools import JsonOutputKeyToolsParser




# tool = PythonAstREPLTool(locals={"df": df})
# llm_with_tool = llm.bind_tools(tools=[tool], tool_choice=tool.name)
# parser = JsonOutputKeyToolsParser(key_name=tool.name, first_tool_only=True)


# df_template = """```python
# {df_name}.head().to_markdown()
# >>> {df_head}
# ```"""
# df_context = "\n\n".join(
#     df_template.format(df_head=_df.head().to_markdown(), df_name=df_name)
#     for _df, df_name in [(df, "df")]
# )

# system = f"""You have access to a number of pandas dataframes. \
# Here is a sample of rows from each dataframe:

# {df_context}

# Given a user question about the dataframes, write the Python code to answer it. \
# Don't assume you have access to any libraries other than built-in Python ones and pandas. \
# Make sure to refer only to the variables mentioned above."""
# prompt = ChatPromptTemplate.from_messages([("system", system), ("human", "{question}")])

# chain = prompt | llm_with_tool 
# chain.invoke(
#     {
#         "question": "provide prevalence of physical violence?"
#     }
# )

