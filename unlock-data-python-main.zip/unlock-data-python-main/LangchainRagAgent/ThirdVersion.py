#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 29 14:11:29 2024

@author: asmat
"""
import os
import openai
from langchain import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from dotenv import load_dotenv
import pandas as pd
import io
import sys
from langchain_experimental.tools import PythonREPLTool

# Load environment variables (OpenAI API key)
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Load CSV into pandas DataFrame
df = pd.read_csv("/home/asmat/LangchainRagAgent/DomesticVoilance.csv")

# Task description from user
question = "What is the percentage of women aged 15-19 who experienced violence in the last 12 months by province?"

# LLM setup (you might be using a local LLM, adjust as needed)
from langchain_ollama import ChatOllama
local_llm = 'codestral:latest'
llm = ChatOllama(model=local_llm, temperature=0.0, num_ctx=32768)

schema_dict = {
    "DomesticVoilance.csv": {
        "caseid": {"type": "str", "description": "This column represents a unique identifier for each respondent or case in the dataset."},
        "residence": {"type": "str", "description": "This column indicates whether the respondent lives in a rural or urban area."},
        "Province": {"type": "str", "description": "This column represents the province where the respondent resides."},
        "edulevel": {"type": "str", "description": "This column refers to the education level of the respondent."},
        "Age": {"type": "str", "description": "This column represents the age of the respondent."},
        "Ethenic": {"type": "str", "description": "This column refers to the ethnic group of the respondent."},
        "marital status": {"type": "str", "description": "This column refers to the marital status of the respondent."},
        "Wealth index": {"type": "str", "description": "This column represents socioeconomic status of the respondent."},
        "Religion": {"type": "str", "description": "This column represents the religion of the respondent."},
        "dv_phy": {"type": "int", "description": "Experienced physical violence since age 15"},
        "dv_phy_12m": {"type": "int", "description": "Experienced physical violence in the past 12 months"},
        "dv_phy_preg": {"type": "int", "description": "Experienced physical violence during pregnancy"},
        "dv_sex": {"type": "int", "description": "Ever experienced sexual violence"},
        "dv_sex_12m": {"type": "int", "description": "Experienced sexual violence in the past 12 months"},
        "dv_sex_age": {"type": "int", "description": "Specific age experienced sexual violence"},
        "dv_phy_only": {"type": "int", "description": "Experienced physical violence only"},
        "dv_sex_only": {"type": "int", "description": "Experienced sexual violence only"},
        "dv_phy_sex_all": {"type": "int", "description": "Experienced physical and sexual violence"},
        "dv_phy_sex_any": {"type": "int", "description": "Experienced physical or sexual violence"},
        "dv_viol_type": {"type": "int", "description": "Experienced physical only, sexual only, or both"},
        "dv_phy_hus_curr": {"type": "int", "description": "Person committing physical violence: current husband/partner"},
        "dv_phy_hus_form": {"type": "int", "description": "Person committing physical violence: former husband/partner"},
        "dv_phy_bf_curr": {"type": "int", "description": "Person committing physical violence: current boyfriend"},
        "dv_phy_bf_form": {"type": "int", "description": "Person committing physical violence: former boyfriend"},
        "dv_phy_father": {"type": "int", "description": "Person committing physical violence: father/step-father"},
        "dv_phy_mother": {"type": "int", "description": "Person committing physical violence: mother/step-mother"},
        "dv_phy_sibling": {"type": "int", "description": "Person committing physical violence: sister or brother"},
        "dv_phy_bychild": {"type": "int", "description": "Person committing physical violence: daughter/son"},
        "dv_phy_other_rel": {"type": "int", "description": "Person committing physical violence: other relative"},
        "dv_phy_mother_inlaw": {"type": "int", "description": "Person committing physical violence: mother-in-law"},
        "dv_phy_father_inlaw": {"type": "int", "description": "Person committing physical violence: father-in-law"},
        "dv_phy_other_inlaw": {"type": "int", "description": "Person committing physical violence: other in-law"},
        "dv_sex_hus_curr": {"type": "int", "description": "Person committing sexual violence: current husband/partner"},
        "dv_sex_hus_form": {"type": "int", "description": "Person committing sexual violence: former husband/partner"},
        "dv_sex_bf": {"type": "int", "description": "Person committing sexual violence: current/former boyfriend"},
        "dv_sex_father": {"type": "int", "description": "Person committing sexual violence: father/step-father"},
        "dv_sex_brother": {"type": "int", "description": "Person committing sexual violence: brother/step-brother"},
        "dv_sex_other_rel": {"type": "int", "description": "Person committing sexual violence: other relative"},
        "dv_sex_inlaw": {"type": "int", "description": "Person committing sexual violence: in-law"},
        "dv_sex_friend": {"type": "int", "description": "Person committing sexual violence: friend/acquaintance"},
        "dv_sex_friend_fam": {"type": "int", "description": "Person committing sexual violence: family friend"},
        "dv_sex_teacher": {"type": "int", "description": "Person committing sexual violence: teacher"},
        "dv_sex_atwork": {"type": "int", "description": "Person committing sexual violence: employer/someone at work"},
        "dv_sex_relig": {"type": "int", "description": "Person committing sexual violence: priest or religious leader"},
        "dv_sex_police": {"type": "int", "description": "Person committing sexual violence: police/soldier"},
        "dv_sex_stranger": {"type": "int", "description": "Person committing sexual violence: stranger"},
        "dv_sex_other": {"type": "int", "description": "Person committing sexual violence: other"},
        "dv_sex_missing": {"type": "int", "description": "Person committing sexual violence: missing"},
        "dv_help_seek": {"type": "int", "description": "Help-seeking behavior of women who ever experienced physical or sexual violence"},
        "dv_help_phy": {"type": "int", "description": "Sources of help sought for physical violence among women who sought help"},
        "dv_help_sex": {"type": "int", "description": "Sources of help sought for sexual violence among women who sought help"},
        "dv_help_phy_sex_all": {"type": "int", "description": "Sources of help sought for physical and sexual violence among women who sought help"},
        "dv_help_phy_sex_any": {"type": "int", "description": "Sources of help sought for physical or sexual violence among women who sought help"},
        "dv_help_fam": {"type": "int", "description": "Source of help: own family"},
        "dv_help_hfam": {"type": "int", "description": "Source of help: husband's family"},
        "dv_help_husb": {"type": "int", "description": "Source of help: husband"},
        "dv_help_bf": {"type": "int", "description": "Source of help: boyfriend"},
        "dv_help_friend": {"type": "int", "description": "Source of help: friend"},
        "dv_help_neighbor": {"type": "int", "description": "Source of help: neighbor"},
        "dv_help_relig": {"type": "int", "description": "Source of help: religious"},
        "dv_help_doc": {"type": "int", "description": "Source of help: doctor"},
        "dv_help_police": {"type": "int", "description": "Source of help: police"},
        "dv_help_lawyer": {"type": "int", "description": "Source of help: lawyer"},
        "dv_help_sw": {"type": "int", "description": "Source of help: social worker"},
        "dv_help_other": {"type": "int", "description": "Source of help: other"},
        "dv_prtnr_phy": {"type": "int", "description": "Domestic Violence by Partner"},
        "dv_prtnr_push": {"type": "int", "description": "Ever pushed, shook, or had something thrown at her in past 12 mos. by partner"},
        "dv_prtnr_slap": {"type": "int", "description": "Ever slapped by partner"},
        "dv_prtnr_twist": {"type": "int", "description": "Ever had arm twisted or hair pulled by partner"},
        "dv_prtnr_punch": {"type": "int", "description": "Ever punched with fist or something else that could hurt her by partner"},
        "dv_prtnr_kick": {"type": "int", "description": "Ever kicked, dragged, or beat up by partner"},
        "dv_prtnr_choke": {"type": "int", "description": "Ever tried to choke or burn her by partner"},
        "dv_prtnr_weapon": {"type": "int", "description": "Ever threatened or attacked with a knife, gun, or other weapon by partner"},
        "dv_prtnr_sex": {"type": "int", "description": "Ever experienced any sexual violence by partner"},
        "dv_prtnr_force": {"type": "int", "description": "Physically forced to have sex when she did not want to by partner"},
        "dv_prtnr_force_act": {"type": "int", "description": "Physically forced to perform other sexual acts when she did not want to by partner"},
        "dv_prtnr_threat_act": {"type": "int", "description": "Forced with threats or in any other way to perform sexual acts she did not want to by partner"},
        "dv_prtnr_emot": {"type": "int", "description": "Any emotional violence by partner"},
        "dv_prtnr_humil": {"type": "int", "description": "Humiliated in front of others by partner"},
        "dv_prtnr_threat": {"type": "int", "description": "Threatened to hurt or harm her or someone she cared about by partner"},
        "dv_prtnr_insult": {"type": "int", "description": "Insulted or made to feel bad about herself by partner"},
        "dv_prtnr_phy_sex": {"type": "int", "description": "Ever experienced physical AND sexual violence by partner"},
        "dv_prtnr_phy_sex_emot": {"type": "int", "description": "Ever experienced physical AND sexual AND emotional violence by partner"},
        "dv_prtnr_phy_sex_any": {"type": "int", "description": "Ever experienced physical OR sexual violence by partner"},
        "dv_prtnr_phy_sex_emot_any": {"type": "int", "description": "Ever experienced physical OR sexual OR emotional violence by partner"},
        "dv_aprtnr_phy": {"type": "int", "description": "Experienced physical violence by any partner"},
        "dv_aprtnr_sex": {"type": "int", "description": "Experienced sexual violence by any partner"},
        "dv_aprtnr_emot": {"type": "int", "description": "Experienced emotional violence by any partner"},
        "dv_aprtnr_phy_sex": {"type": "int", "description": "Experienced physical and sexual violence by any partner"},
        "dv_aprtnr_phy_sex_any": {"type": "int", "description": "Ever experienced physical OR sexual violence by any partner"},
        "dv_aprtnr_phy_sex_emot": {"type": "int", "description": "Ever experienced physical AND sexual AND emotional violence by any partner"},
        "dv_aprtnr_phy_sex_emot_any": {"type": "int", "description": "Ever experienced physical OR sexual OR emotional violence by any partner"},
        "dv_prtnr_viol_years": {"type": "int", "description": "Experience of physical or sexual violence by partner by specific exact years since marriage - among women only married once"},
        "dv_prtnr_viol_none": {"type": "int", "description": "Did not experience physical or sexual violence by partner - among women only married once"},
        "dv_marr_viol_0": {"type": "int", "description": "Experience of violence by exact marriage duration: before marriage"},
        "dv_marr_viol_2": {"type": "int", "description": "Experience of violence by exact marriage duration: 2 yrs of marriage"},
        "dv_marr_viol_5": {"type": "int", "description": "Experience of violence by exact marriage duration: 5 yrs of marriage"},
        "dv_marr_viol_10": {"type": "int", "description": "Experience of violence by exact marriage duration: 10 yrs of marriage"},
        "dv_prtnr_cuts": {"type": "int", "description": "Have cuts, bruises, or aches as a result of the violence by partner"},
        "dv_prtnr_injury": {"type": "int", "description": "Have eye injuries, sprains, dislocations, or burns as a result of the violence by partner"},
        "dv_prtnr_broken": {"type": "int", "description": "Deep wounds, broken bones, broken teeth, or any other serious injury as a result of the violence by partner"},
        "dv_prtnr_injury_any": {"type": "int", "description": "Have any injury as a result of the violence by partner"},
        "dv_abusedhus_phy": {"type": "int", "description": "Ever committed physical violence against partner when he was not already beating or physically hurting her"},
        "dv_abusedhus_phy_12m": {"type": "int", "description": "Committed physical violence against partner in past 12 mos. when he was not already beating or physically hurting her"},
        "dwt": {"type": "float", "description": "Weight for scaling"}
    }
}

from difflib import SequenceMatcher

def find_columns_match(question, schema_dict, threshold=51):
    try:
        # Dictionary to store file names and their matching columns with type and description
        matching_columns = {}
        # Define common terms for scaling weight columns
        scaling_weight_keywords = ['weight', 'dweight', 'scaling', 'survey_weight']
        # Loop through each file in the schema dictionary
        for file_name, columns in schema_dict.items():
            # List to store matching columns with their type and description for the current file
            file_matching_columns = []

            # Loop through the columns in the current file
            for column_name, attributes in columns.items():
                description = attributes['description']

                # Calculate similarity score between the question and the column description
                score = SequenceMatcher(None, description.lower(), question.lower()).ratio() * 100

                # If score is above the threshold, add the column name, type, and description to the list for the current file
                if score > threshold:
                    file_matching_columns.append({
                        "column_name": column_name,
                        "type": attributes['type'],
                        "description": description
                    })
            # Check if the column is related to scaling weight and always add it
                if any(keyword in column_name.lower() or keyword in description for keyword in scaling_weight_keywords):
                    file_matching_columns.append({
                        "column_name": column_name,
                        "type": attributes['type'],
                        "description": attributes['description'] + " (Scaling Weight)"
                    })
            # If there are matching columns, add them to the dictionary under the file name
            if file_matching_columns:
                matching_columns[file_name] = file_matching_columns

        # Return the dictionary of matching columns or an empty dictionary if no matches found
        return matching_columns if matching_columns else {question: []}
    
    except Exception as e:
        return {question: []}




# Call the function
matching_columns = find_columns_match(question, schema_dict)
# Extract file names (assuming keys end with .csv or similar)
file_names = [file_name for file_name in schema_dict.keys() if file_name.endswith('.csv')]
# Output the result
print(matching_columns)




# Prompt template to generate Python code
template = """
You are a highly skilled and experienced Python programming assistant with expertise in data manipulation and analysis. Your task is to write Python code that processes data within a pandas DataFrame according to the user's instructions. Ensure that you consider potential data quality issues such as missing values (e.g., NaN, NA, None), and include appropriate handling methods for these values (such as imputation, dropping, or filtering) and present the results by using print statements.




Schema: **Schema of the columns in df:**

{matching_columns}




### Instructions:

1. **Analyze Schema**:  
    Review the schema and data types of each column to ensure the expected types (e.g., `int`, `float`, `str`).

2. **Import Libraries**:  
    Import the necessary libraries for data manipulation and analysis.

    ```python
    import pandas as pd
    import numpy as np
    ```
3. **Read CSV Files**: Load all the files in {filenames} into a pandas DataFrames one-by-one.

    ```python
    # Load CSV into DataFrame
    df = pd.read_csv('DomesticVoilance.csv')
    ``` 
   
4. **Ensure Consistent Data Types for Comparisons**:

    For the **Age** column, where age ranges are provided as strings (e.g., "15-19"), it is important to understand that these ranges represent people within the specified age group, including both the lower and upper bounds (i.e., from 15 to 19, inclusive). To facilitate accurate comparisons, you need to extract both the lower and upper bounds of the age range.

    Here’s an example of how to handle the **Age** string column for comparisons:
    
    ```python
    # Extract the lower and upper bounds of the age range
    df['age_min'] = df['Age'].apply(lambda x: int(x.split('-')[0]))
    df['age_max'] = df['Age'].apply(lambda x: int(x.split('-')[1]))
    
    # Example: Filter rows where age falls within a specific range (e.g., 15-19)
    filtered_df = df[(df['age_min'] <= 19) & (df['age_max'] >= 15)]
    ```
    This code splits the **Age** column into two new columns, `age_min` and `age_max`, corresponding to the lower and upper bounds of the age range. You can then use these columns to filter data or perform any age-related comparisons while ensuring inclusivity of the specified age range.
    
    
5. **Exclude Special Values in Calculations**:

    Identify and exclude rows with NaN or NA values in relevant columns by using the dropna() function.
    ```python
    # Exclude rows with NaN or NA values in relevant columns
    df = df.dropna(subset=['Province', 'dwt', 'dv_sex_12m'])
    ```

   
6. **Use Scaling Column**:

    Ensure that the scaling column is used for unbiased and accurate survey calculations, particularly in cases of uneven population distribution.


    ### Example Calculations:
    Assume 'dweight' is a scaling column.
    1. **Calculate the Total Weight**:
        ```python
        weighted_total = df[''dweight''].sum()
        ```
    2. **Calculate the Weighted Sum for Individuals Who Experienced Physical Violence

    ```python
    weighted_phy_violence = df[df['dv_phy'] == True]['dweight'].sum()
    ```
    3. **Calculate the Prevalence of Physical Violence (Weighted Proportion)

    ```python
    prevalence_phy_violence = weighted_phy_violence / weighted_total
    ```
7. **Perform Element-wise Multiplication**:

    Use element-wise multiplication for calculations within groups, applying the lambda function.

    Example:

    ```python
    # Perform element-wise multiplication within groups and calculate the weighted sum
    weighted_phy_violence = df.groupby('Province').apply(lambda x: (x['dv_phy'] * x['dwt']).sum())
    ```
8. **Perform DataFrame Manipulations**:

    Use DataFrame operations such as filtering, grouping, and aggregation to meet the requirements.

    ```python
    # Example: Group data by a column and calculate the sum of another column
    result = df.groupby('group_column')['target_column'].sum() 
    ```
9. **Ensure Parentheses Grouping**:
    Double-check that parentheses are correctly placed around grouped parts of an expression.
    
10. **Break Down the Expression**:
    If the expression is complex, break it down into smaller, simpler parts to verify that everything is correctly placed.
11. **Visual Matching of Parentheses**:
    When writing complex expressions, always check that each opening parenthesis `(` has a matching closing parenthesis `)`. In some code editors, the matching pair of parentheses is highlighted to help avoid this error.
12. **Indentation and Line Breaks**:
    If the expression becomes too long or hard to read, break it into multiple lines for clarity. This makes it easier to track matching parentheses. Break long expressions into multiple lines and ensure proper indentation.


13. **Output the Results**:

    Display the final results with appropriate labels for clarity and interpretation using print statement.

    ```python
    # Print final result
    print(result)
    ```   
  

   

Task: {question}

Expected Output: The Python code generated must be syntactically correct, follow best practices for data analysis using pandas, and be robust against missing values and other anomalies.

Python Code:
"""

# Creating a PromptTemplate and LLMChain for code generation
prompt = PromptTemplate(input_variables=["matching_columns","filenames","question"], template=template)
llm_chain = LLMChain(prompt=prompt, llm=llm)

# Generate the Python code using invoke()
response = llm_chain.invoke({"matching_columns": matching_columns,"filenames":file_names,"question": question})

# Extract the generated code from the response
generated_code = response['text']
print("Generated Python Code:\n", generated_code)

# Step 1: Parse the code block (extract code between ```python and ``` tags)
def extract_code(code_block):
    if '```python' in code_block:
        return code_block.split('```python')[1].split('```')[0].strip()
    return code_block

# Extract code from generated response
code_to_execute = extract_code(generated_code)

import autopep8
import ast

def check_indentation(code):
    """
    This function checks for any IndentationError or syntax errors by parsing the code.
    """
    try:
        # Try compiling the code to check for syntax and indentation issues
        compile(code, '<string>', 'exec')
        return None  # No indentation or syntax error found
    except IndentationError as e:
        return str(e)  # Return indentation error message
    except SyntaxError:
        # Allow for syntax checking later on
        return None

def check_syntax(code):
    """
    This function uses Python's compile() function to check for syntax errors.
    """
    try:
        # Use the Python compiler to check for syntax errors
        compile(code, '<string>', 'exec')
        return None  # No syntax error found
    except SyntaxError as e:
        return str(e)  # Return the syntax error message

def fix_code(code):
    """
    This function uses autopep8 to automatically format and fix common Python code issues,
    including indentation and other PEP8 violations.
    """
    fixed_code = autopep8.fix_code(code)
    return fixed_code

def check_and_fix_code(code):
    """
    This function checks for both indentation and syntax errors, fixes them, and returns the corrected code.
    It ensures:
    1. Indentation is corrected first if needed.
    2. Syntax is then checked and corrected if necessary.
    """
    # Step 1: Check for indentation errors
    indentation_error = check_indentation(code)
    
    if indentation_error:
        print("Indentation Error Found:", indentation_error)
        print("Attempting to fix the indentation...")
        
        # Step 2: Fix indentation errors
        fixed_code = fix_code(code)
        
        # Step 3: Re-check the fixed code for syntax errors
        syntax_error = check_syntax(fixed_code)
        if syntax_error:
            print("Syntax Error Found after fixing indentation:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 4: Fix syntax errors if found
            final_code = fix_code(fixed_code)
            return final_code
        else:
            return fixed_code
    else:
        # If indentation is correct, check for syntax errors using the compiler
        syntax_error = check_syntax(code)
        if syntax_error:
            print("Syntax Error Found:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 5: Fix syntax errors
            final_code = fix_code(code)
            return final_code
        else:
            # If no errors found, return the original code
            return code



# Check and fix the code
fixed_code = check_and_fix_code(code_to_execute)
print("Fixed Code:\n", fixed_code)


# Initialize PythonREPLTool for executing Python code
python_repl = PythonREPLTool()

#### We run the code in loop, till it executes
max_retries = 5
retries = 0

# Function to check for errors in the execution output
def check_for_errors(execution_output, error_keywords):
    for keyword in error_keywords:
        if keyword in execution_output:
            return True, keyword
    return False, None

while retries < max_retries:
    
        # Step 2: Execute the code within the PythonREPLTool
        execution_output = python_repl.run(fixed_code)
        print("Execution Output:\n", execution_output)
        
        
        # List of common Python error keywords
        error_keywords = [
            'Exception', 'ArithmeticError', 'AssertionError', 'AttributeError', 
            'BufferError', 'EOFError', 'FloatingPointError', 'GeneratorExit', 
            'ImportError', 'ModuleNotFoundError', 'IndexError', 'KeyError', 
            'KeyboardInterrupt', 'MemoryError', 'NameError', 'NotImplementedError', 
            'OSError', 'OverflowError', 'RecursionError', 'ReferenceError', 
            'RuntimeError', 'StopIteration', 'SyntaxError', 'IndentationError', 
            'TabError', 'SystemError', 'SystemExit', 'TypeError', 'UnboundLocalError', 
            'UnicodeError', 'UnicodeEncodeError', 'UnicodeDecodeError', 
            'UnicodeTranslateError', 'ValueError', 'ZeroDivisionError', 'FileNotFoundError',
            'PermissionError', 'TimeoutError', 'ConnectionError', 'ConnectionAbortedError',
            'ConnectionRefusedError', 'ConnectionResetError', 'BrokenPipeError', 'BlockingIOError',
            'ChildProcessError', 'EnvironmentError'
        ]
        
        # Call the function and check for errors
        error_detected, error_type = check_for_errors(execution_output, error_keywords)
        
        if error_detected:
            # Here, you'd send the error message to the LLM for fixing
            # LLM generates the corrected code (simulated here for illustration)
            fix_error_prompt=""""You are an expert at correcting python code. Here is the Python code that produced an error. Please analyze the error based on instructions and provide an updated version of the code that fixes the issue.
            
            error:
                {execution_output}
                
            ### Instructions:

            1. **Analyze Schema**:  
                Review the schema and data types of each column to ensure the expected types (e.g., `int`, `float`, `str`).

            2. **Import Libraries**:  
                Import the necessary libraries for data manipulation and analysis.

                ```python
                import pandas as pd
                import numpy as np
                ```
            3. **Read CSV Files**: Load all the files in {filenames} into a pandas DataFrames one-by-one.

                ```pythonelse:
                # Load CSV into DataFrame
                df = pd.read_csv('DomesticVoilance.csv')
                ``` 
               
            4. **Ensure Consistent Data Types for Comparisons**:

                For the **Age** column, where age ranges are provided as strings (e.g., "15-19"), it is important to understand that these ranges represent people within the specified age group, including both the lower and upper bounds (i.e., from 15 to 19, inclusive). To facilitate accurate comparisons, you need to extract both the lower and upper bounds of the age range.

                Here’s an example of how to handle the **Age** string column for comparisons:
                
                ```python
                # Extract the lower and upper bounds of the age range
                df['age_min'] = df['Age'].apply(lambda x: int(x.split('-')[0]))
                df['age_max'] = df['Age'].apply(lambda x: int(x.split('-')[1]))
                
                # Example: Filter rows where age falls within a specific range (e.g., 15-19)
                filtered_df = df[(df['age_min'] <= 19) & (df['age_max'] >= 15)]
                ```
                This code splits the **Age** column into two new columns, `age_min` and `age_max`, corresponding to the lower and upper bounds of the age range. You can then use these columns to filter data or perform any age-related comparisons while ensuring inclusivity of the specified age range.
                
                
            5. **Exclude Special Values in Calculations**:

                Identify and exclude rows with NaN or NA values in relevant columns by using the dropna() function.
                ```python
                # Exclude rows with NaN or NA values in relevant columns
                df = df.dropna(subset=['Province', 'dwt', 'dv_sex_12m'])
                ```

               
            6. **Use Scaling Column**:

                Ensure that the scaling column is used for unbiased and accurate survey calculations, particularly in cases of uneven population distribution.


                ### Example Calculations:
                Assume 'dweight' is a scaling column.
                1. **Calculate the Total Weight**:
                    ```python
                    weighted_total = df[''dweight''].sum()
                    ```
                2. **Calculate the Weighted Sum for Individuals Who Experienced Physical Violence

                ```python
                weighted_phy_violence = df[df['dv_phy'] == True]['dweight'].sum()
                ```
                3. **Calculate the Prevalence of Physical Violence (Weighted Proportion)

                ```python
                prevalence_phy_violence = weighted_phy_violence / weighted_total
                ```
            7. **Perform Element-wise Multiplication**:

                Use element-wise multiplication for calculations within groups, applying the lambda function.

                Example:

                ```python
                # Perform element-wise multiplication within groups and calculate the weighted sum
                weighted_phy_violence = df.groupby('Province').apply(lambda x: (x['dv_phy'] * x['dwt']).sum())
                ```
            8. **Perform DataFrame Manipulations**:

                Use DataFrame operations such as filtering, grouping, and aggregation to meet the requirements.

                ```python
                # Example: Group data by a column and calculate the sum of another column
                result = df.groupby('group_column')['target_column'].sum() 
                ```
            9. **Ensure Parentheses Grouping**:
                Double-check that parentheses are correctly placed around grouped parts of an expression.
                
            10. **Break Down the Expression**:
                If the expression is complex, break it down into smaller, simpler parts to verify that everything is correctly placed.
            11. **Visual Matching of Parentheses**:
                When writing complex expressions, always check that each opening parenthesis `(` has a matching closing parenthesis `)`. In some code editors, the matching pair of parentheses is highlighted to help avoid this error.
            12. **Indentation and Line Breaks**:
                If the expression becomes too long or hard to read, break it into multiple lines for clarity. This makes it easier to track matching parentheses. Break long expressions into multiple lines and ensure proper indentation.

            Python code need to be fixed:
                {fixed_code}
                
            corrected_code:
            """
            
            # Creating a PromptTemplate and LLMChain for code generation
            prompt = PromptTemplate(input_variables=["fixed_code","execution_output","filenames"], template=fix_error_prompt)
            llm_fix_chain = LLMChain(prompt=prompt, llm=llm)

            # Generate the Python code using invoke()
            response = llm_fix_chain.invoke({"fixed_code": fixed_code, "execution_output": execution_output,"filenames":file_names})

            # Extract the generated code from the response
            generated_code = response['text']
            code_to_execute = extract_code(generated_code)
            # Check and fix the code
            fixed_code = check_and_fix_code(code_to_execute)
            print("fixed_code\n",fixed_code)
            
            retries += 1
            
        else:
            break
            
            


        
       
        
        



# Step 2: Feed back to LLM for narrative generation and insights
insight_template = """
Your task is to provide a clear and focused response based on the execution output of the code. The response should:
1. Restate the original query.
2. Summarize the execution output.
3. Provide insights and conclusions based on the results.

Ensure the explanation is concise, coherent, and directly addresses the user’s query.

Original Query: {question}

Execution Output:
{execution_output}

Response:
"""

insight_prompt = PromptTemplate(input_variables=["question","execution_output"], template=insight_template)
insight_chain = LLMChain(prompt=insight_prompt, llm=llm)


print("Insights and Narrative:\n", insight_chain.invoke({"question": question,"execution_output":execution_output}))


