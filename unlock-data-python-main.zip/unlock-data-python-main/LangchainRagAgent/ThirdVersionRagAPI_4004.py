#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 12:36:56 2024

@author: asmat
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 20:27:33 2024

@author: asmat
"""

import os
import openai
from langchain import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from dotenv import load_dotenv
import pandas as pd
import io
import sys
from langchain_experimental.tools import PythonREPLTool
import re

# Load environment variables (OpenAI API key)
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")


# #LLM setup (you might be using a local LLM, adjust as needed)
# from langchain_ollama import ChatOllama
# local_llm = 'hhao/openbmb-minicpm-llama3-v-2_5:fp16'
# llm = ChatOllama(model=local_llm, temperature=0.0, num_ctx=32768)

from langchain_groq import ChatGroq
GROQ_API_KEY = "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"
llm = ChatGroq(groq_api_key=GROQ_API_KEY, temperature=0, model="llama-3.1-70b-versatile")

import re
from difflib import SequenceMatcher



def extract_schema(input_text):
    # Regular expression to capture the schema section
    schema_section = re.search(r'\*\*Schema of the dataset:\*\*\n(.*?)(?=\*\*Special instruction for analysis:\*\*|\Z)', input_text, re.DOTALL)

    # Initialize an empty list to store column information
    schema_list = []

    if schema_section:
        # Split the schema into lines and process each line
        lines = schema_section.group(1).strip().split('\n')
        for line in lines:
            # Split by the first colon to separate column name and its attributes
            column_info = line.split(':', 1)
            if len(column_info) == 2:
                column_name = column_info[0].strip()  # Extract the column name
                attributes = column_info[1].strip()  # Extract the attributes
                column_type = attributes.split('#')[0].strip()  # Extract the type

                # Extract description
                description = attributes.split('#')[1].strip() if '#' in attributes else ""
                
                # Append the column information as a dictionary to the list
                schema_list.append({
                    "column_name": column_name,
                    "type": column_type,
                    "description": description
                })

    return schema_list



from sentence_transformers import SentenceTransformer, util

# # Load the pre-trained transformer model
model = SentenceTransformer('sentence-transformers/msmarco-distilbert-base-v4')



import nltk
from nltk.corpus import stopwords
import string

# Download stopwords to ensure they are available
nltk.download('stopwords')

# Load the list of stopwords (e.g., for English)
stop_words = set(stopwords.words('english'))

# Function to clean and filter text by removing stop words and punctuation
def clean_text(text):
    # Remove punctuation and split text into words
    words = text.lower().translate(str.maketrans('', '', string.punctuation)).split()
    # Filter out stop words and return the set of cleaned keywords
    return set(word for word in words if word not in stop_words)

import re
from collections import OrderedDict

def extract_timestamp_from_filename(file_name):
    """Extracts the timestamp from the beginning of the file name."""
    # Assuming the timestamp is at the beginning of the file name and is numeric
    timestamp = re.search(r'^\d+', file_name)
    return int(timestamp.group()) if timestamp else 0

from sentence_transformers import SentenceTransformer, util
from collections import OrderedDict
import traceback  # For detailed error reporting

# Load a pre-trained Sentence Transformer model (you can try other models too)
model = SentenceTransformer('all-MiniLM-L6-v2')

def find_columns_match(question, schema_dict):
    try:
        # Validate inputs
        if not question or not isinstance(schema_dict, dict):
            raise ValueError("Invalid input: Question must be a non-empty string and schema_dict a dictionary.")

        # Dictionary to store matching columns by file name
        matching_columns = {}

        # Set to store column names that have already been matched
        matched_column_names = set()

        # Define common keywords for scaling weight columns
        scaling_weight_keywords = ['weight', 'dweight', 'scaling', 'survey_weight', 'weighting']

        # Encode the question to get its embedding
        question_embedding = model.encode(question, convert_to_tensor=True)

        # Sort schema files by timestamp in descending order (most recent first)
        sorted_schema_dict = OrderedDict(
            sorted(schema_dict.items(), key=lambda x: extract_timestamp_from_filename(x[0]), reverse=True)
        )

        # Loop through each file in the schema dictionary
        for file_name, columns in sorted_schema_dict.items():
            if not isinstance(columns, list):
                print(f"Warning: {file_name} does not contain a list of columns.")
                continue

            # Store matching columns for the current file
            file_matching_columns = []

            # First pass: Match based on semantic similarity between the question and column description
            for column in columns:
                if not isinstance(column, dict) or 'column_name' not in column or \
                   'description' not in column or 'type' not in column:
                    print(f"Warning: Invalid column format in file {file_name}. Skipping column.")
                    continue

                column_name = column['column_name'].lower()
                description = column['description'].lower()
                col_type = column['type']

                # Skip already matched columns
                if column['column_name'] in matched_column_names:
                    continue

                # Concatenate column name and description for better similarity matching
                combined_text = f"{column_name} {description}"

                # Compute embedding for the combined text
                combined_embedding = model.encode(combined_text, convert_to_tensor=True)

                # Calculate cosine similarity between question and combined text
                similarity = util.cos_sim(question_embedding, combined_embedding).item()
                print(f"Similarity between '{question}' and '{combined_text}': {similarity}")

                # If similarity exceeds the threshold, add it to the matching columns
                if similarity > 0.1:
                    file_matching_columns.append({
                        "column_name": column['column_name'],
                        "type": col_type,
                        "description": column['description']
                    })
                    matched_column_names.add(column['column_name'])

            # Second pass: Always add scaling weight columns if not matched already
            for column in columns:
                column_name = column['column_name'].lower()
                description = column['description'].lower()
                col_type = column['type']

                if column['column_name'] in matched_column_names:
                    continue

                if any(keyword in column_name or keyword in description for keyword in scaling_weight_keywords):
                    file_matching_columns.append({
                        "column_name": column['column_name'],
                        "type": col_type,
                        "description": column['description'] + " (Scaling Weight)"
                    })
                    matched_column_names.add(column['column_name'])

            # Add matching columns for the current file to the dictionary
            if file_matching_columns:
                matching_columns[file_name] = file_matching_columns

        # Return the dictionary of matching columns or an empty dictionary if none found
        return matching_columns if matching_columns else {question: []}

    except Exception as e:
        print(f"Error: {traceback.format_exc()}")
        return {question: []}





# Prompt template to generate Python code
template = """ 
You are **Mike**, a world-renowned Python expert in data manipulation and analysis, with a Stanford background and years of mastery. Your task is to evaluate queries and provide **executable Python code** focused solely on **data manipulation**, incorporating necessary precautions to avoid past mistakes. You will assess your code for potential past mistakes and include safeguards to prevent them.


---

# Guidelines

- Focus solely on **data preparation** tasks.
- **Do not include graphical instructions** (e.g., matplotlib), even if requested.
- Ensure **clarity** and **accuracy** in the code, and **verify all outputs** thoroughly.
- For identifying fields to be selected for relevant_column variable, use the query text to match with schema text.
- Take precautions to avoid common mistakes when writing executable Python code.



# Schema:
schema:{schema} 
csv_files_names: {csv_files_names}

# Task: {query} 


# Instructions:

## **Analyze Schema**
Select the relevant columns to be used in the python code exclusively from the variable 'schema'.
Review the schema and data types from the `schema` variable to ensure they align with expected types (e.g., `int`, `float`, `str`). 
**Always use the columns provided in `relevant_columns` and avoid creating or assuming new ones**.
**Always use the files provided in `csv_files_names` and avoid creating or assuming new ones**.
---

## **Import Libraries**
Import the necessary libraries for data manipulation.

```python
import pandas as pd
import numpy as np
```


## **Reading CSV Files**  
Identify first the file paths as files with list items in the 'csv_files_names' variable. Then Load all CSV files into a list of DataFrames.

```python
csv_files_names = ['filepath1','filepath2']
dataframes = []
for file in csv_files_names:
    try:
        df = pd.read_csv(file)
        dataframes.append(df)
        print(f"CSV file loaded successfully.")
    except Exception as e:
        print(f"Error loading file: {{e}}")
```

## **Process Each File**  
Iterate over each file, load it using `pd.read_csv()`, store the DataFrames, clean the data, and perform any necessary calculations, such as summing weights or counting occurrences.


## **Identify Relevant Fields Based on a Query**
Determine the most appropriate fields that represents the query based on the 'schema' text.
Save the most appropriate field names in a list variable called `relevant_columns` for further use.


## **Handling Missing Values in Relevant Columns**  
To ensure the integrity of your data, it's essential to remove any rows that contain missing values in the relevant columns.

```python
# Drop rows with missing values in the relevant columns
df = df.dropna(subset=relevant_columns)
```
## **Ensure Consistent Data Types**  
To maintain data integrity, it’s crucial to ensure that your boolean columns are correctly represented. For columns with binary values like 0 and 1, convert them to `False` and `True`. Additionally, verify that other columns, such as 'dweight', are in the appropriate data type (e.g., `float`).

```python
df['dv_phy'] = df['dv_phy'].astype(bool)
df['dweight'] = df['dweight'].astype(float)
```
## Check possible values present in relevant columns.
- **Boolean Data Type**:  
  If the data type of a column is 'Boolean', its values will either be `0` (representing `False`) or `1` (representing `True`).

- **String Data Type**:  
  If the data type is 'String', list all unique text-based values to create logical conditions or filters.

- **Float Data Type**:  
  If the data type is 'Float', ensure accurate handling of numerical operations and address any irregularities such as `NaN` or outliers.

## **Handle Age Columns with Ranges**  
Identify the column within `relevant_columns` that contains entries formatted like `15-19`. If such an age column is found, split it into two new columns: `age_min` and `age_max`.

```python
# Assuming 'age' is the identified column containing entries like '15-19'
df['age_min'] = df['age'].apply(lambda x: int(x.split('-')[0]))
df['age_max'] = df['age'].apply(lambda x: int(x.split('-')[1]))
```

## ** Printing the final output **
After processing the data, it’s essential to print the results with proper labels for clarity. Below are the detailed instructions for printing and labeling your final output.**

### Instructions for Printing Output

1. **Prepare the Output DataFrame**: Ensure that your final DataFrame (`output_df`) contains all the necessary information you want to display.

2. **Print with Labels**: Use the `print()` function to display your output, and include descriptive labels to clarify what each piece of information represents.






# Expected Output: The Python code generated must be syntactically correct, follow best practices for data analysis using pandas, and be robust against missing values and other anomalies, while also taking care of previous mistakes.


# Python Code:

"""




# Step 1: Parse the code block (extract code between ```python and ``` tags)
def extract_code(code_block):
    if '```python' in code_block:
        return code_block.split('```python')[1].split('```')[0].strip()
    return code_block



import autopep8
import ast

def check_indentation(code):
    """
    This function checks for any IndentationError or syntax errors by parsing the code.
    """
    try:
        # Try compiling the code to check for syntax and indentation issues
        compile(code, '<string>', 'exec')
        return None  # No indentation or syntax error found
    except IndentationError as e:
        return str(e)  # Return indentation error message
    except SyntaxError:
        # Allow for syntax checking later on
        return None

def check_syntax(code):
    """
    This function uses Python's compile() function to check for syntax errors.
    """
    try:
        # Use the Python compiler to check for syntax errors
        compile(code, '<string>', 'exec')
        return None  # No syntax error found
    except SyntaxError as e:
        return str(e)  # Return the syntax error message

def fix_code(code):
    """
    This function uses autopep8 to automatically format and fix common Python code issues,
    including indentation and other PEP8 violations.
    """
    fixed_code = autopep8.fix_code(code)
    return fixed_code

def check_and_fix_code(code):
    """
    This function checks for both indentation and syntax errors, fixes them, and returns the corrected code.
    It ensures:
    1. Indentation is corrected first if needed.
    2. Syntax is then checked and corrected if necessary.
    """
    # Step 1: Check for indentation errors
    indentation_error = check_indentation(code)
    
    if indentation_error:
        print("Indentation Error Found:", indentation_error)
        print("Attempting to fix the indentation...")
        
        # Step 2: Fix indentation errors
        fixed_code = fix_code(code)
        
        # Step 3: Re-check the fixed code for syntax errors
        syntax_error = check_syntax(fixed_code)
        if syntax_error:
            print("Syntax Error Found after fixing indentation:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 4: Fix syntax errors if found
            final_code = fix_code(fixed_code)
            return final_code
        else:
            return fixed_code
    else:
        # If indentation is correct, check for syntax errors using the compiler
        syntax_error = check_syntax(code)
        if syntax_error:
            print("Syntax Error Found:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 5: Fix syntax errors
            final_code = fix_code(code)
            return final_code
        else:
            # If no errors found, return the original code
            return code




fix_error_prompt=""""You are an expert at correcting python code. Here is the Python code that produced an error. Please analyze the error based on instructions and provide an updated version of the code that fixes the issue.

error:
    {execution_output}
    
### Instructions:

1. **Analyze Schema**:  
    Review the schema and data types of each column to ensure the expected types (e.g., `int`, `float`, `str`).

2. **Import Libraries**:  
    Import the necessary libraries for data manipulation and analysis.

    ```python
    import pandas as pd
    import numpy as np
    ```
. **Reading CSV Files**: The code loads all CSV files from {csv_files_names} path into a list of DataFrames.
    For this purpose, follow the example code below.
    ```python
    # Initialize a list to hold all DataFrames
    dataframes = []
    
    # Load each CSV file into a DataFrame and append it to the list
    for file in csv_files_names:
        try:
            df = pd.read_csv(file)
            dataframes.append(df)
            print(f"CSV file  loaded successfully")
        except Exception as e:
            print(f"Error loading file")
    
    # Example: Accessing the first DataFrame from the list
    if dataframes:
        df = dataframes[0]  # Do something with the first DataFrame
    else:
        print("No CSV files loaded")
    ```
    
   
4. **Ensure Consistent Data Types for Comparisons**:
    For some columns, data values may be 0 and 1, which should be interpreted as False and True, respectively, when a boolean type is required.
    For oher columns, where age ranges are provided as strings (e.g., "15-19"), it is important to understand that these ranges represent people within the specified age group, including both the lower and upper bounds (i.e., from 15 to 19, inclusive). To facilitate accurate comparisons, you need to extract both the lower and upper bounds of the age range.

    Here’s an example of how to handle the **Age** string column for comparisons:
    
    ```python
    # Extract the lower and upper bounds of the age range
    df['age_min'] = df['Age'].apply(lambda x: int(x.split('-')[0]))
    df['age_max'] = df['Age'].apply(lambda x: int(x.split('-')[1]))
    
    # Example: Filter rows where age falls within a specific range (e.g., 15-19)
    filtered_df = df[(df['age_min'] <= 19) & (df['age_max'] >= 15)]
    ```
    This code splits the **Age** column into two new columns, `age_min` and `age_max`, corresponding to the lower and upper bounds of the age range. You can then use these columns to filter data or perform any age-related comparisons while ensuring inclusivity of the specified age range.
    
    
5. **Exclude Special Values in Calculations**:

    Identify and exclude rows with NaN or NA values in relevant columns by using the dropna() function.
    ```python
    # Exclude rows with NaN or NA values in relevant columns
    df = df.dropna(subset=['province', 'dwt', 'dv_sex_12m'])
    ```

   
6. **Use Scaling Column**:

    Ensure that the scaling column is used for unbiased and accurate survey calculations, particularly in cases of uneven population distribution.


    ### Example Calculations:
    Assume 'dweight' is a scaling column.
    1. **Calculate the Total Weight**:file_name
        ```python
        weighted_total = df[''dweight''].sum()
        ```
    2. **Calculate the Weighted Sum for Individuals Who Experienced Physical Violence

    ```python
    weighted_phy_violence = df[df['dv_phy'] == 1]['dweight'].sum()
    ```
    3. **Calculate the Prevalence of Physical Violence (Weighted Proportion)

    ```python
    prevalence_phy_violence = weighted_phy_violence / weighted_total
    ```
7. **Perform Element-wise Multiplication**:

    Use element-wise multiplication for calculations within groups, applying the lambda function.

    Example:

    ```python
    # Perform element-wise multiplication within groups and calculate the weighted sum
    weighted_phy_violence = df.groupby('province').apply(lambda x: (x['dv_phy'] * x['dwt']).sum())
    ```
8. **Perform DataFrame Manipulations**:

    Use DataFrame operations such as filtering, grouping, and aggregation to meet the requirements.

    ```python
    # Example: Group data by a column and calculate the sum of another column
    result = df.groupby('group_column')['target_column'].sum() 
    ```
9. **Ensure Parentheses Grouping**:
    Double-check that parentheses are correctly placed around grouped parts of an expression.
    
10. **Break Down the Expression**:
    If the expression is complex, break it down into smaller, simpler parts to verify that everything is correctly placed.
11. **Visual Matching of Parentheses**:
    When writing complex expressions, always check that each opening parenthesis `(` has a matching closing parenthesis `)`. In some code editors, the matching pair of parentheses is highlighted to help avoid this error.
12. **Indentation and Line Breaks**:
    If the expression becomes too long or hard to read, break it into multiple lines for clarity. This makes it easier to track matching parentheses. Break long expressions into multiple lines and ensure proper indentation.

Python code need to be fixed:
    {fixed_code}
    
corrected_code:
"""

# Function to check for errors in the execution output
def check_for_errors(execution_output, error_keywords):
    for keyword in error_keywords:
        if keyword in execution_output:
            return True, keyword
    return False, None
            

error_keywords = [
    'BaseException', 'SystemExit', 'KeyboardInterrupt', 'GeneratorExit', 
    'Exception', 'ArithmeticError', 'FloatingPointError', 'OverflowError', 
    'ZeroDivisionError', 'AssertionError', 'AttributeError', 'BufferError', 
    'EOFError', 'ImportError', 'ModuleNotFoundError', 'LookupError', 
    'IndexError', 'KeyError', 'MemoryError', 'NameError', 'UnboundLocalError', 
    'OSError', 'BlockingIOError', 'ChildProcessError', 'ConnectionError', 
    'BrokenPipeError', 'ConnectionAbortedError', 'ConnectionRefusedError', 
    'ConnectionResetError', 'FileExistsError', 'FileNotFoundError', 
    'InterruptedError', 'IsADirectoryError', 'NotADirectoryError', 
    'PermissionError', 'ProcessLookupError', 'TimeoutError', 
    'ReferenceError', 'RuntimeError', 'NotImplementedError', 'RecursionError', 
    'SyntaxError', 'IndentationError', 'TabError', 'SystemError', 
    'TypeError', 'ValueError', 'UnicodeError', 'UnicodeDecodeError', 
    'UnicodeEncodeError', 'UnicodeTranslateError', 'Warning', 
    'DeprecationWarning', 'PendingDeprecationWarning', 'RuntimeWarning', 
    'SyntaxWarning', 'UserWarning', 'FutureWarning', 'ImportWarning', 
    'UnicodeWarning', 'BytesWarning', 'ResourceWarning'
]

        
       



insight_template = """
You are Mike, a renowned expert with years of experience delivering precise, insightful responses based on code execution and project history.
Your priority is to provide useful and clarifying comments based on the combined input, which contains both the user’s query and the execution results. You focus on delivering accurate, actionable feedback that directly addresses the task, grounded in the project’s context.

You assess the combined input carefully based on context and ensure that your response is clear, reliable, and concise, integrating expert insights when necessary. Markdown is used for emphasis where needed.

Your response must help the user fully understand the implications of the execution output within their project.

Your response is to **display execution results** based on the user's instructions. If the user asks for output in:
- **Tabular format**, display results in tables.
- **Graphical format**, provide Highcharts JSON encloded in three backticks with keyword JSON where variable 'Title', 'data', 'name' and 'y' values to be filled based on python code execution :
```json
{{
"Title": " ",
"series": [{{
	"showInLegend": false,
	"data": [
		{{"name": " ", "y": }},
		{{"name": " ", "y": }}
		
	]
	}}
	]
}}
```
- **Narrative format**, give a detailed description based on the results.

During the response, if the response string contains quotes inside another quote (i.e., nested quotes), you must escape them using a backslash (\) to ensure that the string is valid for json.dumps().
IF the response contains pandas series object then it should be converted to Python Dictionary object.
<Context>:
{history}
</Context>

<Human>: 
    {combined_result}
<Human>




<AI>:
"""

matching_columns_template = """
Review all fields and their descriptions from the schema. Then, use a step-by-step approach to select the most suitable fields for the query, providing clear reasons for each choice.


Schema: 
{schema}

Response:
"""


summary_template = """
Hi, I’m here to help you craft a focused and insightful summary. A good summary should capture the key points in a clear and concise way, without losing the essence of the original material. The summary will focus on discussing the main idea and the important points supporting it, ensuring brevity and clarity.

Your task is to generate a brief, factual summary that discusses the key points of the provided text. The summary should:
1. Clearly state the main idea or central theme.
2. Highlight the key points and arguments relevant to the topic.
3. Be concise, avoiding unnecessary details or non-essential examples.
4. Use clear and straightforward language for easy understanding.
5. Maintain a neutral tone and avoid personal opinions.
6. Follow a logical structure that mirrors the original text.
7. Avoid direct quotations unless a key phrase is particularly significant.

By following these guidelines, your summary will effectively convey the essence of the original material while remaining brief and accessible.

### Text: {schema_content}

Summary:
"""

history_template = """
Your task is to generate a concise summary that offers historical context for the new query based on previous queries and narrations
in the conversation. Discuss the previous quesries and narraton as a coherent conversation. Highlight all key parts to emphasize critical points. Ensure that the summary captures the essence of the discussion 
without unnecessary details, making it useful for formulating responses even when the current query lacks clarity.

### Text: {updated_history}

### Response:
"""

Nofile_template = """
You are Mike, an expert in crafting a precise and known for your ability to generate clear and precise responses even when there is 
no schema or execution output available. Your strength lies in analyzing the query and leveraging the previous conversation's context 
to deliver accurate and relevant solutions.



### Context: {history}

### Query: {query}

### Response:
"""

context_template = """
Given a chat history and the latest user question \
which might reference context in the chat history, formulate a standalone question \
which can be understood without the chat history. Do NOT answer the question, \
just reformulate it if needed and otherwise return it as is.

<Conversation History>:
{chat_history}
<Conversation History>


<Human>: 
    {query}
</Human>

<standalone question>:
"""




title_template = """
You are Mike, an expert known for your ability to craft precise and clear titles. Your strength lies in assessing the query and making your best judgment to generate a three-word phrase that accurately represents the query. 
This title should summarize the essence of the query in three words, ensuring clarity and relevance. 
If the query is unclear, use your best judgment to clarify its meaning and create an appropriate title.

<query>
 {query}
 <\query>

Title:
"""




import os
import re
from sentence_transformers import SentenceTransformer, util



import os
import re
from sentence_transformers import SentenceTransformer, util



import os
import re
from sentence_transformers import SentenceTransformer, util

def load_schema_files(user_id, thread_id, UPLOAD_DIR):
    sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")
   
    
    # Check if the user/thread directory exists
    if not os.path.exists(sub_dir):
        return f"Directory for user {user_id} and thread {thread_id} does not exist."
    
    file_schemas = []  # List to store formatted file and schema details

    # Loop through all the files in the subdirectory
    for file_name in os.listdir(sub_dir):
        # Extract timestamp (numeric part at the start) and base filename for CSV files
        match = re.match(r"^(\d+)_(.+)\.(csv)", file_name)
        if match:
            timestamp = int(match.group(1))

            # Construct schema file name and paths
            schema_file_name = f"{timestamp}_schema.txt"
            schema_path = os.path.join(sub_dir, schema_file_name)
            csv_file_path = os.path.join(sub_dir, file_name)
            
            # Check if schema file exists for the current CSV file
            if os.path.exists(schema_path):
                # Read schema content
                with open(schema_path, 'r', encoding='utf-8') as schema_file:
                    schema_content = schema_file.read()
                    # Store the CSV file path and schema content
                    file_schemas.append((csv_file_path, schema_content))
            else:
                print(f"Missing schema file for {csv_file_path}: {schema_file_name}")
    
    # If no matching schemas were found
    if not file_schemas:
        return "No schema files found."
    return file_schemas


def is_whole_word_in_text(keyword, text):
    if not text:  # Ensure text is not None
        return False
    # Use word boundaries (\b) to match complete words
    pattern = fr'\b{re.escape(keyword)}\b'
    return bool(re.search(pattern, text))

from sentence_transformers import SentenceTransformer, util

def match_query_with_schema(query, user_id, thread_id, UPLOAD_DIR, threshold=0.4):
    # Load schema files and their contents
    file_schemas = load_schema_files(user_id, thread_id, UPLOAD_DIR)

    if isinstance(file_schemas, str):  # Check if no schemas were found
        return file_schemas

    # Load the Sentence Transformer model
    model = SentenceTransformer('all-MiniLM-L6-v2')

    # Prepare a list to store all matches
    matches = []

    # Compute the query embedding
    query_embedding = model.encode(query, convert_to_tensor=True)

    # Define keywords for scaling/weighting columns
    scaling_keywords = [
        "weight", "scale", "scaling", "normalized", "adjusted", "factor", 
        "magnitude", "size", "rating", "score", "importance", "value"
    ]

    # Define keywords for background characteristics
    background_keywords = [
        "age", "residence", "province", "marital", "work", "living", 
        "education", "child", "wealth", "quintile", "ecological", "ethnic"
    ]

    # Iterate through each file's schema content
    for csv_file_path, schema_content in file_schemas:
        lines = schema_content.strip().splitlines()
        matching_columns = []
        scaling_columns = []
        background_columns = []

        # Store matches with their similarity scores
        similarity_scores = []

        for line in lines:
            if ':' in line:
                column_name, description = line.split(':', 1)
                description = description.strip()

                # Check for scaling/weighting columns
                if any(keyword in description.lower() for keyword in scaling_keywords):
                    scaling_columns.append(f"- **{column_name.strip()}**: {description}")

                # Check for background characteristic columns
                for keyword in background_keywords:
                    if (is_whole_word_in_text(keyword, query.lower()) and 
                        is_whole_word_in_text(keyword, description.lower())):
                        background_columns.append(f"- **{column_name.strip()}**: {description}")
                        break  # Prevent duplicate addition

                # Compute cosine similarity
                description_embedding = model.encode(description, convert_to_tensor=True)
                cosine_sim = util.pytorch_cos_sim(query_embedding, description_embedding).item()

                # Store columns that meet the similarity threshold
                if cosine_sim >= threshold:
                    similarity_scores.append((column_name.strip(), description, cosine_sim))

        # Sort matching columns by similarity score in descending order
        similarity_scores.sort(key=lambda x: x[2], reverse=True)

        # Prepare formatted matching columns with similarity scores
        for column_name, description, score in similarity_scores:
            matching_columns.append(
                f"- **{column_name}**: {description} (Similarity: {score:.2f})"
            )

        # Prepare the output for the current file
        if matching_columns or scaling_columns or background_columns:
            match_output = [f'The file "{csv_file_path}" contains the following matching columns:']
            if matching_columns:
                match_output.append("\n".join(matching_columns))
            if scaling_columns:
                match_output.append(
                    "Additionally, it contains the following scaling/weighting columns:\n" + 
                    "\n".join(scaling_columns)
                )
            if background_columns:
                match_output.append(
                    "Additionally, it contains the following background characteristic columns:\n" + 
                    "\n".join(background_columns)
                )
            matches.append("\n".join(match_output))
        else:
            matches.append(f'The file "{csv_file_path}" does not contain any matching columns for the query.')

    if not matches:
        return "No matching columns found."

    # Combine all matches into a single text result
    return "\n\n".join(matches)



# Function to extract keywords from the text schema
def extract_keywords(text):
    # Remove punctuation and non-alphabetic characters
    clean_text = re.sub(r'\W+', ' ', text)
    # Convert to lowercase
    clean_text = clean_text.lower()
    # Split into words
    words = clean_text.split()
    # Extract only significant keywords (ignore common words)
    common_words = set(["the", "and", "of", "in", "to", "with", "by", "on", "for", "at", "is", "as", "a", "an"])
    keywords = [word for word in words if word not in common_words]
    return keywords

# # Function to match query against keywords in the schema
# def match_query_with_schema(query, schema_keywords):
#     query_keywords = extract_keywords(query)
#     query_keyword_set = set(query_keywords)
#     schema_keyword_set = set(schema_keywords.split())
#     matching_keywords = query_keyword_set.intersection(schema_keyword_set)
    
#     # Check if 50% or more keywords match
#     match_percentage = (len(matching_keywords) / len(query_keyword_set)) * 100
#     return match_percentage >= 50


###########################################
### Now we are going to make an API
###########################################   
from flask import Flask, request, jsonify
import os
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferWindowMemory
from langchain.schema import HumanMessage, AIMessage
from langchain.memory import ChatMessageHistory, ConversationBufferMemory
from langchain.schema import messages_from_dict, messages_to_dict
import json
from collections import Counter 

app = Flask(__name__)

#Define the upload directory
UPLOAD_DIR = "/var/www/html/unlock-data/backend/storage/app/public/uploads"

@app.route('/process_summary/', methods=['POST'])
def process_summary():
    try:
        # Retrieve form data: user_id, thread_id, and timestamp
        user_id = request.form.get('user_id')
        thread_id = request.form.get('thread_id')
        timestamp = request.form.get('timestamp')

        # Debugging output
        print(f"User ID: {user_id}, Thread ID: {thread_id}, Timestamp: {timestamp}")

        # Construct the directory path using user_id and thread_id
        sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")

        # Ensure the sub-directory exists
        if not os.path.exists(sub_dir):
            return jsonify({"error": "Directory not found"}), 404

        # Construct the schema file name and path based on the timestamp
        schema_file = f"{timestamp}_schema.txt"
        schema_file_path = os.path.join(sub_dir, schema_file)

        # Check if the schema file exists
        if not os.path.exists(schema_file_path):
            return jsonify({"error": "Schema file not found"}), 404

        # Read the schema file content for summarization
        with open(schema_file_path, 'r') as file:
            schema_content = file.read()

        # Placeholder: Perform summarization on the schema content (customize this part as needed)
        # Extract keywords
        keywords = extract_keywords(schema_content)
        keyword_summary = " ".join(set(keywords))  # Ensure unique keywords
    
        # title for thread
        # Count the frequency of each keyword
        keyword_counts = Counter(keywords)
        
        # Get the most common keywords (list of tuples)
        top_keywords = keyword_counts.most_common(3)
        
        # Extract only the keywords from the tuples
        top_keywords_list = [keyword for keyword, _ in top_keywords]
        
        # Join the top keywords into a title string
        title = " ".join(top_keywords_list)

        # Return the summarization result
        return jsonify({
            "user_id": user_id,
            "thread_id": thread_id,
            "timestamp": timestamp,
            "summarization": keyword_summary,
            "title": title
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500




import requests
import json
import ollama

@app.route('/execute_query/', methods=['POST'])
def execute_query():
    try:
        # Retrieve form data and uploaded files
        query = request.form.get('query')
        user_id = request.form.get('user_id')
        thread_id = request.form.get('thread_id')
        
       
        print(f"Query: {query}, User ID: {user_id}, Thread ID: {thread_id}")  # Debugging output
       
        
        # now read previous history
        sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")
        os.makedirs(sub_dir, exist_ok=True)
        history_file_path = os.path.join(sub_dir, "history.txt")
        
        # Initialize an empty variable for history content
       
        
        history_content =""
        # history_content = [
        # {"role": "user", "content": "Query: 'Can you provide data on instances of physical violence?'..."},
        # {"role": "assistant", "content": "Based on the execution output, it appears that there are no instances..."},
        # {"role": "user", "content": "Query: 'Based on the previous conversation, can you generate a graphical..."},
        # {"role": "assistant", "content": "Based on the updated execution output, it appears that there are instances..."},
        # {"role": "user", "content": "Can you give me the weighted sum of physical violence for different categories?"},
        # {"role": "assistant", "content": "The weighted sum for the requested categories is..."}
        # ]
        
        # Check if the history file already exists
        if os.path.exists(history_file_path):
            # Read existing history content
            with open(history_file_path, "r", encoding='utf-8') as history_file:
                history_content = history_file.read()
        
        # If there's content in the history file, process it
        if history_content:
            print("\n history content",history_content)
            
            messages = json.loads(history_content)  # Read the JSON data back as a list
            messages = messages[-5:]
            print("messages",messages)
            
           
        else:
            messages =[]
                
                
        ###### First we will make a context query based on history messages
        context_prompt = (
            f"Given a  coversation history and the latest user question which might reference context in the conversaion history, "
            f"formulate a standalone question which can be understood without the conversation history. "
            f"Do NOT answer the question, just reformulate it if needed and otherwise return it as is.\n\n"
            f"<Conversation History>:\n"
            f"{messages}\n"
            f"<Conversation History>\n\n"
            f"<Latest User Question>: \n"
            f"    {query}\n"
            f"</Latest User Question>\n\n"
            f"<Standalone Question>:\n"
        )
        # Use ollama to generate the response
        try:
            # Call the generate function from the ollama library
               result = ollama.generate(
                model='codestral:22b-v0.1-q6_K',
                prompt=context_prompt,  # Use '=' instead of ':'
                options={
                    'temperature': 0.0  # Use '=' instead of ':' and ensure keys are quoted
                },
                stream=False  # Use '=' instead of ':'
                )

                
               # Print the generated response
               original_query = query
               query = str(result['response'])
               print("\n context query",query)
               print("\n")
        except Exception as e:
            print(f"An error occurred: {e}")
        
        
        
        


        # ##### Now Retrieval job
        ### First we retrieve csv file names based on schemas
        print("I am before matching_Schema_info")
        matching_schema_info = match_query_with_schema(query, user_id, thread_id, UPLOAD_DIR)
        
        print("\n query",query)
        print("\n matching schema info",matching_schema_info)
        
       
        
        # Python program creation through LLM
        # Define the python_program_prompt
        python_program_prompt = (
             f"You are **Mike**, a world-renowned Python expert specializing in **data manipulation and analysis**, with limited expertise in Python graphical utilities. "
             f"With your Stanford background and years of experience, your primary task is to analyze user queries and provide **executable Python code** focused on **data preparation and manipulation**, ensuring correctness and avoiding mistakes.\n\n"
         
             # Guidelines
             f"# Guidelines\n"
             f"- Focus only on **data preparation** and **manipulation tasks**.\n"
             f"- **Do not include any plotting or graphical instructions** (e.g., `matplotlib`, `seaborn`, or `plt`).\n"
             f"- Verify the **accuracy** of your code and check all outputs carefully.\n"
             f"- Identify relevant fields from the query and match them to fields in **`matching_schema_info`**.\n"
             f"- **The `csv_files_names` list must contain only filenames from `matching_schema_info`**.\n"
             f"- Avoid assumptions: Do not create new columns, filenames, or datasets unless explicitly mentioned.\n"
             f"- Use **weighted sums** for percentage calculations:\n"
             f"  `(weighted_sum_numerator / weighted_sum_denominator) * 100`.\n\n"
         
             # Schema
             f"# Schema\n"
             f"`matching_schema_info`: {matching_schema_info}\n\n"
         
             # Task and Instructions
             f"# Task: {query}\n\n"
         
             # Analyze Schema
             f"## Analyze Schema\n"
             f"Select relevant filenames and columns **only from `matching_schema_info`**. Ensure data types align with expectations (e.g., `int`, `float`, `str`).\n"
             f"Do not assume or create new data elements.\n\n"
         
             # Import Libraries
             f"## Import Libraries\n"
             f"```python\n"
             f"import pandas as pd\n"
             f"import numpy as np\n"
             f"```\n\n"
         
             
            ## Reading CSV Files
            f"Identify the relevant filenames from the `matching_schema_info` and load them into DataFrames instead of 'filename1' and 'filename2'\n"  
            f"Handle any errors gracefully during the loading process.\n"
            
            f"```python \n"
            f"csv_files_names = ['filename1', 'filename2'] "
            f"dataframes = [] \n"
            
            f"for file in csv_files_names:\n"
            f"    try: \n"
            f"        df = pd.read_csv(file) \n"
            f"        dataframes.append(df)  \n"
            f"        print(f'Successfully loaded: {{file}}') \n"
            f"    except: Exception as e: \n"
            f"        print(f'Error loading {{file}}: {{e}}')"
            f" ``` "

         
             # Processing Data
             f"## Processing Data\n"
             f"Iterate through DataFrames, clean the data, and perform necessary operations like weighted sums or filtering.\n\n"
         
             # Identify Relevant Fields
             f"## Identify Relevant Fields\n"
             f"Extract appropriate fields matching the query from `matching_schema_info`.\n"
             f"Store them in `relevant_columns`.\n\n"
         
             # Handling Missing Values
             f"## Handle Missing Values\n"
             f"Remove rows with missing values in relevant columns to maintain data integrity.\n"
             f"```python\n"
             f"df = df.dropna(subset=relevant_columns)\n"
             f"```\n\n"
         
             # Ensure Consistent Data Types
             f"## Ensure Consistent Data Types\n"
             f"Convert binary columns to Boolean and ensure numerical columns are correctly typed.\n"
             f"```python\n"
             f"df['dv_sex_12m'] = df['dv_sex_12m'].astype(int)  # 1 = Yes, 0 = No\n"
             f"df['dwt'] = df['dwt'].astype(float)\n"
             f"```\n\n"
         
             # Check Possible Values
             f"## Check Possible Values in Relevant Columns\n"
             f"- **Boolean Data**: Ensure values are 0 or 1.\n"
             f"- **String Data**: List unique values for logical checks.\n"
             f"- **Numerical Data**: Check for irregularities like `NaN` or outliers.\n\n"
         
             # Handle Age Ranges
             f"## Handle Age Columns with Ranges\n"
             f"If age columns contain ranges like '15-19', split them into `age_min` and `age_max`.\n"
             f"```python\n"
             f"df['age_min'] = df['age'].apply(lambda x: int(x.split('-')[0]))\n"
             f"df['age_max'] = df['age'].apply(lambda x: int(x.split('-')[1]))\n"
             f"```\n\n"
         
             # Calculate Percentage
             f"## Calculate Percentage\n"
             f"Use **weighted sums** for percentage calculations. Example:\n"
             f"```python\n"
             f"result = (\n"
             f"    df.groupby('province').apply(\n"
             f"        lambda x: (x['dv_sex_12m'] * x['dwt']).sum() / x['dwt'].sum() * 100\n"
             f"    ).reset_index(name='percentage')\n"
             f")\n"
             f"```\n"
         
             # Important Note on Graphs
             f"## Important Note on Graphs\n"
             f"- **Do not include any plotting or graph-related instructions**. Avoid `matplotlib`, `seaborn`, or similar libraries even if explicitly requested.\n"
         
             # Print Final Output
             f"## Print Final Output\n"
             f"Prepare the final DataFrame and print results clearly.\n"
             f"```python\n"
             f"print(result)\n"
             f"```\n\n"
         
             # Expected Output
             f"# Expected Output\n"
             f"The generated Python code must be:\n"
             f"- **Accurate** and follow best practices for data analysis.\n"
             f"- Handle missing values or irregularities correctly.\n"
         )

        try:
            # Call the generate function from the ollama library
               result = ollama.generate(
                model='codestral:22b-v0.1-q6_K',
                prompt=python_program_prompt,  # Use '=' instead of ':'
                options={
                    'temperature': 0.0  # Use '=' instead of ':' and ensure keys are quoted
                },
                stream=False  # Use '=' instead of ':'
                )

                
               # Print the generated response
               print("Matching Response:", f"The python code is:\n {result['response']}")
               generated_code = result['response']
        except Exception as e:
            print(f"An error occurred: {e}")



        
       
        fixed_code = check_and_fix_code(extract_code(generated_code))
        #print("fixed code",fixed_code)

        # Execute the generated Python code
        execution_output =""
        python_repl = PythonREPLTool()
        execution_output = python_repl.run(fixed_code)
        print("I am after execution output")
        print("fixed code",fixed_code)
        # Retry mechanism for error handling
        retries = 0
        max_retries = 2
        while retries < max_retries:
            error_detected, error_type = check_for_errors(execution_output, error_keywords)
            if error_detected:
                print("Error detected",execution_output)
                # Fix the code using LLM
                print("I am inside error detected")
                prompt = PromptTemplate(input_variables=["fixed_code", "execution_output", "csv_files_names"], template=fix_error_prompt)
                llm_fix_chain = LLMChain(prompt=prompt, llm=llm)
                response = llm_fix_chain.invoke({"fixed_code": fixed_code, "execution_output": execution_output, "csv_files_names": matching_schema_info})
                fixed_code = check_and_fix_code(extract_code(response['text']))
                print("I am after response",response['text'])
                execution_output = python_repl.run(fixed_code)
                retries += 1
                print("I am before fixed_code")
                print("fixed code",fixed_code)
                print("execution_output",execution_output)
            else:
                break
       
        
        
        
        
        # Create the LLM prompt
        insight_prompt = f"""
        You are Mike, a renowned expert known for delivering precise, insightful responses rooted in code execution and project history. Your primary goal is to offer clear, actionable feedback based on both the user’s query and execution results, ensuring alignment with the project context.
        
        Carefully assess the combined input to ensure your response is:
        - **Accurate and reliable** 
        - **Context-aware and concise**
        - **Enhanced with expert insights** where appropriate  
        Use **Markdown** for emphasis where needed.
        
        Your response must help the user fully understand the meaning and implications of the execution output within their project.
        
        ### Response Format Guidelines:
        1. **Execution Results**:  
           Display results according to the user’s instructions:
           - **Tabular Format**: Use tables for structured data.  
           - **Graphical Format**: Provide a Highcharts JSON enclosed within three backticks using the keyword `json`. Ensure variables like `'Title'`, `'data'`, `'name'`, and `'y'` values align with the Python execution results:  
             ```json
             {{
                 "Title": " ",
                 "series": [{{
                     "showInLegend": false,
                     "data": [
                         {{"name": " ", "y": }},
                         {{"name": " ", "y": }}
                     ]
                 }}]
             }}
             ```
           - **Narrative Format**: Offer a detailed explanation of the results.
        
        2. **Handling Nested Quotes**:  
           If the response contains nested quotes (quotes within quotes), escape them using a backslash (`\\`) to ensure the string is JSON-compatible.
        
        3. **Pandas Series Handling**:  
           Convert any `pandas` Series object into a Python dictionary before including it in the response.
        
        ---
        
        ### Context:
        {messages}
        
        ---
        
        ### User Query:
        {query} 
        
        ### Execution Results:
        {execution_output}
        
        ---
        
        Response:
        """
        try:
            # Call the generate function from the ollama library
               result = ollama.generate(
                model='codestral:22b-v0.1-q6_K',
                prompt=insight_prompt,  # Use '=' instead of ':'
                options={
                    'temperature': 0.0  # Use '=' instead of ':' and ensure keys are quoted
                },
                stream=False  # Use '=' instead of ':'
                )

                
               # Print the generated response
               narration = result['response']
        except Exception as e:
            print(f"An error occurred: {e}")
        
        
        
        
        print("query after narration",query)
        fullNarration = f""" We will provide an answer to the question: {query}.\n
        To achieve this, we can execute the following Python script: ```python {fixed_code} ``` \n
        The execution of this code produced the following output: {execution_output}.\n
        This output can be explained as follows:: {narration}"""
        
        
        messages.append(
            {
              'role': 'user',
              'content': original_query,
            }
          )
        messages.append(
            {
              'role': 'assistant',
              'content': narration,
            }
          )
        
        history = json.dumps(messages)
        # Build the response
        result_json = {
            "user_id": user_id,
            "thread_id": thread_id,
            "prompt_id": f"{user_id}{thread_id}",
            "query": original_query,
            "codeblock": fixed_code,
            "execution_output": execution_output,
            "narration": narration,
            "fullNarration": fullNarration,
            "context_query":"context",
            "title": 'title',
            "history": history

        }
        
        
        return result_json

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": f"There was an error processing the request: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4004)
