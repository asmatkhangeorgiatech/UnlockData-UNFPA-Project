import requests
import json
import ollama

# Define your query and schema variables
query = "Provide the data for Ever experienced physical AND sexual AND emotional violence by any partner"  # Replace with your actual query
schema = """Use the uploaded dataset "All_columns_dv_2.csv" to provide simple easy to understand output from the dataset as per user request. The schema of the dataset as well as special instruction for analysis are as follows:

**Schema of the dataset:**

dv_phy: BOOLEAN# Experienced physical violence since age 15 by any perpetrator
dv_phy_12m: BOOLEAN# Experienced physical violence in the past 12 months by any perpetrator
dv_phy_preg: BOOLEAN# Experienced physical violence during pregnancy by any perpetrator
dv_sex: BOOLEAN# Ever experienced sexual violence by any perpetrator
dv_sex_12m: BOOLEAN# Experienced sexual violence in the past 12 months by any perpetrator
dv_phy_sex_12m_f: STRING# Frequency of physical AND sexual violence experienced by any perpetrator in the last 12 months Often or Sometimes 
dv_phy_only: BOOLEAN# Experienced physical violence only by any perpetrator
dv_sex_only: BOOLEAN# Experienced sexual violence only by any perpetrator
dv_phy_sex_any: BOOLEAN# Experienced physical or sexual violence by any perpetrator
dv_viol_type: STRING# Experienced physical only, sexual only, or both by any perpetrator
dv_sex_age_10: BOOLEAN# First experienced sexual violence by age 10 by any perpetrator
dv_sex_age_12: BOOLEAN# First experienced sexual violence by age 12 by any perpetrator
dv_sex_age_15: BOOLEAN# First experienced sexual violence by age 15 by any perpetrator
dv_sex_age_18: BOOLEAN# First experienced sexual violence by age 18 by any perpetrator
dv_sex_age_22: BOOLEAN# First experienced sexual violence by age 22 by any perpetrator
dv_prtnr_phy: BOOLEAN# Ever experienced any physical violence by intimate partner
dv_prtnr_sex: BOOLEAN# Ever experienced any sexual violence by intimate partner
dv_prtnr_emot: BOOLEAN# Any emotional violence by intimate partner
dv_prtnr_phy_sex: BOOLEAN# Ever experienced physical AND sexual violence by intimate partner
dv_prtnr_phy_sex_emot: BOOLEAN# Ever experienced physical AND sexual AND emotional violence by intimate partner
dv_prtnr_phy_sex_any: BOOLEAN# Ever experienced physical OR sexual violence by intimate partner
dv_prtnr_phy_sex_emot_any: BOOLEAN# Ever experienced physical OR sexual OR emotional violence by intimate partner
dv_aprtnr_phy: BOOLEAN# Experienced physical by any partner
dv_aprtnr_sex: BOOLEAN# Experienced sexual violence by any partner
dv_aprtnr_emot: BOOLEAN# Experienced emotional violence by any partner
dv_aprtnr_phy_sex: BOOLEAN# Experienced physical and sexual violence by any partner
dv_aprtnr_phy_sex_any: BOOLEAN# Ever experienced physical OR sexual violence by any partner
dv_aprtnr_phy_sex_emot: BOOLEAN# Ever experienced physical AND sexual AND emotional violence by any partner
dv_aprtnr_phy_sex_emot_any: BOOLEAN# Ever experienced physical OR sexual OR emotional violence by any partner
dv_age: STRING# age groups of the study participants
residence: STRING# residence of the study participants. Urban or Rural.
province: STRING# province where study participants reside
marital_status: STRING# Marital status of the study participants. currently in union/living with a man, never in union, formerly in union/living with a man
work: STRING# Work status of the study participants. does not earn cash, earns cash, not employed
livingchild: STRING# Living children of the study participants. 0, 1-2, 3-4, 5+
education: STRING# Education level of the study participants. 0, 1-2, 3-4, 5+
wealth_quintile: STRING# Education level of the study participants. 0, 1-2, 3-4, 5+
ecological_zone: STRING# ecological zone of the study participants. Mountain, Hill and Terai.
ethnic_group: STRING# Ethnic group of the study participants. Brahmin/Chhetri, Dalit, Janajati, Madhesi, Muslim and Other.
dwt: FLOAT# sample weights. Any calculation should be preceded by weighting."  # Replace with your actual schema
"""
# Create the prompt
prompt = (
    f"Match the query statement with the description of each field in the schema step by step:\n"
    f"1. First, attempt to match the entire query as a single phrase with each field description. This match can be either literal or semantic.\n"
    f"2. If no match is found, reduce the query by removing one word at a time, starting from the end, and try matching the remaining phrase with the field descriptions.\n"
    f"3. Continue this process of reducing the phrase until a match is found.\n"
    f"4. Rank the fields based on the longest phrase that matches, where longer phrase matches take precedence over shorter ones. If multiple fields match on the same length of phrase, rank based on the number of matched words.\n\n"
    f"Query: {query}\n\n"
    f"Schema: {schema}\n\n"
    "Response Format:\n"
    "- Field 1: Justification (longest matched phrase and its word count)\n"
    "- Field 2: Justification (longest matched phrase and its word count)\n"
    "- Field 3: Justification (longest matched phrase and its word count)"
)






# Use ollama to generate the response
try:
    # Call the generate function from the ollama library
       result = ollama.generate(
        model='codestral:22b-v0.1-q6_K',
        prompt=prompt,  # Use '=' instead of ':'
        options={
            'temperature': 0.0  # Use '=' instead of ':' and ensure keys are quoted
        },
        stream=False  # Use '=' instead of ':'
        )

        
       # Print the generated response
       print("Matching Response:", result['response'])

except Exception as e:
    print(f"An error occurred: {e}")
