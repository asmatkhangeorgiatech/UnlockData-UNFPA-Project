import pandas as pd

# Read data from CSV file
df = pd.read_csv('assets/9_470/1728635859_All_columns_dv_2.csv')

# Function to calculate row percentages
def calc_row_percentages(df, cell_vars, col_vars, weight):
    # Create a pivot table with sum of weights
    pivot_table = df.pivot_table(
        values=weight,
        index=cell_vars,
        columns=col_vars,
        aggfunc='sum',
        margins=True,
        margins_name='All'
    )
    
    # Calculate row totals excluding the 'All' row
    row_totals = pivot_table.loc[:, pivot_table.columns != 'All'].sum(axis=1).drop('All')
    
    # Calculate percentages for each cell in rows other than 'All'
    percentages = pivot_table.loc[:, pivot_table.columns != 'All'].div(row_totals, axis=0) * 100
    
    # Calculate the overall percentages for the 'All' row separately
    overall_totals = pivot_table.loc['All', pivot_table.columns != 'All']
    overall_percentages = (overall_totals / overall_totals.sum() * 100).values
    
    # Insert the 'All' row correctly
    percentages.loc['All'] = overall_percentages
    
    return percentages.round(1)

# Define the variables
cell_vars = ['ecological_zone']
col_vars = ['dv_viol_type']
weight = 'dwt'

# Calculate the custom table
custom_table = calc_row_percentages(df, cell_vars, col_vars, weight)

# Print the table (or save it to a file)
print(custom_table)