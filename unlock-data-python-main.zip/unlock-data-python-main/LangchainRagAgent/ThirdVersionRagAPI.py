#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 12:36:56 2024

@author: asmat
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 20:27:33 2024

@author: asmat
"""

import os
import openai
from langchain import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI
from dotenv import load_dotenv
import pandas as pd
import io
import sys
from langchain_experimental.tools import PythonREPLTool
import re

# Load environment variables (OpenAI API key)
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")


# # #LLM setup (you might be using a local LLM, adjust as needed)
# from langchain_ollama import ChatOllama
# local_llm = 'codestral:22b-v0.1-q6_K'
# llm = ChatOllama(model=local_llm, temperature=0.0, num_ctx=32768)

from langchain_groq import ChatGroq
GROQ_API_KEY = "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"
llm = ChatGroq(groq_api_key=GROQ_API_KEY, temperature=0, model="llama-3.1-70b-versatile")

import re
from difflib import SequenceMatcher



def extract_schema(input_text):
    # Regular expression to capture the schema section
    schema_section = re.search(r'\*\*Schema of the dataset:\*\*\n(.*?)(?=\*\*Special instruction for analysis:\*\*|\Z)', input_text, re.DOTALL)

    # Initialize an empty list to store column information
    schema_list = []

    if schema_section:
        # Split the schema into lines and process each line
        lines = schema_section.group(1).strip().split('\n')
        for line in lines:
            # Split by the first colon to separate column name and its attributes
            column_info = line.split(':', 1)
            if len(column_info) == 2:
                column_name = column_info[0].strip()  # Extract the column name
                attributes = column_info[1].strip()  # Extract the attributes
                column_type = attributes.split('#')[0].strip()  # Extract the type

                # Extract description
                description = attributes.split('#')[1].strip() if '#' in attributes else ""
                
                # Append the column information as a dictionary to the list
                schema_list.append({
                    "column_name": column_name,
                    "type": column_type,
                    "description": description
                })

    return schema_list



from sentence_transformers import SentenceTransformer, util

# # Load the pre-trained transformer model
model = SentenceTransformer('sentence-transformers/msmarco-distilbert-base-v4')

# def find_columns_match(question, schema_dict, threshold=0.5):  # Use cosine similarity threshold
#     try:
#         # Dictionary to store file names and their matching columns with type and description
#         matching_columns = {}
#         # Define common terms for scaling weight columns
#         scaling_weight_keywords = ['weight', 'dweight', 'scaling', 'survey_weight', 'weighting']

#         # Encode the question into a vector using the transformer model
#         question_embedding = model.encode(question.lower(), convert_to_tensor=True)

#         # Loop through each file in the schema dictionary
#         for file_name, columns in schema_dict.items():
#             # List to store matching columns with their type and description for the current file
#             file_matching_columns = []

#             # First, find columns that match the question based on description similarity
#             for column in columns:
#                 column_name = column['column_name']
#                 description = column['description']
#                 col_type = column['type']

#                 # Encode the column description
#                 description_embedding = model.encode(description.lower(), convert_to_tensor=True)

#                 # Calculate cosine similarity between question and description embeddings
#                 cosine_sim = util.pytorch_cos_sim(question_embedding, description_embedding).item()

#                 # If similarity score is above the threshold, add the column details to the list
#                 if cosine_sim > threshold:
#                     file_matching_columns.append({
#                         "column_name": column_name,
#                         "type": col_type,
#                         "description": description
#                     })

#             # Next, append any scaling weight columns
#             for column in columns:
#                 column_name = column['column_name']
#                 description = column['description']
#                 col_type = column['type']

#                 # Check if the column is related to scaling weight and always add it
#                 if any(keyword in column_name.lower() or keyword in description.lower() for keyword in scaling_weight_keywords):
#                     # Ensure not to duplicate columns if they already matched
#                     if not any(col['column_name'] == column_name for col in file_matching_columns):
#                         file_matching_columns.append({
#                             "column_name": column_name,
#                             "type": col_type,
#                             "description": description + " (Scaling Weight)"
#                         })

#             # If there are matching columns, associate them with the file name in the dictionary
#             if file_matching_columns:
#                 matching_columns[file_name] = file_matching_columns

#         # Return the dictionary of matching columns or an empty dictionary if no matches found
#         return matching_columns if matching_columns else {question: []}

#     except Exception as e:
#         return {question: []}

import nltk
from nltk.corpus import stopwords
import string

# Download stopwords to ensure they are available
nltk.download('stopwords')

# Load the list of stopwords (e.g., for English)
stop_words = set(stopwords.words('english'))

# Function to clean and filter text by removing stop words and punctuation
def clean_text(text):
    # Remove punctuation and split text into words
    words = text.lower().translate(str.maketrans('', '', string.punctuation)).split()
    # Filter out stop words and return the set of cleaned keywords
    return set(word for word in words if word not in stop_words)

import re
from collections import OrderedDict

def extract_timestamp_from_filename(file_name):
    """Extracts the timestamp from the beginning of the file name."""
    # Assuming the timestamp is at the beginning of the file name and is numeric
    timestamp = re.search(r'^\d+', file_name)
    return int(timestamp.group()) if timestamp else 0

from sentence_transformers import SentenceTransformer, util
from collections import OrderedDict
import traceback  # For detailed error reporting

# Load a pre-trained Sentence Transformer model (you can try other models too)
model = SentenceTransformer('all-MiniLM-L6-v2')

def find_columns_match(question, schema_dict):
    try:
        # Validate inputs
        if not question or not isinstance(schema_dict, dict):
            raise ValueError("Invalid input: Question must be a non-empty string and schema_dict a dictionary.")

        # Dictionary to store matching columns by file name
        matching_columns = {}

        # Set to store column names that have already been matched
        matched_column_names = set()

        # Define common keywords for scaling weight columns
        scaling_weight_keywords = ['weight', 'dweight', 'scaling', 'survey_weight', 'weighting']

        # Encode the question to get its embedding
        question_embedding = model.encode(question, convert_to_tensor=True)

        # Sort schema files by timestamp in descending order (most recent first)
        sorted_schema_dict = OrderedDict(
            sorted(schema_dict.items(), key=lambda x: extract_timestamp_from_filename(x[0]), reverse=True)
        )

        # Loop through each file in the schema dictionary
        for file_name, columns in sorted_schema_dict.items():
            if not isinstance(columns, list):
                print(f"Warning: {file_name} does not contain a list of columns.")
                continue

            # Store matching columns for the current file
            file_matching_columns = []

            # First pass: Match based on semantic similarity between the question and column description
            for column in columns:
                if not isinstance(column, dict) or 'column_name' not in column or \
                   'description' not in column or 'type' not in column:
                    print(f"Warning: Invalid column format in file {file_name}. Skipping column.")
                    continue

                column_name = column['column_name'].lower()
                description = column['description'].lower()
                col_type = column['type']

                # Skip already matched columns
                if column['column_name'] in matched_column_names:
                    continue

                # Concatenate column name and description for better similarity matching
                combined_text = f"{column_name} {description}"

                # Compute embedding for the combined text
                combined_embedding = model.encode(combined_text, convert_to_tensor=True)

                # Calculate cosine similarity between question and combined text
                similarity = util.cos_sim(question_embedding, combined_embedding).item()
                print(f"Similarity between '{question}' and '{combined_text}': {similarity}")

                # If similarity exceeds the threshold, add it to the matching columns
                if similarity > 0.3:
                    file_matching_columns.append({
                        "column_name": column['column_name'],
                        "type": col_type,
                        "description": column['description']
                    })
                    matched_column_names.add(column['column_name'])

            # Second pass: Always add scaling weight columns if not matched already
            for column in columns:
                column_name = column['column_name'].lower()
                description = column['description'].lower()
                col_type = column['type']

                if column['column_name'] in matched_column_names:
                    continue

                if any(keyword in column_name or keyword in description for keyword in scaling_weight_keywords):
                    file_matching_columns.append({
                        "column_name": column['column_name'],
                        "type": col_type,
                        "description": column['description'] + " (Scaling Weight)"
                    })
                    matched_column_names.add(column['column_name'])

            # Add matching columns for the current file to the dictionary
            if file_matching_columns:
                matching_columns[file_name] = file_matching_columns

        # Return the dictionary of matching columns or an empty dictionary if none found
        return matching_columns if matching_columns else {question: []}

    except Exception as e:
        print(f"Error: {traceback.format_exc()}")
        return {question: []}





# Prompt template to generate Python code
template = """ 
You are Mike, a world-renowned Python expert in data manipulation and analysis, with a Stanford background and years of mastery. Your task is to evaluate queries and provide executable Python code focused only on data manipulation.

---

# **Guidelines**
1. **Focus on data preparation** aspects only.
2. **Exclude matplotlib or graphical instructions**, even if requested.
3. Ensure **clarity, correctness, and accuracy**. Verify outputs carefully—accuracy is essential.

---

# **Schema**
matching_columns: {matching_columns}  
csv_file_names: {csv_file_names}


# Instructions

## **Analyze Schema**
Select the relevant columns to be used in the python code exclusively from the variable 'matching_columns'.
Review the schema and data types from the `matching_columns` variable to ensure they align with expected types (e.g., `int`, `float`, `str`). 
**Always use the columns provided in `matching_columns` and avoid creating or assuming new ones**.

---

## **Import Libraries**
Import the necessary libraries for data manipulation.

```python
import pandas as pd
import numpy as np
```


## **Reading CSV Files**  
Load all CSV files from the `csv_file_names` variable into a list of DataFrames.

```python
dataframes = []
for file in csv_file_names:
    try:
        df = pd.read_csv(file)
        dataframes.append(df)
        print(f"CSV file loaded successfully.")
    except Exception as e:
        print(f"Error loading file: {{e}}")
```

## **Process Each File**  
Iterate over each file, load it using `pd.read_csv()`, store the DataFrames, clean the data, and perform any necessary calculations, such as summing weights or counting occurrences.


## **Extract Relevant Columns*  
Retrieve relevant columns based on the specific query of interest from the `matching_columns` variable and remove rows with missing values in these columns immediately.

```python
# Define relevant columns based on the query of interest
relevant_columns = [column for column in matching_columns if column in ['province', 'dv_phy', 'dweight', 'age']]  # Example selection based on interest

# Extract only the relevant columns
df = df[relevant_columns] 
``` 

## **Handling Missing Values in Relevant Columns**  
To ensure the integrity of your data, it's essential to remove any rows that contain missing values in the relevant columns.

```python
# Drop rows with missing values in the relevant columns
df = df.dropna(subset=relevant_columns)
```
## **Ensure Consistent Data Types**  
To maintain data integrity, it’s crucial to ensure that your boolean columns are correctly represented. For columns with binary values like 0 and 1, convert them to `False` and `True`. Additionally, verify that other columns, such as 'dweight', are in the appropriate data type (e.g., `float`).

```python
df['dv_phy'] = df['dv_phy'].astype(bool)
df['dweight'] = df['dweight'].astype(float)
```
## Check possible values present in relevant columns.
- **Boolean Data Type**:  
  If the data type of a column is 'Boolean', its values will either be `0` (representing `False`) or `1` (representing `True`).

- **String Data Type**:  
  If the data type is 'String', list all unique text-based values to create logical conditions or filters.

- **Float Data Type**:  
  If the data type is 'Float', ensure accurate handling of numerical operations and address any irregularities such as `NaN` or outliers.

## **Handle Age Columns with Ranges**  
Identify the column within `relevant_columns` that contains entries formatted like `15-19`. If such an age column is found, split it into two new columns: `age_min` and `age_max`.

```python
# Assuming 'age' is the identified column containing entries like '15-19'
df['age_min'] = df['age'].apply(lambda x: int(x.split('-')[0]))
df['age_max'] = df['age'].apply(lambda x: int(x.split('-')[1]))
```




# Task: {query} 

# Expected Output: The Python code generated must be syntactically correct, follow best practices for data analysis using pandas, and be robust against missing values and other anomalies.

# Python Code:

"""

# 
#template =You are **Mike**, a world-renowned Python expert in data manipulation and analysis, with a Stanford background and years of mastery. Your task is to **evaluate queries** and provide **executable Python code** focused **only on data manipulation**.  

# <Guidelines> 
# 1. Focus on the data preparation aspect of the query.  
# 2. Exclude any matplotlib or graphical instructions, even if requested.  
# 3. Prioritize clarity, correctness, and accuracy. Verify outputs thoroughly—accuracy is essential.
# </Guidelines>

# <Schema>: 
#     {matching_columns}
# </Schema> 

# <Instructions>:
# 1. **Analyze Schema**:  
#     Review the schema and data types in the {matching_columns} variable to ensure they match expected types (e.g., `int`, `float`, `str`).

# 2. **Import Libraries**:  
#     Import necessary libraries for data manipulation.
#     ```python
#     import pandas as pd
#     import numpy as np
#     ```

# 3. **Reading CSV Files**:  
#     Load all CSV files from {csv_file_names} into a list of DataFrames.
#     ```python
#     dataframes = []
#     for file in csv_file_names:
#         try:
#             df = pd.read_csv(file)
#             dataframes.append(df)
#             print(f"CSV file loaded successfully")
#         except Exception as e:
#             print(f"Error loading file")
#     ```

# 4. **Process Each File**:  
#     Use a loop to go through each file, reading each with `pd.read_csv()` and storing DataFrames in a list. Clean the data and perform calculations (e.g., summing weights).

# 5. **Extract Relevant Columns**:  
#     Get the relevant columns from the {matching_columns} variable.

# 6. **Ensure Consistent Data Types**:  
#     For boolean columns (0 and 1), convert to `False` and `True`. For age-related columns, extract lower and upper bounds from strings (e.g., "15-19").
#     ```python
#     df['age_min'] = df['Age'].apply(lambda x: int(x.split('-')[0]))
#     df['age_max'] = df['Age'].apply(lambda x: int(x.split('-')[1]))
#     ```

# 7. **Exclude Special Values**:  
#     Use `dropna()` to exclude rows with NaN or NA values in relevant columns.
#     ```python
#     df = df.dropna(subset=['province', 'dwt', 'dv_sex_12m'])
#     ```

# 8. **Use Scaling Column**:  
#     Identify the scaling column from {matching_columns} for unbiased calculations (e.g., 'dweight').
#     ```python
#     weighted_total = df['dweight'].sum()
#     ```

# 9. **Element-wise Multiplication**:  
#     Perform element-wise multiplication for calculations within groups.
#     ```python
#     weighted_phy_violence = df.groupby('province').apply(lambda x: (x['dv_phy'] * x['dwt']).sum())
#     ```

# 10. **DataFrame Manipulations**:  
#     Use filtering, grouping, and aggregation.
#     ```python
#     result = df.groupby('group_column')['target_column'].sum() 
#     ```

# 11. **Output the Results**:  
#     Display final results with appropriate labels.
#     ```python
#     print(result)
#     ```   
# </Instructions>  

# <Examples>:
# ```python
# # Example code structure to load and process CSV files
# import pandas as pd
# import numpy as np

# # Get the {{csv_file_names}} and {{matching_columns}} variables from the user query
# dataframes = []
# for file in csv_file_names:
#     try:
#         columns_info = matching_columns[file]
#         columns = [col_info['column_name'] for col_info in columns_info]
#         df = pd.read_csv(file, usecols=columns)
#         print(f"CSV file '{{file}}' loaded successfully.")
#         df.dropna(subset=columns, inplace=True)

#         # Data type conversions
#         for col_info in columns_info:
#             col = col_info['column_name']
#             col_type = col_info['type']
#             if col_type == 'BOOLEAN':
#                 df[col] = df[col].astype(bool)
#             elif col_type == 'FLOAT':
#                 df[col] = df[col].astype(float)
#             elif col_type == 'STRING':
#                 df[col] = df[col].astype(str)

#         # Example calculations
#         if 'dweight' in df.columns:
#             weighted_total = df['dweight'].sum()
#             print(f"Total weight: {{weighted_total}}")

#     except Exception as e:
#         print(f"Error processing file '{{file}}': {{e}}")



# </Examples>

# <Task>: {query} </Task>

# <Expected Output>: The Python code generated must be syntactically correct, follow best practices for data analysis using pandas, and be robust against missing values and other anomalies.</Expected Output>

# <Python Code>:
# """



# Step 1: Parse the code block (extract code between ```python and ``` tags)
def extract_code(code_block):
    if '```python' in code_block:
        return code_block.split('```python')[1].split('```')[0].strip()
    return code_block



import autopep8
import ast

def check_indentation(code):
    """
    This function checks for any IndentationError or syntax errors by parsing the code.
    """
    try:
        # Try compiling the code to check for syntax and indentation issues
        compile(code, '<string>', 'exec')
        return None  # No indentation or syntax error found
    except IndentationError as e:
        return str(e)  # Return indentation error message
    except SyntaxError:
        # Allow for syntax checking later on
        return None

def check_syntax(code):
    """
    This function uses Python's compile() function to check for syntax errors.
    """
    try:
        # Use the Python compiler to check for syntax errors
        compile(code, '<string>', 'exec')
        return None  # No syntax error found
    except SyntaxError as e:
        return str(e)  # Return the syntax error message

def fix_code(code):
    """
    This function uses autopep8 to automatically format and fix common Python code issues,
    including indentation and other PEP8 violations.
    """
    fixed_code = autopep8.fix_code(code)
    return fixed_code

def check_and_fix_code(code):
    """
    This function checks for both indentation and syntax errors, fixes them, and returns the corrected code.
    It ensures:
    1. Indentation is corrected first if needed.
    2. Syntax is then checked and corrected if necessary.
    """
    # Step 1: Check for indentation errors
    indentation_error = check_indentation(code)
    
    if indentation_error:
        print("Indentation Error Found:", indentation_error)
        print("Attempting to fix the indentation...")
        
        # Step 2: Fix indentation errors
        fixed_code = fix_code(code)
        
        # Step 3: Re-check the fixed code for syntax errors
        syntax_error = check_syntax(fixed_code)
        if syntax_error:
            print("Syntax Error Found after fixing indentation:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 4: Fix syntax errors if found
            final_code = fix_code(fixed_code)
            return final_code
        else:
            return fixed_code
    else:
        # If indentation is correct, check for syntax errors using the compiler
        syntax_error = check_syntax(code)
        if syntax_error:
            print("Syntax Error Found:", syntax_error)
            print("Attempting to fix the syntax...")
            
            # Step 5: Fix syntax errors
            final_code = fix_code(code)
            return final_code
        else:
            # If no errors found, return the original code
            return code




fix_error_prompt=""""You are an expert at correcting python code. Here is the Python code that produced an error. Please analyze the error based on instructions and provide an updated version of the code that fixes the issue.

error:
    {execution_output}
    
### Instructions:

1. **Analyze Schema**:  
    Review the schema and data types of each column to ensure the expected types (e.g., `int`, `float`, `str`).

2. **Import Libraries**:  
    Import the necessary libraries for data manipulation and analysis.

    ```python
    import pandas as pd
    import numpy as np
    ```
. **Reading CSV Files**: The code loads all CSV files from {csv_file_names} path into a list of DataFrames.
    For this purpose, follow the example code below.
    ```python
    # Initialize a list to hold all DataFrames
    dataframes = []
    
    # Load each CSV file into a DataFrame and append it to the list
    for file in csv_file_names:
        try:
            df = pd.read_csv(file)
            dataframes.append(df)
            print(f"CSV file  loaded successfully")
        except Exception as e:
            print(f"Error loading file")
    
    # Example: Accessing the first DataFrame from the list
    if dataframes:
        df = dataframes[0]  # Do something with the first DataFrame
    else:
        print("No CSV files loaded")
    ```
    
   
4. **Ensure Consistent Data Types for Comparisons**:
    For some columns, data values may be 0 and 1, which should be interpreted as False and True, respectively, when a boolean type is required.
    For oher columns, where age ranges are provided as strings (e.g., "15-19"), it is important to understand that these ranges represent people within the specified age group, including both the lower and upper bounds (i.e., from 15 to 19, inclusive). To facilitate accurate comparisons, you need to extract both the lower and upper bounds of the age range.

    Here’s an example of how to handle the **Age** string column for comparisons:
    
    ```python
    # Extract the lower and upper bounds of the age range
    df['age_min'] = df['Age'].apply(lambda x: int(x.split('-')[0]))
    df['age_max'] = df['Age'].apply(lambda x: int(x.split('-')[1]))
    
    # Example: Filter rows where age falls within a specific range (e.g., 15-19)
    filtered_df = df[(df['age_min'] <= 19) & (df['age_max'] >= 15)]
    ```
    This code splits the **Age** column into two new columns, `age_min` and `age_max`, corresponding to the lower and upper bounds of the age range. You can then use these columns to filter data or perform any age-related comparisons while ensuring inclusivity of the specified age range.
    
    
5. **Exclude Special Values in Calculations**:

    Identify and exclude rows with NaN or NA values in relevant columns by using the dropna() function.
    ```python
    # Exclude rows with NaN or NA values in relevant columns
    df = df.dropna(subset=['province', 'dwt', 'dv_sex_12m'])
    ```

   
6. **Use Scaling Column**:

    Ensure that the scaling column is used for unbiased and accurate survey calculations, particularly in cases of uneven population distribution.


    ### Example Calculations:
    Assume 'dweight' is a scaling column.
    1. **Calculate the Total Weight**:file_name
        ```python
        weighted_total = df[''dweight''].sum()
        ```
    2. **Calculate the Weighted Sum for Individuals Who Experienced Physical Violence

    ```python
    weighted_phy_violence = df[df['dv_phy'] == 1]['dweight'].sum()
    ```
    3. **Calculate the Prevalence of Physical Violence (Weighted Proportion)

    ```python
    prevalence_phy_violence = weighted_phy_violence / weighted_total
    ```
7. **Perform Element-wise Multiplication**:

    Use element-wise multiplication for calculations within groups, applying the lambda function.

    Example:

    ```python
    # Perform element-wise multiplication within groups and calculate the weighted sum
    weighted_phy_violence = df.groupby('province').apply(lambda x: (x['dv_phy'] * x['dwt']).sum())
    ```
8. **Perform DataFrame Manipulations**:

    Use DataFrame operations such as filtering, grouping, and aggregation to meet the requirements.

    ```python
    # Example: Group data by a column and calculate the sum of another column
    result = df.groupby('group_column')['target_column'].sum() 
    ```
9. **Ensure Parentheses Grouping**:
    Double-check that parentheses are correctly placed around grouped parts of an expression.
    
10. **Break Down the Expression**:
    If the expression is complex, break it down into smaller, simpler parts to verify that everything is correctly placed.
11. **Visual Matching of Parentheses**:
    When writing complex expressions, always check that each opening parenthesis `(` has a matching closing parenthesis `)`. In some code editors, the matching pair of parentheses is highlighted to help avoid this error.
12. **Indentation and Line Breaks**:
    If the expression becomes too long or hard to read, break it into multiple lines for clarity. This makes it easier to track matching parentheses. Break long expressions into multiple lines and ensure proper indentation.

Python code need to be fixed:
    {fixed_code}
    
corrected_code:
"""

# Function to check for errors in the execution output
def check_for_errors(execution_output, error_keywords):
    for keyword in error_keywords:
        if keyword in execution_output:
            return True, keyword
    return False, None
            

error_keywords = [
    'BaseException', 'SystemExit', 'KeyboardInterrupt', 'GeneratorExit', 
    'Exception', 'ArithmeticError', 'FloatingPointError', 'OverflowError', 
    'ZeroDivisionError', 'AssertionError', 'AttributeError', 'BufferError', 
    'EOFError', 'ImportError', 'ModuleNotFoundError', 'LookupError', 
    'IndexError', 'KeyError', 'MemoryError', 'NameError', 'UnboundLocalError', 
    'OSError', 'BlockingIOError', 'ChildProcessError', 'ConnectionError', 
    'BrokenPipeError', 'ConnectionAbortedError', 'ConnectionRefusedError', 
    'ConnectionResetError', 'FileExistsError', 'FileNotFoundError', 
    'InterruptedError', 'IsADirectoryError', 'NotADirectoryError', 
    'PermissionError', 'ProcessLookupError', 'TimeoutError', 
    'ReferenceError', 'RuntimeError', 'NotImplementedError', 'RecursionError', 
    'SyntaxError', 'IndentationError', 'TabError', 'SystemError', 
    'TypeError', 'ValueError', 'UnicodeError', 'UnicodeDecodeError', 
    'UnicodeEncodeError', 'UnicodeTranslateError', 'Warning', 
    'DeprecationWarning', 'PendingDeprecationWarning', 'RuntimeWarning', 
    'SyntaxWarning', 'UserWarning', 'FutureWarning', 'ImportWarning', 
    'UnicodeWarning', 'BytesWarning', 'ResourceWarning'
]

        
       



insight_template = """
You are Mike, a renowned expert with years of experience delivering precise, insightful responses based on code execution and project history.
Your priority is to provide useful and clarifying comments based on the combined input, which contains both the user’s query and the execution results. You focus on delivering accurate, actionable feedback that directly addresses the task, grounded in the project’s context.

You assess the combined input carefully based on context and ensure that your response is clear, reliable, and concise, integrating expert insights when necessary. Markdown is used for emphasis where needed.

Your response must help the user fully understand the implications of the execution output within their project.

Your response is to **display execution results** based on the user's instructions. If the user asks for output in:
- **Tabular format**, display results in tables.
- **Graphical format**, provide Highcharts JSON encloded in three backticks with keyword JSON where variable 'Title', 'data', 'name' and 'y' values to be filled based on python code execution :
```json
{{
"Title": " ",
"series": [{{
	"showInLegend": false,
	"data": [
		{{"name": " ", "y": }},
		{{"name": " ", "y": }}
		
	]
	}}
	]
}}
```
- **Narrative format**, give a detailed description based on the results.

During the response, if the response string contains quotes inside another quote (i.e., nested quotes), you must escape them using a backslash (\) to ensure that the string is valid for json.dumps().
IF the response contains pandas series object then it should be converted to Python Dictionary object.
<Context>:
{history}
</Context>

<Human>: 
    {combined_result}
<Human>




<AI>:
"""



summary_template = """
Hi, I’m here to help you craft a focused and insightful summary. A good summary should capture the key points in a clear and concise way, without losing the essence of the original material. The summary will focus on discussing the main idea and the important points supporting it, ensuring brevity and clarity.

Your task is to generate a brief, factual summary that discusses the key points of the provided text. The summary should:
1. Clearly state the main idea or central theme.
2. Highlight the key points and arguments relevant to the topic.
3. Be concise, avoiding unnecessary details or non-essential examples.
4. Use clear and straightforward language for easy understanding.
5. Maintain a neutral tone and avoid personal opinions.
6. Follow a logical structure that mirrors the original text.
7. Avoid direct quotations unless a key phrase is particularly significant.

By following these guidelines, your summary will effectively convey the essence of the original material while remaining brief and accessible.

### Text: {schema_content}

Summary:
"""

history_template = """
Your task is to generate a concise summary that offers historical context for the new query based on previous queries and narrations
in the conversation. Discuss the previous quesries and narraton as a coherent conversation. Highlight all key parts to emphasize critical points. Ensure that the summary captures the essence of the discussion 
without unnecessary details, making it useful for formulating responses even when the current query lacks clarity.

### Text: {updated_history}

### Response:
"""

Nofile_template = """
You are Mike, an expert in crafting a precise and known for your ability to generate clear and precise responses even when there is 
no schema or execution output available. Your strength lies in analyzing the query and leveraging the previous conversation's context 
to deliver accurate and relevant solutions.



### Context: {history}

### Query: {query}

### Response:
"""

context_template = """
Given a chat history and the latest user question \
which might reference context in the chat history, formulate a standalone question \
which can be understood without the chat history. Do NOT answer the question, \
just reformulate it if needed and otherwise return it as is.

<Conversation History>:
{chat_history}
<Conversation History>


<Human>: 
    {query}
</Human>

<standalone question>:
"""




title_template = """
You are Mike, an expert known for your ability to craft precise and clear titles. Your strength lies in assessing the query and making your best judgment to generate a three-word phrase that accurately represents the query. 
This title should summarize the essence of the query in three words, ensuring clarity and relevance. 
If the query is unclear, use your best judgment to clarify its meaning and create an appropriate title.

<query>
 {query}
 <\query>

Title:
"""


def load_and_match_summaries(user_id, thread_id, user_question, similarity_threshold=60):
    sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")
    
    # Check if the user/thread directory exists
    if not os.path.exists(sub_dir):
        return f"Directory for user {user_id} and thread {thread_id} does not exist."
    
    summaries = {}
    csv_files = {}
    schema_files = {}

    # Loop through all the files in the subdirectory
    for file_name in os.listdir(sub_dir):
        # Extract timestamp (numeric part at the start) and base filename for CSV files
        match = re.match(r"^(\d+)_(.+)\.(csv)", file_name)
        if match:
            timestamp = int(match.group(1))
            base_filename = match.group(2)  # Filename without extension and timestamp

            # Collect the corresponding summary and schema files based on the base filename
            summary_file_name = f"{timestamp}_summary.txt"
            schema_file_name = f"{timestamp}_schema.txt"
            summary_path = os.path.join(sub_dir, summary_file_name)
            schema_path = os.path.join(sub_dir, schema_file_name)
            csv_file_path = os.path.join(sub_dir, file_name)
            print("schema filepath",schema_path)

            # Check if both the summary and schema files exist for the current CSV file
            if os.path.exists(summary_path) and os.path.exists(schema_path):
                # Read summary content
                with open(summary_path, 'r', encoding='utf-8') as summary_file:
                    summary_content = summary_file.read()
                    print(f"Summary content for {summary_file_name}: {summary_content}")
                
                # Store the paths for later use
                summaries[summary_file_name] = summary_content
                print("summaries",summaries)
                csv_files[summary_file_name] = csv_file_path
                schema_files[summary_file_name] = schema_path
            else:
                print(f"Missing summary or schema file for {file_name}:")
                if not os.path.exists(summary_path):
                    print(f"- Missing summary file: {summary_file_name}")
                if not os.path.exists(schema_path):
                    print(f"- Missing schema file: {schema_file_name}")

    # If no summaries were found
    if not summaries:
        return "No summary files found."

    # Match user question with summaries using SequenceMatcher
    matched_summaries = match_summaries_with_question(user_question, summaries, similarity_threshold)
    print("matched summaries",matched_summaries)
    
    # Ensure that matched_summaries is a dictionary
    if isinstance(matched_summaries, dict):
        # Load corresponding CSV and schema files for matched summaries
        results = {}
        for summary_file, similarity in matched_summaries.items():
            if similarity >= similarity_threshold:
                csv_file = csv_files.get(summary_file)
                schema_file = schema_files.get(summary_file)
                print("schema file",schema_file)
                
                # Load CSV and schema if similarity exceeds threshold
                if schema_file:
                    with open(schema_file, 'r', encoding='utf-8') as schema:
                        schema_content = schema.read()
                    
                    # Store results for each file
                    results[summary_file] = {
                        "csv_filename": csv_file,
                        "schema_content": schema_content,
                        "similarity": similarity
                    }
        
        # If no results after matching
        if not results:
            return "No summaries matched the threshold."
        
        return results
    else:
        # Return an error message if matched_summaries is not a dictionary
        return matched_summaries


from fuzzywuzzy import process

def match_summaries_with_question(user_question, summaries, similarity_threshold=0.5):
    """Match the user's question against the summaries based on keyword sets with partial matching."""
    
    # Ensure summaries is a dictionary
    if not isinstance(summaries, dict):
        return "Error: summaries is not a dictionary."
    
    matched_summaries = {}
    query_keywords = extract_keywords(user_question)

    # Check if there are no keywords in the query to avoid division by zero
    if not query_keywords:
        return matched_summaries  # Return empty if no keywords are found

    query_keyword_set = set(query_keywords)

    # Iterate through the summaries and calculate matches
    for summary_file, summary_content in summaries.items():
        # Ensure summary_content is valid and iterable
        if not isinstance(summary_content, str):
            print(f"Warning: summary_content for {summary_file} is invalid. Fixing it...")
            summary_content = ""  # Fix by setting to an empty string

        # Split the string into words and filter out non-keywords
        summary_keywords_for_file = [word for word in summary_content.split() if not word.isdigit()]
        print("summary keywords:", summary_keywords_for_file)

        # Convert to a set for matching
        summary_keyword_set = set(summary_keywords_for_file)

        # Initialize a counter for matches
        matching_keywords = set()

        # Check for exact and partial matches
        for keyword in query_keyword_set:
            # Find the best match for each keyword in the summary keywords
            best_match = process.extractOne(keyword, summary_keywords_for_file)
            if best_match and best_match[1] >= 80:  # Adjust the threshold for partial matches (0-100)
                matching_keywords.add(best_match[0])  # Add the matched keyword

        # Calculate match percentage
        match_percentage = (len(matching_keywords) / len(query_keyword_set)) * 100 if query_keyword_set else 0

        # Store the similarity if it meets the threshold
        if match_percentage >= (similarity_threshold * 100):  # Convert threshold to percentage
            matched_summaries[summary_file] = match_percentage

    return matched_summaries





# Function to extract keywords from the text schema
def extract_keywords(text):
    # Remove punctuation and non-alphabetic characters
    clean_text = re.sub(r'\W+', ' ', text)
    # Convert to lowercase
    clean_text = clean_text.lower()
    # Split into words
    words = clean_text.split()
    # Extract only significant keywords (ignore common words)
    common_words = set(["the", "and", "of", "in", "to", "with", "by", "on", "for", "at", "is", "as", "a", "an"])
    keywords = [word for word in words if word not in common_words]
    return keywords

# Function to match query against keywords in the schema
def match_query_with_schema(query, schema_keywords):
    query_keywords = extract_keywords(query)
    query_keyword_set = set(query_keywords)
    schema_keyword_set = set(schema_keywords.split())
    matching_keywords = query_keyword_set.intersection(schema_keyword_set)
    
    # Check if 50% or more keywords match
    match_percentage = (len(matching_keywords) / len(query_keyword_set)) * 100
    return match_percentage >= 50


###########################################
### Now we are going to make an API
###########################################   
from flask import Flask, request, jsonify
import os
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferWindowMemory
from langchain.schema import HumanMessage, AIMessage
from langchain.memory import ChatMessageHistory, ConversationBufferMemory
from langchain.schema import messages_from_dict, messages_to_dict
import json
from collections import Counter


app = Flask(__name__)

#Define the upload directory
UPLOAD_DIR = "/var/www/html/unlock-data/backend/storage/app/public/uploads"

@app.route('/process_summary/', methods=['POST'])
def process_summary():
    try:
        # Retrieve form data: user_id, thread_id, and timestamp
        user_id = request.form.get('user_id')
        thread_id = request.form.get('thread_id')
        timestamp = request.form.get('timestamp')

        # Debugging output
        print(f"User ID: {user_id}, Thread ID: {thread_id}, Timestamp: {timestamp}")

        # Construct the directory path using user_id and thread_id
        sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")

        # Ensure the sub-directory exists
        if not os.path.exists(sub_dir):
            return jsonify({"error": "Directory not found"}), 404

        # Construct the schema file name and path based on the timestamp
        schema_file = f"{timestamp}_schema.txt"
        schema_file_path = os.path.join(sub_dir, schema_file)

        # Check if the schema file exists
        if not os.path.exists(schema_file_path):
            return jsonify({"error": "Schema file not found"}), 404

        # Read the schema file content for summarization
        with open(schema_file_path, 'r') as file:
            schema_content = file.read()

        # Placeholder: Perform summarization on the schema content (customize this part as needed)
        # Extract keywords
        keywords = extract_keywords(schema_content)
        keyword_summary = " ".join(set(keywords))  # Ensure unique keywords
    
        # title for thread
        # Count the frequency of each keyword
        keyword_counts = Counter(keywords)
        
        # Get the most common keywords (list of tuples)
        top_keywords = keyword_counts.most_common(3)
        
        # Extract only the keywords from the tuples
        top_keywords_list = [keyword for keyword, _ in top_keywords]
        
        # Join the top keywords into a title string
        title = " ".join(top_keywords_list)

        # Return the summarization result
        return jsonify({
            "user_id": user_id,
            "thread_id": thread_id,
            "timestamp": timestamp,
            "summarization": keyword_summary,
            "title": title
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500






@app.route('/execute_query/', methods=['POST'])
def execute_query():
    try:
        # Retrieve form data and uploaded files
        query = request.form.get('query')
        user_id = request.form.get('user_id')
        thread_id = request.form.get('thread_id')
        
       
        print(f"Query: {query}, User ID: {user_id}, Thread ID: {thread_id}")  # Debugging output
       
        
        # now read previous history
        sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")
        os.makedirs(sub_dir, exist_ok=True)
        history_file_path = os.path.join(sub_dir, "history.txt")
        
        # Initialize an empty variable for history content
        retrieved_chat_history = []
        
        history_content =""
        # Check if the history file already exists
        if os.path.exists(history_file_path):
            # Read existing history content
            with open(history_file_path, "r", encoding='utf-8') as history_file:
                history_content = history_file.read()
        
        # If there's content in the history file, process it
        if history_content:
            print("\n history content",history_content)
            # Deserialize the JSON content to a Python dictionary
            retrieve_from_db = json.loads(history_content)
        
            # Convert the dictionary back to List[HumanMessage | AIMessage]
            try:
                retrieved_messages = messages_from_dict(retrieve_from_db)
            except ImportError:
                # Fallback to manual deserialization if messages_from_dict is not available
                retrieved_messages = messages_from_dict(retrieve_from_db)
        
            # Limit to the last five messages
            #last_five_messages = retrieved_messages[-5:]
            last_five_messages = retrieved_messages
            
            # Construct ChatMessageHistory from the last five messages
            retrieved_chat_history = ChatMessageHistory(messages=last_five_messages)
            
            # Construct ConversationBufferMemory from ChatMessageHistory
            retrieved_memory = ConversationBufferMemory(chat_memory=retrieved_chat_history)
            
        else:
            retrieved_memory = ConversationBufferMemory(chat_memory=ChatMessageHistory(messages=[]))  # Initialized with an empty history
                
                
        ###### First we will make a context query
        prompt = PromptTemplate(input_variables=["chat_history","query"], template=context_template)
        llm_context_chain = LLMChain(prompt=prompt, llm=llm)
        context = llm_context_chain.invoke({"chat_history":retrieved_chat_history,"query":query})
        original_query = query
        query = str(context['text'])
        print("\n context query",query)
        # Ensure required parameters are present
        if not query or not user_id:
            return jsonify({"error": "Missing parameters: 'query', 'user_id', or 'thread_id'"}), 400
        
        
        # creating title    
        clean_query = re.sub(r'\W+', ' ', query).lower()
        words = clean_query.split()   
        # Count the frequency of each word
        word_counts = Counter(words)
        # Get the three most common words as keywords#LLM setup (you might be using a local LLM, adjust as needed)

        keywords = [word for word, _ in word_counts.most_common(3)]
        # Join the keywords to form a title
        title = ' '.join(keywords).title()  # Capitalize each word for the title
        

     
        
       

       

        ##### Now Retrieval job
        
        # Retrieve matching CSV and schema files
        similarity_threshold= 0.001
        # Run the function to find matches
        results = load_and_match_summaries(user_id, thread_id, query, similarity_threshold)
        if isinstance(results, str):
            # Handle error or message
            print(results)
            prompt = PromptTemplate(input_variables=["query"], template=Nofile_template)
            llm_Nofile_chain = LLMChain(prompt=prompt, llm=llm, memory = retrieved_memory)
            Nofile = llm_Nofile_chain.invoke({"query":query})
            
            # Build the response
            result_json = {
                "user_id": user_id,
                "thread_id": thread_id,
                "prompt_id": f"{user_id}{thread_id}",                
                "query": original_query,
                "codeblock": [],
                "execution_output": [],
                "narration": str(Nofile["text"]),
                "fullNarration": str(Nofile["text"]),
                "context_query":context,
                "title": title,
            }
            return result_json
        else:
            # Output the matched results
            for summary_file, result_data in results.items():
                print(f"Matched CSV File Name: result_data['csv_filename']")
                print(f"Similarity: {result_data['similarity']}")
               
        
        
        # Assuming UPLOAD_DIR, user_id, and thread_id are defined earlier in your code
        original_csv_files = []
        schema_dict = {}
        sub_dir = os.path.join(UPLOAD_DIR, f"{user_id}_{thread_id}")
        
        for summary_file, result_data in results.items():
            schema = result_data['schema_content']
            original_csv_filename = result_data['csv_filename']
            original_csv_files.append(original_csv_filename)
        
            # Extract the base file name (without the directory path)
            base_file_name = os.path.basename(original_csv_filename)
        
            # Extract schema from the input text
            extracted_schema = extract_schema(schema) if schema else []
        
            # Update schema_dict with the base file name as the key
            schema_dict[base_file_name] = extracted_schema
        
        # Print the collected schemas
        #print("\nSchema Dictionary:", schema_dict)
   
            
       
        
        
        # Find matching columns in the data
        matching_columns = find_columns_match(query, schema_dict)
        print("\n matching column", matching_columns)
        print("\n csv_files_names", original_csv_files)
        print("\n query", query)
        
       
        
       
                
        # Generate Python code using LLM chain
        prompt = PromptTemplate(input_variables=["matching_columns", "csv_file_names", "query"], template=template)
        print("I am after prompt")
        llm_chain = LLMChain(prompt=prompt, llm=llm)
        print("I am after llm_chain")
        response = llm_chain.invoke({"matching_columns": matching_columns, "csv_file_names": original_csv_files, "query": query})
        print("query after template response",query)
        generated_code = response['text']
        fixed_code = check_and_fix_code(extract_code(generated_code))
        #print("fixed code",fixed_code)

        # Execute the generated Python code
        execution_output =""
        python_repl = PythonREPLTool()
        execution_output = python_repl.run(fixed_code)
        print("I am after execution output")
        print("fixed code",fixed_code)
        # Retry mechanism for error handling
        retries = 0
        max_retries = 2
        while retries < max_retries:
            error_detected, error_type = check_for_errors(execution_output, error_keywords)
            if error_detected:
                # Fix the code using LLM
                print("I am inside error detected")
                prompt = PromptTemplate(input_variables=["fixed_code", "execution_output", "csv_file_names"], template=fix_error_prompt)
                llm_fix_chain = LLMChain(prompt=prompt, llm=llm)
                response = llm_fix_chain.invoke({"fixed_code": fixed_code, "execution_output": execution_output, "csv_file_names": original_csv_files})
                fixed_code = check_and_fix_code(extract_code(response['text']))
                print("I am after response",response['text'])
                execution_output = python_repl.run(fixed_code)
                retries += 1
                print("I am before fixed_code")
                print("fixed code",fixed_code)
                print("execution_output",execution_output)
            else:
                break
       
        
        # Create the insight prompt with the combined input
        print("I am before combined input",query,execution_output)
        combined_result = f"Query:\n{query}\n\nExecution Output:\n{execution_output}"
        print("combined_result", combined_result)
        insight_prompt = PromptTemplate(input_variables=["history", "combined_result"], template=insight_template)
        
        
        # Create the LLM chain
        insight_chain = LLMChain(prompt=insight_prompt, llm=llm, memory = retrieved_memory)
       
        # Pass the combined input and history into the invoke call
        narration = insight_chain.invoke({"combined_result": combined_result})
        print("query after narration",query)
        fullNarration = f""" We will provide an answer to the question: {query}.\n
        To achieve this, we can execute the following Python script: ```python {fixed_code} ``` \n
        The execution of this code produced the following output: {execution_output}.\n
        This output can be explained as follows:: {narration["text"]}"""
        print("The title is",title)
        
        
        # # Extract messages from memory as a list of HumanMessage or AIMessage
        extracted_messages = insight_chain.memory.chat_memory.messages
        #print("extracted messages",extracted_messages)
        ingest_to_db = messages_to_dict(extracted_messages)
        #print("I am after ingest_to_db",ingest_to_db)
        serialized_messages = json.dumps(ingest_to_db)
        #print("I am after serialized messages", serialized_messages)
        # Build the response
        result_json = {
            "user_id": user_id,
            "thread_id": thread_id,
            "prompt_id": f"{user_id}{thread_id}",
            "query": original_query,
            "codeblock": fixed_code,
            "execution_output": execution_output,
            "narration": narration,
            "fullNarration": fullNarration,
            "context_query":"context",
            "title": title,
            "history": serialized_messages

        }
        
        
        return result_json

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": f"There was an error processing the request: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4000)
