--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: countries_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.countries_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999
    CACHE 1;


ALTER TABLE public.countries_seq OWNER TO ndhsuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.countries (
    country_id integer DEFAULT nextval('public.countries_seq'::regclass) NOT NULL,
    country character varying(50) NOT NULL
);


ALTER TABLE public.countries OWNER TO ndhsuser;

--
-- Name: indicators_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.indicators_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999
    CACHE 1;


ALTER TABLE public.indicators_seq OWNER TO ndhsuser;

--
-- Name: indicators; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.indicators (
    indicator_id integer DEFAULT nextval('public.indicators_seq'::regclass) NOT NULL,
    indicator character varying(200) NOT NULL,
    section_id integer,
    survey_source_id integer DEFAULT 1 NOT NULL,
    indicator_definition text
);


ALTER TABLE public.indicators OWNER TO ndhsuser;

--
-- Name: indicators_data_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.indicators_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999
    CACHE 1;


ALTER TABLE public.indicators_data_seq OWNER TO ndhsuser;

--
-- Name: indicators_data; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.indicators_data (
    id integer DEFAULT nextval('public.indicators_data_seq'::regclass) NOT NULL,
    indicator_id integer NOT NULL,
    province_id integer,
    lookup_group_id integer,
    lookup_id integer,
    indicator_data double precision NOT NULL,
    survey_source_id integer DEFAULT 1 NOT NULL,
    country_id integer DEFAULT 1 NOT NULL,
    year integer DEFAULT 2022 NOT NULL
);


ALTER TABLE public.indicators_data OWNER TO ndhsuser;

--
-- Name: lookup_group_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.lookup_group_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999
    CACHE 1;


ALTER TABLE public.lookup_group_seq OWNER TO ndhsuser;

--
-- Name: lookup_groups; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.lookup_groups (
    lookup_group_id integer DEFAULT nextval('public.lookup_group_seq'::regclass) NOT NULL,
    lookup_group character varying(100) NOT NULL
);


ALTER TABLE public.lookup_groups OWNER TO ndhsuser;

--
-- Name: lookup_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.lookup_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 99999999
    CACHE 1;


ALTER TABLE public.lookup_seq OWNER TO ndhsuser;

--
-- Name: lookups; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.lookups (
    id integer DEFAULT nextval('public.lookup_seq'::regclass) NOT NULL,
    lookup_group_id integer NOT NULL,
    lookup_id integer NOT NULL,
    lookup character varying(100) NOT NULL
);


ALTER TABLE public.lookups OWNER TO ndhsuser;

--
-- Name: provinces_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.provinces_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999
    CACHE 1;


ALTER TABLE public.provinces_seq OWNER TO ndhsuser;

--
-- Name: provinces; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.provinces (
    province_id integer DEFAULT nextval('public.provinces_seq'::regclass) NOT NULL,
    province character varying(50) NOT NULL,
    country_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.provinces OWNER TO ndhsuser;

--
-- Name: sections_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.sections_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999
    CACHE 1;


ALTER TABLE public.sections_seq OWNER TO ndhsuser;

--
-- Name: sections; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.sections (
    section_id integer DEFAULT nextval('public.sections_seq'::regclass) NOT NULL,
    section character varying(100) NOT NULL
);


ALTER TABLE public.sections OWNER TO ndhsuser;

--
-- Name: survey_source_seq; Type: SEQUENCE; Schema: public; Owner: ndhsuser
--

CREATE SEQUENCE public.survey_source_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 99
    CACHE 1;


ALTER TABLE public.survey_source_seq OWNER TO ndhsuser;

--
-- Name: survey_source; Type: TABLE; Schema: public; Owner: ndhsuser
--

CREATE TABLE public.survey_source (
    survey_source_id integer DEFAULT nextval('public.survey_source_seq'::regclass) NOT NULL,
    survey_source character varying(30) NOT NULL
);


ALTER TABLE public.survey_source OWNER TO ndhsuser;

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.countries (country_id, country) FROM stdin;
1	Nepal
\.


--
-- Data for Name: indicators; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.indicators (indicator_id, indicator, section_id, survey_source_id, indicator_definition) FROM stdin;
1	Total Fertility Rate (number of children per woman)	1	1	\N
2	Median age at first birth women age 25-49 (years)	1	1	\N
3	Women age 15-19 who have ever been pregnant (%)	1	1	\N
4	Current use of any method of family planning (%)	2	1	\N
5	Current use of a modern method of family planning (%)	2	1	\N
6	Demand satisfied by modern methods of family planning (%)	2	1	\N
7	Unmet need for family planning	2	1	\N
8	Neonatal mortality	3	1	\N
9	Infant mortality	3	1	\N
10	Under-five mortality	3	1	\N
12	Births delivered in a health facility (%)	4	1	\N
13	Births assisted by a skilled provider3 (%)	4	1	\N
14	Children who are fully vaccinated against all basic antigens4 (%)	5	1	\N
15	Children who are fully vaccinated according to the national schedule5 (%)	5	1	\N
16	Children under age five who are stunted (%)	6	1	\N
17	Children under age five who are wasted (%)	6	1	\N
18	Children under age five who are underweight (%)	6	1	\N
19	Children age 6-23 months living with their mother fed a minimum acceptable diet6 (%)	6	1	\N
20	Women age 15-49 who achieved minimum dietary diversity7 (%)	6	1	\N
21	Household population with access to at least basic drinking water service (%)	7	1	\N
22	Household population with access to at least basic sanitation service8 (%)	7	1	\N
23	Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)	8	1	\N
24	Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)	8	1	\N
25	Married women age 15-49 who participate in household decisions9 (%)	8	1	\N
26	Women age 15-49 who have experienced physical violence since age 15 (%)	9	1	\N
27	Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months10 (%)	9	1	\N
28	Women age 15-49 who have heard of COVID-19 (%)	10	1	\N
29	Men age 15-49 who have heard of COVID-19 (%)	10	1	\N
30	Women age 15-49 with hypertension11 (%)	11	1	\N
31	Men age 15-49 with hypertension11 (%)	11	1	\N
32	Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)	12	1	\N
33	Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)	12	1	\N
34	Women age 15-49 with symptoms of anxiety according to international cutoffs12 (%)	13	1	\N
35	Men age 15-49 with symptoms of anxiety according to international cutoffs12 (%)	13	1	\N
36	Women age 15-49 with symptoms of depression according to international cutoffs13 (%)	13	1	\N
37	Men age 15-49 with symptoms of depression according to international cutoffs13 (%)	13	1	\N
11	Antenatal care (ANC) from a skilled provider	4	1	Percent distribution of women age 15–49 who had a live birth and/or stillbirth in the 2 years preceding the survey by antenatal care (ANC) provider during the pregnancy for the most recent live birth or stillbirth and percentage receiving antenatal care from a skilled provider for the most recent live birth or stillbirth
\.


--
-- Data for Name: indicators_data; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.indicators_data (id, indicator_id, province_id, lookup_group_id, lookup_id, indicator_data, survey_source_id, country_id, year) FROM stdin;
1	1	\N	1	1	2	1	1	2022
2	2	\N	1	1	21.4	1	1	2022
3	3	\N	1	1	7.8	1	1	2022
4	4	\N	1	1	60	1	1	2022
5	5	\N	1	1	39.6	1	1	2022
6	6	\N	1	1	49	1	1	2022
7	7	\N	1	1	20.7	1	1	2022
8	1	\N	1	2	2.4	1	1	2022
9	2	\N	1	2	19.5	1	1	2022
10	3	\N	1	2	20.7	1	1	2022
11	4	\N	1	2	52.6	1	1	2022
12	5	\N	1	2	44	1	1	2022
13	6	\N	1	2	56.4	1	1	2022
14	7	\N	1	2	25.5	1	1	2022
15	1	\N	1	3	1.8	1	1	2022
16	2	\N	1	3	21.2	1	1	2022
17	3	\N	1	3	12.9	1	1	2022
18	4	\N	1	3	61.3	1	1	2022
19	5	\N	1	3	45.4	1	1	2022
20	6	\N	1	3	56.1	1	1	2022
21	7	\N	1	3	19.7	1	1	2022
22	1	\N	1	4	2.4	1	1	2022
23	2	\N	1	4	19.5	1	1	2022
24	3	\N	1	4	13.5	1	1	2022
25	4	\N	1	4	55.1	1	1	2022
26	5	\N	1	4	44.6	1	1	2022
27	6	\N	1	4	61.4	1	1	2022
28	7	\N	1	4	17.6	1	1	2022
29	1	\N	1	5	3.3	1	1	2022
30	2	\N	1	5	19.2	1	1	2022
31	3	\N	1	5	22.2	1	1	2022
32	4	\N	1	5	33.2	1	1	2022
33	5	\N	1	5	27.6	1	1	2022
34	6	\N	1	5	47.6	1	1	2022
35	7	\N	1	5	24.7	1	1	2022
36	1	\N	2	1	2	1	1	2022
37	2	\N	2	1	20.8	1	1	2022
38	3	\N	2	1	12.9	1	1	2022
39	4	\N	2	1	56.9	1	1	2022
40	5	\N	2	1	40.7	1	1	2022
41	6	\N	2	1	52.4	1	1	2022
42	7	\N	2	1	20.7	1	1	2022
43	1	\N	2	2	2.4	1	1	2022
44	2	\N	2	2	20.2	1	1	2022
45	3	\N	2	2	14.9	1	1	2022
46	4	\N	2	2	58	1	1	2022
47	5	\N	2	2	46.8	1	1	2022
48	6	\N	2	2	59.2	1	1	2022
49	7	\N	2	2	21.1	1	1	2022
50	1	\N	3	1	2.7	1	1	2022
51	2	\N	3	1	20.5	1	1	2022
52	3	\N	3	1	15.8	1	1	2022
53	4	\N	3	1	62.7	1	1	2022
54	5	\N	3	1	50.1	1	1	2022
55	6	\N	3	1	61.2	1	1	2022
56	7	\N	3	1	19.1	1	1	2022
57	1	\N	3	2	1.8	1	1	2022
58	2	\N	3	2	21.1	1	1	2022
59	3	\N	3	2	12.5	1	1	2022
60	4	\N	3	2	59.1	1	1	2022
61	5	\N	3	2	41.1	1	1	2022
62	6	\N	3	2	50.3	1	1	2022
63	7	\N	3	2	22.7	1	1	2022
64	1	\N	3	3	2.2	1	1	2022
65	2	\N	3	3	20.3	1	1	2022
66	3	\N	3	3	14.1	1	1	2022
67	4	\N	3	3	5.4	1	1	2022
68	5	\N	3	3	43	1	1	2022
69	6	\N	3	3	57.2	1	1	2022
70	7	\N	3	3	19.7	1	1	2022
71	1	1	\N	\N	2.2	1	1	2022
72	2	1	\N	\N	21.6	1	1	2022
73	3	1	\N	\N	12.8	1	1	2022
74	4	1	\N	\N	61.5	1	1	2022
75	5	1	\N	\N	43.5	1	1	2022
76	6	1	\N	\N	55.1	1	1	2022
77	7	1	\N	\N	17.6	1	1	2022
78	1	1	2	1	2.2	1	1	2022
79	2	1	2	1	21.8	1	1	2022
80	3	1	2	1	9.9	1	1	2022
81	4	1	2	1	62.3	1	1	2022
82	5	1	2	1	42.9	1	1	2022
83	6	1	2	1	54.2	1	1	2022
84	7	1	2	1	16.9	1	1	2022
85	1	1	2	2	2.3	1	1	2022
86	2	1	2	2	21.3	1	1	2022
87	3	1	2	2	17.1	1	1	2022
88	4	1	2	2	60.1	1	1	2022
89	5	1	2	2	44.9	1	1	2022
90	6	1	2	2	56.8	1	1	2022
91	7	1	2	2	18.9	1	1	2022
92	1	2	\N	\N	2.7	1	1	2022
93	2	2	\N	\N	19.3	1	1	2022
94	3	2	\N	\N	19.8	1	1	2022
95	4	2	\N	\N	49	1	1	2022
96	5	2	\N	\N	40.5	1	1	2022
97	6	2	\N	\N	57.8	1	1	2022
98	7	2	\N	\N	21.1	1	1	2022
99	1	2	2	1	2.6	1	1	2022
100	2	2	2	1	19.3	1	1	2022
101	3	2	2	1	19.3	1	1	2022
102	4	2	2	1	46.5	1	1	2022
103	5	2	2	1	38.1	1	1	2022
104	6	2	2	1	55.4	1	1	2022
105	7	2	2	1	22.2	1	1	2022
106	1	2	2	2	2.7	1	1	2022
107	2	2	2	2	19.3	1	1	2022
108	3	2	2	2	21	1	1	2022
109	4	2	2	2	56	1	1	2022
110	5	2	2	2	47.4	1	1	2022
111	6	2	2	2	64.1	1	1	2022
112	7	2	2	2	17.9	1	1	2022
113	1	3	\N	\N	1.6	1	1	2022
114	2	3	\N	\N	21.9	1	1	2022
115	3	3	\N	\N	7.8	1	1	2022
116	4	3	\N	\N	66.2	1	1	2022
117	5	3	\N	\N	44.6	1	1	2022
118	6	3	\N	\N	54.3	1	1	2022
119	7	3	\N	\N	16	1	1	2022
120	1	3	2	1	1.5	1	1	2022
121	2	3	2	1	22.4	1	1	2022
122	3	3	2	1	6.9	1	1	2022
123	4	3	2	1	65.9	1	1	2022
124	5	3	2	1	42.3	1	1	2022
125	6	3	2	1	51.6	1	1	2022
126	7	3	2	1	16	1	1	2022
127	1	3	2	2	2.4	1	1	2022
128	2	3	2	2	20.4	1	1	2022
129	3	3	2	2	10.6	1	1	2022
130	4	3	2	2	67.1	1	1	2022
131	5	3	2	2	53.5	1	1	2022
132	6	3	2	2	64.5	1	1	2022
133	7	3	2	2	15.9	1	1	2022
134	1	4	\N	\N	1.4	1	1	2022
135	2	4	\N	\N	20.9	1	1	2022
136	3	4	\N	\N	12.9	1	1	2022
137	4	4	\N	\N	51.5	1	1	2022
138	5	4	\N	\N	35.1	1	1	2022
139	6	4	\N	\N	44.2	1	1	2022
140	7	4	\N	\N	28.1	1	1	2022
141	1	4	2	1	1.2	1	1	2022
142	2	4	2	1	21.2	1	1	2022
143	3	4	2	1	12.6	1	1	2022
144	4	4	2	1	49.9	1	1	2022
145	5	4	2	1	32.7	1	1	2022
146	6	4	2	1	41.9	1	1	2022
147	7	4	2	1	28.2	1	1	2022
148	1	4	2	2	1.8	1	1	2022
149	2	4	2	2	20.5	1	1	2022
150	3	4	2	2	13.9	1	1	2022
151	4	4	2	2	55.3	1	1	2022
152	5	4	2	2	40.8	1	1	2022
153	6	4	2	2	49.1	1	1	2022
154	7	4	2	2	27.7	1	1	2022
155	1	5	\N	\N	1.9	1	1	2022
156	2	5	\N	\N	20.5	1	1	2022
157	3	5	\N	\N	9.8	1	1	2022
158	4	5	\N	\N	56.5	1	1	2022
159	5	5	\N	\N	43	1	1	2022
160	6	5	\N	\N	53.8	1	1	2022
161	7	5	\N	\N	23.3	1	1	2022
162	1	5	2	1	1.8	1	1	2022
163	2	5	2	1	20.8	1	1	2022
164	3	5	2	1	10.5	1	1	2022
165	4	5	2	1	57.4	1	1	2022
166	5	5	2	1	40.5	1	1	2022
167	6	5	2	1	50.4	1	1	2022
168	7	5	2	1	23	1	1	2022
169	1	5	2	2	2.2	1	1	2022
170	2	5	2	2	20.1	1	1	2022
171	3	5	2	2	8.9	1	1	2022
172	4	5	2	2	55.5	1	1	2022
173	5	5	2	2	46.1	1	1	2022
174	6	5	2	2	58.2	1	1	2022
175	7	5	2	2	23.8	1	1	2022
176	1	6	\N	\N	2.6	1	1	2022
177	2	6	\N	\N	19.7	1	1	2022
178	3	6	\N	\N	20.5	1	1	2022
179	4	6	\N	\N	55.3	1	1	2022
180	5	6	\N	\N	45.9	1	1	2022
181	6	6	\N	\N	58.4	1	1	2022
182	7	6	\N	\N	23.4	1	1	2022
183	1	6	2	1	2.1	1	1	2022
184	2	6	2	1	19.6	1	1	2022
185	3	6	2	1	20.6	1	1	2022
186	4	6	2	1	56.2	1	1	2022
187	5	6	2	1	45	1	1	2022
188	6	6	2	1	57.5	1	1	2022
189	7	6	2	1	22.1	1	1	2022
190	1	6	2	2	3.2	1	1	2022
191	2	6	2	2	19.8	1	1	2022
192	3	6	2	2	20.4	1	1	2022
193	4	6	2	2	54.1	1	1	2022
194	5	6	2	2	47.1	1	1	2022
195	6	6	2	2	59.5	1	1	2022
196	7	6	2	2	25	1	1	2022
197	1	7	\N	\N	2.3	1	1	2022
198	2	7	\N	\N	20.3	1	1	2022
199	3	7	\N	\N	12.5	1	1	2022
200	4	7	\N	\N	58.6	1	1	2022
201	5	7	\N	\N	47	1	1	2022
202	6	7	\N	\N	58.2	1	1	2022
203	7	7	\N	\N	22.1	1	1	2022
204	1	7	2	1	2.2	1	1	2022
205	2	7	2	1	20.4	1	1	2022
206	3	7	2	1	12.2	1	1	2022
207	4	7	2	1	59	1	1	2022
208	5	7	2	1	46.5	1	1	2022
209	6	7	2	1	57	1	1	2022
210	7	7	2	1	22.6	1	1	2022
211	1	7	2	2	2.3	1	1	2022
212	2	7	2	2	20.1	1	1	2022
213	3	7	2	2	12.9	1	1	2022
214	4	7	2	2	58	1	1	2022
215	5	7	2	2	47.8	1	1	2022
216	6	7	2	2	60.3	1	1	2022
217	7	7	2	2	21.3	1	1	2022
218	1	\N	4	1	3.3	1	1	2022
219	2	\N	4	1	19.5	1	1	2022
220	3	\N	4	1	32.7	1	1	2022
221	4	\N	4	1	62.2	1	1	2022
222	5	\N	4	1	54.3	1	1	2022
223	6	\N	4	1	69	1	1	2022
224	7	\N	4	1	16.4	1	1	2022
225	1	\N	4	2	2.3	1	1	2022
226	2	\N	4	2	19.8	1	1	2022
227	3	\N	4	2	19.8	1	1	2022
228	4	\N	4	2	55.1	1	1	2022
229	5	\N	4	2	42.4	1	1	2022
230	6	\N	4	2	53.7	1	1	2022
231	7	\N	4	2	23.7	1	1	2022
232	1	\N	4	3	1.8	1	1	2022
233	2	\N	4	3	22.6	1	1	2022
234	3	\N	4	3	8.2	1	1	2022
235	4	\N	4	3	53.5	1	1	2022
236	5	\N	4	3	32.9	1	1	2022
237	6	\N	4	3	43.1	1	1	2022
238	7	\N	4	3	22.7	1	1	2022
239	1	\N	4	4	1.6	1	1	2022
240	4	\N	4	4	64.8	1	1	2022
241	5	\N	4	4	32.7	1	1	2022
242	6	\N	4	4	40.4	1	1	2022
243	7	\N	4	4	16.1	1	1	2022
244	1	\N	5	1	2.8	1	1	2022
245	2	\N	5	1	20.1	1	1	2022
246	3	\N	5	1	17.4	1	1	2022
247	4	\N	5	1	54.3	1	1	2022
248	5	\N	5	1	44.7	1	1	2022
249	6	\N	5	1	56.5	1	1	2022
250	7	\N	5	1	24.7	1	1	2022
251	1	\N	5	2	2.4	1	1	2022
252	2	\N	5	2	20.2	1	1	2022
253	3	\N	5	2	18.5	1	1	2022
254	4	\N	5	2	56.4	1	1	2022
255	5	\N	5	2	46.9	1	1	2022
256	6	\N	5	2	60.3	1	1	2022
257	7	\N	5	2	21.4	1	1	2022
258	1	\N	5	3	2.1	1	1	2022
259	2	\N	5	3	20.1	1	1	2022
260	3	\N	5	3	13.9	1	1	2022
261	4	\N	5	3	56.2	1	1	2022
262	5	\N	5	3	44.4	1	1	2022
263	6	\N	5	3	58	1	1	2022
264	7	\N	5	3	20.4	1	1	2022
265	1	\N	5	4	1.7	1	1	2022
266	2	\N	5	4	20.5	1	1	2022
267	3	\N	5	4	12.1	1	1	2022
268	4	\N	5	4	56.6	1	1	2022
269	5	\N	5	4	38.7	1	1	2022
270	6	\N	5	4	49.9	1	1	2022
271	7	\N	5	4	20.9	1	1	2022
272	1	\N	5	5	1.6	1	1	2022
273	2	\N	5	5	22.5	1	1	2022
274	3	\N	5	5	4	1	1	2022
275	4	\N	5	5	62.5	1	1	2022
276	5	\N	5	5	39	1	1	2022
277	6	\N	5	5	49.2	1	1	2022
278	7	\N	5	5	16.9	1	1	2022
279	1	\N	\N	\N	2.1	1	1	2022
280	2	\N	\N	\N	20.6	1	1	2022
281	3	\N	\N	\N	13.6	1	1	2022
282	4	\N	\N	\N	57.2	1	1	2022
283	5	\N	\N	\N	42.7	1	1	2022
284	6	\N	\N	\N	54.7	1	1	2022
285	7	\N	\N	\N	20.8	1	1	2022
286	6	\N	6	4	24	1	1	2022
287	7	\N	6	4	30.9	1	1	2022
288	6	\N	6	5	36.8	1	1	2022
289	7	\N	6	5	29.1	1	1	2022
290	6	\N	6	6	49.4	1	1	2022
291	7	\N	6	6	23.5	1	1	2022
292	6	\N	6	7	54.5	1	1	2022
293	7	\N	6	7	22	1	1	2022
294	6	\N	6	8	63.8	1	1	2022
295	7	\N	6	8	17.2	1	1	2022
296	6	\N	6	9	65.6	1	1	2022
297	7	\N	6	9	14.4	1	1	2022
298	6	\N	6	10	67.6	1	1	2022
299	7	\N	6	10	10.2	1	1	2022
300	8	\N	2	1	19	1	1	2022
301	9	\N	2	1	25	1	1	2022
302	10	\N	2	1	30	1	1	2022
303	8	\N	2	2	25	1	1	2022
304	9	\N	2	2	34	1	1	2022
305	10	\N	2	2	38	1	1	2022
306	8	\N	3	1	32	1	1	2022
307	9	\N	3	1	47	1	1	2022
308	10	\N	3	1	55	1	1	2022
309	8	\N	3	2	19	1	1	2022
310	9	\N	3	2	27	1	1	2022
311	10	\N	3	2	31	1	1	2022
312	8	\N	3	3	23	1	1	2022
313	9	\N	3	3	33	1	1	2022
314	10	\N	3	3	39	1	1	2022
315	8	1	\N	\N	20	1	1	2022
316	9	1	\N	\N	28	1	1	2022
317	10	1	\N	\N	34	1	1	2022
318	8	1	2	1	14	1	1	2022
319	9	1	2	1	22	1	1	2022
320	10	1	2	1	29	1	1	2022
321	8	1	2	2	30	1	1	2022
322	9	1	2	2	40	1	1	2022
323	10	1	2	2	43	1	1	2022
324	8	2	\N	\N	27	1	1	2022
325	9	2	\N	\N	38	1	1	2022
326	10	2	\N	\N	43	1	1	2022
327	8	2	2	1	22	1	1	2022
328	9	2	2	1	33	1	1	2022
329	10	2	2	1	38	1	1	2022
330	8	2	2	2	41	1	1	2022
331	9	2	2	2	53	1	1	2022
332	10	2	2	2	57	1	1	2022
333	8	3	\N	\N	18	1	1	2022
334	9	3	\N	\N	21	1	1	2022
335	10	3	\N	\N	24	1	1	2022
336	8	3	2	1	17	1	1	2022
337	9	3	2	1	17	1	1	2022
338	10	3	2	1	19	1	1	2022
339	8	3	2	2	21	1	1	2022
340	9	3	2	2	33	1	1	2022
341	10	3	2	2	40	1	1	2022
342	8	4	\N	\N	8	1	1	2022
343	9	4	\N	\N	19	1	1	2022
344	10	4	\N	\N	23	1	1	2022
345	8	4	2	1	2	1	1	2022
346	9	4	2	1	5	1	1	2022
347	10	4	2	1	7	1	1	2022
348	8	4	2	2	20	1	1	2022
349	9	4	2	2	44	1	1	2022
350	10	4	2	2	52	1	1	2022
351	8	5	\N	\N	24	1	1	2022
352	9	5	\N	\N	34	1	1	2022
353	10	5	\N	\N	41	1	1	2022
354	8	5	2	1	26	1	1	2022
355	9	5	2	1	35	1	1	2022
356	10	5	2	1	40	1	1	2022
357	8	5	2	2	21	1	1	2022
358	9	5	2	2	33	1	1	2022
359	10	5	2	2	43	1	1	2022
360	8	6	\N	\N	26	1	1	2022
361	9	6	\N	\N	36	1	1	2022
362	10	6	\N	\N	46	1	1	2022
363	8	6	2	1	20	1	1	2022
364	9	6	2	1	25	1	1	2022
365	10	6	2	1	32	1	1	2022
366	8	6	2	2	31	1	1	2022
367	9	6	2	2	47	1	1	2022
368	10	6	2	2	59	1	1	2022
369	8	7	\N	\N	27	1	1	2022
370	9	7	\N	\N	40	1	1	2022
371	10	7	\N	\N	49	1	1	2022
372	8	7	2	1	20	1	1	2022
373	9	7	2	1	27	1	1	2022
374	10	7	2	1	36	1	1	2022
375	8	7	2	2	37	1	1	2022
376	9	7	2	2	59	1	1	2022
377	10	7	2	2	67	1	1	2022
378	8	\N	5	1	26	1	1	2022
379	9	\N	5	1	45	1	1	2022
380	10	\N	5	1	53	1	1	2022
381	8	\N	5	2	31	1	1	2022
382	9	\N	5	2	41	1	1	2022
383	10	\N	5	2	50	1	1	2022
384	8	\N	5	3	21	1	1	2022
385	9	\N	5	3	26	1	1	2022
386	10	\N	5	3	30	1	1	2022
387	8	\N	5	4	17	1	1	2022
388	9	\N	5	4	23	1	1	2022
389	10	\N	5	4	28	1	1	2022
390	8	\N	5	5	13	1	1	2022
391	9	\N	5	5	15	1	1	2022
392	10	\N	5	5	16	1	1	2022
393	8	\N	\N	\N	21	1	1	2022
394	9	\N	\N	\N	28	1	1	2022
395	10	\N	\N	\N	33	1	1	2022
396	8	\N	7	1	26	1	1	2022
397	9	\N	7	1	41	1	1	2022
398	10	\N	7	1	50	1	1	2022
399	8	\N	7	2	28	1	1	2022
400	9	\N	7	2	36	1	1	2022
401	10	\N	7	2	41	1	1	2022
403	9	\N	\N	\N	44	1	1	2022
404	10	\N	\N	\N	49	1	1	2022
406	9	\N	\N	\N	28	1	1	2022
407	10	\N	\N	\N	30	1	1	2022
408	8	\N	7	3	15	1	1	2022
409	9	\N	7	3	21	1	1	2022
410	10	\N	7	3	24	1	1	2022
412	9	\N	\N	\N	25	1	1	2022
413	10	\N	\N	\N	29	1	1	2022
415	9	\N	\N	\N	13	1	1	2022
416	10	\N	\N	\N	16	1	1	2022
417	8	\N	7	4	7	1	1	2022
418	9	\N	7	4	8	1	1	2022
419	8	\N	8	1	24	1	1	2022
420	9	\N	8	1	30	1	1	2022
421	10	\N	8	1	35	1	1	2022
422	8	\N	8	2	17	1	1	2022
423	9	\N	8	2	27	1	1	2022
424	10	\N	8	2	30	1	1	2022
425	11	\N	1	1	96	1	1	2022
426	11	\N	1	2	92	1	1	2022
427	11	\N	1	3	91.8	1	1	2022
428	11	\N	1	4	98	1	1	2022
429	11	\N	1	5	96.3	1	1	2022
430	11	\N	2	1	94.2	1	1	2022
431	11	\N	2	2	94.6	1	1	2022
432	11	\N	3	1	93.5	1	1	2022
433	11	\N	3	2	94	1	1	2022
434	11	\N	3	3	94.6	1	1	2022
435	11	1	\N	\N	90.4	1	1	2022
436	11	1	2	1	89.6	1	1	2022
437	11	1	2	2	91.8	1	1	2022
438	11	2	\N	\N	96	1	1	2022
439	11	2	2	1	95.3	1	1	2022
440	11	2	2	2	97.9	1	1	2022
441	11	3	\N	\N	93.4	1	1	2022
442	11	3	2	1	95.9	1	1	2022
443	11	3	2	2	86.6	1	1	2022
444	11	4	\N	\N	96.7	1	1	2022
445	11	4	2	1	100	1	1	2022
446	11	4	2	2	90.5	1	1	2022
447	11	5	\N	\N	96.8	1	1	2022
448	11	5	2	1	96	1	1	2022
449	11	5	2	2	97.8	1	1	2022
450	11	6	\N	\N	91	1	1	2022
451	11	6	2	1	88	1	1	2022
452	11	6	2	2	94	1	1	2022
453	11	7	\N	\N	95.9	1	1	2022
454	11	7	2	1	94.2	1	1	2022
455	11	7	2	2	98.8	1	1	2022
456	11	\N	4	1	92.8	1	1	2022
457	11	\N	4	2	92.8	1	1	2022
458	11	\N	4	3	95.6	1	1	2022
459	11	\N	4	4	99.7	1	1	2022
460	11	\N	5	1	90.5	1	1	2022
461	11	\N	5	2	92.9	1	1	2022
462	11	\N	5	3	97	1	1	2022
463	11	\N	5	4	94.7	1	1	2022
464	11	\N	5	5	98.1	1	1	2022
465	11	\N	\N	\N	94.3	1	1	2022
466	12	\N	1	1	86.9	1	1	2022
467	12	\N	1	2	70.1	1	1	2022
468	12	\N	1	3	83.3	1	1	2022
469	12	\N	1	4	76.2	1	1	2022
470	12	\N	1	5	67.3	1	1	2022
471	12	\N	2	1	80.9	1	1	2022
472	12	\N	2	2	76.5	1	1	2022
473	12	\N	3	1	75.3	1	1	2022
474	12	\N	3	2	81.6	1	1	2022
475	12	\N	3	3	78.6	1	1	2022
476	12	1	\N	\N	81.5	1	1	2022
477	12	1	2	1	83.7	1	1	2022
478	12	1	2	2	77.3	1	1	2022
479	12	2	\N	\N	66.8	1	1	2022
480	12	2	2	1	66.6	1	1	2022
481	12	2	2	2	67.3	1	1	2022
482	12	3	\N	\N	88.3	1	1	2022
483	12	3	2	1	91.9	1	1	2022
484	12	3	2	2	78.6	1	1	2022
485	12	4	\N	\N	87.7	1	1	2022
486	12	4	2	1	94.9	1	1	2022
487	12	4	2	2	74	1	1	2022
488	12	5	\N	\N	84.4	1	1	2022
489	12	5	2	1	83.7	1	1	2022
490	12	5	2	2	85.4	1	1	2022
491	12	6	\N	\N	72.4	1	1	2022
492	12	6	2	1	75.8	1	1	2022
493	12	6	2	2	69.1	1	1	2022
494	12	7	\N	\N	86.8	1	1	2022
495	12	7	2	1	90	1	1	2022
496	12	7	2	2	81.5	1	1	2022
497	12	\N	4	1	59.6	1	1	2022
498	12	\N	4	2	74	1	1	2022
499	12	\N	4	3	90.1	1	1	2022
500	12	\N	4	4	100	1	1	2022
501	12	\N	5	1	65.8	1	1	2022
502	12	\N	5	2	73.2	1	1	2022
503	12	\N	5	3	79.6	1	1	2022
504	12	\N	5	4	87.1	1	1	2022
505	12	\N	5	5	97.6	1	1	2022
506	12	\N	\N	\N	79.4	1	1	2022
507	13	\N	3	1	76.5	1	1	2022
508	13	\N	3	2	81	1	1	2022
509	13	\N	3	3	80	1	1	2022
510	13	1	\N	\N	81.8	1	1	2022
511	13	1	2	1	84.5	1	1	2022
512	13	1	2	2	76.6	1	1	2022
513	13	2	\N	\N	68	1	1	2022
514	13	2	2	1	67.6	1	1	2022
515	13	2	2	2	69.1	1	1	2022
516	13	3	\N	\N	86.6	1	1	2022
517	13	3	2	1	90.7	1	1	2022
518	13	3	2	2	75.5	1	1	2022
519	13	4	\N	\N	89.2	1	1	2022
520	13	4	2	1	96.6	1	1	2022
521	13	4	2	2	75.2	1	1	2022
522	13	5	\N	\N	86.9	1	1	2022
523	13	5	2	1	85	1	1	2022
524	13	5	2	2	89.3	1	1	2022
525	13	6	\N	\N	72.2	1	1	2022
526	13	6	2	1	76.1	1	1	2022
527	13	6	2	2	68.4	1	1	2022
528	13	7	\N	\N	87.8	1	1	2022
529	13	7	2	1	89.6	1	1	2022
530	13	7	2	2	84.9	1	1	2022
531	13	\N	5	1	67	1	1	2022
532	13	\N	5	2	73.1	1	1	2022
533	13	\N	5	3	81.2	1	1	2022
534	13	\N	5	4	88.2	1	1	2022
535	13	\N	5	5	97.4	1	1	2022
536	13	\N	\N	\N	80.1	1	1	2022
537	13	\N	7	1	60.9	1	1	2022
538	13	\N	7	2	74.9	1	1	2022
541	13	\N	7	3	90.9	1	1	2022
544	13	\N	7	4	96.2	1	1	2022
545	11	\N	9	1	94.5	1	1	2022
546	11	\N	9	2	94.5	1	1	2022
547	11	\N	9	3	90.6	1	1	2022
548	11	\N	10	1	95.6	1	1	2022
549	11	\N	10	2	94.5	1	1	2022
550	11	\N	10	3	89.5	1	1	2022
551	11	\N	10	4	78.4	1	1	2022
552	12	\N	9	1	79.6	1	1	2022
553	12	\N	9	2	79.4	1	1	2022
554	12	\N	9	3	78.2	1	1	2022
555	12	\N	10	1	90.2	1	1	2022
556	12	\N	10	2	74.5	1	1	2022
557	12	\N	10	3	55.9	1	1	2022
558	12	\N	10	4	58.6	1	1	2022
559	12	\N	11	1	48.2	1	1	2022
560	12	\N	11	2	62.2	1	1	2022
561	12	\N	11	2	84.1	1	1	2022
562	14	\N	2	1	79.8	1	1	2022
563	15	\N	2	1	52.6	1	1	2022
564	14	\N	2	2	80.3	1	1	2022
565	15	\N	2	2	51.1	1	1	2022
566	14	\N	3	1	89.1	1	1	2022
567	15	\N	3	1	60.3	1	1	2022
568	14	\N	3	2	84.3	1	1	2022
569	15	\N	3	2	58.7	1	1	2022
570	14	\N	3	3	76.7	1	1	2022
571	15	\N	3	3	47.7	1	1	2022
572	14	1	\N	\N	80.8	1	1	2022
573	15	1	\N	\N	45	1	1	2022
574	14	1	2	1	83.3	1	1	2022
575	15	1	2	1	49.6	1	1	2022
576	14	1	2	2	76.7	1	1	2022
577	15	1	2	2	37.2	1	1	2022
578	14	2	\N	\N	67.7	1	1	2022
579	15	2	\N	\N	41.9	1	1	2022
580	14	2	2	1	68.9	1	1	2022
581	15	2	2	1	42.4	1	1	2022
582	14	2	2	2	63.7	1	1	2022
583	15	2	2	2	40.5	1	1	2022
584	14	3	\N	\N	83.4	1	1	2022
585	15	3	\N	\N	60.3	1	1	2022
586	14	3	2	1	85.7	1	1	2022
587	15	3	2	1	62.1	1	1	2022
588	14	3	2	2	78.5	1	1	2022
589	15	3	2	2	56.6	1	1	2022
590	14	4	\N	\N	93.4	1	1	2022
591	15	4	\N	\N	79.2	1	1	2022
592	14	4	2	1	96.8	1	1	2022
593	15	4	2	1	82	1	1	2022
594	14	4	2	2	89.4	1	1	2022
595	15	4	2	2	75.9	1	1	2022
596	14	5	\N	\N	85.3	1	1	2022
597	15	5	\N	\N	57.6	1	1	2022
598	14	5	2	1	82.2	1	1	2022
599	15	5	2	1	56.8	1	1	2022
600	14	5	2	2	89.2	1	1	2022
601	15	5	2	2	58.6	1	1	2022
602	14	6	\N	\N	84.3	1	1	2022
603	15	6	\N	\N	55.8	1	1	2022
604	14	6	2	1	85	1	1	2022
605	15	6	2	1	60	1	1	2022
606	14	6	2	2	83.6	1	1	2022
607	15	6	2	2	51.7	1	1	2022
608	14	7	\N	\N	88.8	1	1	2022
609	15	7	\N	\N	54	1	1	2022
610	14	7	2	1	87.2	1	1	2022
611	15	7	2	1	53.6	1	1	2022
612	14	7	2	2	92.1	1	1	2022
613	15	7	2	2	54.8	1	1	2022
614	14	\N	5	1	75.8	1	1	2022
615	15	\N	5	1	50	1	1	2022
616	14	\N	5	2	74.1	1	1	2022
617	15	\N	5	2	45.1	1	1	2022
618	14	\N	5	3	85	1	1	2022
619	15	\N	5	3	55.1	1	1	2022
620	14	\N	5	4	85.2	1	1	2022
621	15	\N	5	4	57.1	1	1	2022
622	14	\N	5	5	82.8	1	1	2022
623	15	\N	5	5	55.9	1	1	2022
624	14	\N	\N	\N	80	1	1	2022
625	15	\N	\N	\N	52.1	1	1	2022
626	14	\N	7	1	65.8	1	1	2022
627	15	\N	7	1	38.8	1	1	2022
628	14	\N	7	2	80.5	1	1	2022
629	15	\N	7	2	50.6	1	1	2022
634	14	\N	7	3	86.3	1	1	2022
635	15	\N	7	3	58.8	1	1	2022
640	14	\N	7	4	84.1	1	1	2022
641	15	\N	7	4	64.9	1	1	2022
642	14	\N	10	1	81.8	1	1	2022
643	15	\N	10	1	54.9	1	1	2022
644	14	\N	10	2	81.3	1	1	2022
645	15	\N	10	2	51.4	1	1	2022
646	14	\N	10	3	66.2	1	1	2022
647	15	\N	10	3	39.6	1	1	2022
648	14	\N	12	1	81.5	1	1	2022
649	15	\N	12	1	54.7	1	1	2022
650	14	\N	12	2	78.4	1	1	2022
651	15	\N	12	2	49.4	1	1	2022
652	14	\N	13	1	87.9	1	1	2022
653	15	\N	13	1	58.1	1	1	2022
654	14	\N	13	2	53.6	1	1	2022
655	15	\N	13	2	31.3	1	1	2022
\.


--
-- Data for Name: lookup_groups; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.lookup_groups (lookup_group_id, lookup_group) FROM stdin;
1	Ethnic group
2	Residence
3	Ecological zone
4	Education
5	Wealth quintile
6	5-Year Age Group
7	Mothers Education
8	Child Sex
10	Birth order
9	Mothers Age at birth
11	Antenatal care visits
12	Sex
13	Vaccination card
\.


--
-- Data for Name: lookups; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.lookups (id, lookup_group_id, lookup_id, lookup) FROM stdin;
1	1	1	Brahmin/Chhetri
2	1	2	Dalit
3	1	3	Janajati
4	1	4	Madhesi
5	1	5	Muslim
6	2	1	Urban
7	2	2	Rural
8	3	1	Mountain
9	3	2	Hill
10	3	3	Terai
11	4	1	No education
12	4	2	Basic education (1–8)
13	4	3	Secondary (9–12)
14	4	4	More than secondary (13 and above)
15	5	1	Lowest
16	5	2	Second
17	5	3	Middle
18	5	4	Fourth
19	5	5	Highest
20	6	1	<5
21	6	2	5–9
22	6	3	10–14
23	6	4	15–19
24	6	5	20–24
25	6	6	25–29
26	6	7	30–34
27	6	8	35–39
28	6	9	40–44
29	6	10	45–49
30	6	11	50–54
31	6	12	55–59
32	6	13	60–64
33	6	14	65–69
34	6	15	70–74
35	6	16	75–79
36	6	17	80+
37	7	1	No education
38	7	2	Basic education (1–8)
39	7	3	Secondary (9–12)
40	7	4	More than secondary (13 and above)
41	8	1	Male
42	8	2	Female
43	9	1	<20
44	9	2	20–34
45	9	3	35–49
46	10	1	1
47	10	2	2–3
48	10	3	4–5
49	10	4	6+
50	11	1	None
51	11	2	1–3
52	11	3	4+
53	12	1	Male
54	12	2	Female
55	13	1	Seen
56	13	2	Not seen or no longer has
\.


--
-- Data for Name: provinces; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.provinces (province_id, province, country_id) FROM stdin;
1	Bagmati	1
2	Gandaki	1
3	Karnali	1
4	Koshi	1
5	Lumbini	1
6	Madhesh	1
7	Sudurpashchim	1
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.sections (section_id, section) FROM stdin;
1	Fertility
2	Family Planning (among married women age 15-49)
3	Infant and Child Mortality (deaths per 1,000 live births)2
4	Maternal and Newborn Health Care
5	Child Health (among children age 12-23 months)
6	Nutrition
7	Household Water, Sanitation, and Hygiene
8	Women’s Empowerment
9	Domestic Violence
10	COVID-19
11	Hypertension
12	Disability
13	Mental Health
\.


--
-- Data for Name: survey_source; Type: TABLE DATA; Schema: public; Owner: ndhsuser
--

COPY public.survey_source (survey_source_id, survey_source) FROM stdin;
1	NDHS
\.


--
-- Name: countries_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.countries_seq', 1, true);


--
-- Name: indicators_data_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.indicators_data_seq', 655, true);


--
-- Name: indicators_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.indicators_seq', 37, true);


--
-- Name: lookup_group_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.lookup_group_seq', 13, true);


--
-- Name: lookup_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.lookup_seq', 56, true);


--
-- Name: provinces_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.provinces_seq', 7, true);


--
-- Name: sections_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.sections_seq', 13, true);


--
-- Name: survey_source_seq; Type: SEQUENCE SET; Schema: public; Owner: ndhsuser
--

SELECT pg_catalog.setval('public.survey_source_seq', 1, true);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (country_id);


--
-- Name: indicators_data indicators_data_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicators_data_pkey PRIMARY KEY (id);


--
-- Name: indicators indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_pkey PRIMARY KEY (indicator_id);


--
-- Name: lookup_groups lookup_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.lookup_groups
    ADD CONSTRAINT lookup_groups_pkey PRIMARY KEY (lookup_group_id);


--
-- Name: lookups lookup_lookup_group_uk; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.lookups
    ADD CONSTRAINT lookup_lookup_group_uk UNIQUE (lookup_group_id, lookup_id);


--
-- Name: lookups lookups_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.lookups
    ADD CONSTRAINT lookups_pkey PRIMARY KEY (id);


--
-- Name: provinces provinces_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.provinces
    ADD CONSTRAINT provinces_pkey PRIMARY KEY (province_id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (section_id);


--
-- Name: survey_source survey_source_pkey; Type: CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.survey_source
    ADD CONSTRAINT survey_source_pkey PRIMARY KEY (survey_source_id);


--
-- Name: indicators_data indicator_data_country_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicator_data_country_fk FOREIGN KEY (country_id) REFERENCES public.countries(country_id);


--
-- Name: indicators_data indicator_data_lookup_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicator_data_lookup_fk FOREIGN KEY (lookup_group_id, lookup_id) REFERENCES public.lookups(lookup_group_id, lookup_id);


--
-- Name: indicators_data indicator_data_lookup_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicator_data_lookup_group_fk FOREIGN KEY (lookup_group_id) REFERENCES public.lookup_groups(lookup_group_id);


--
-- Name: indicators_data indicator_data_province_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicator_data_province_fk FOREIGN KEY (province_id) REFERENCES public.provinces(province_id);


--
-- Name: indicators_data indicator_data_survey_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicator_data_survey_source_fk FOREIGN KEY (survey_source_id) REFERENCES public.survey_source(survey_source_id);


--
-- Name: indicators_data indicators_data_indicators_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators_data
    ADD CONSTRAINT indicators_data_indicators_fk FOREIGN KEY (indicator_id) REFERENCES public.indicators(indicator_id);


--
-- Name: indicators indicators_sections_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_sections_fk FOREIGN KEY (section_id) REFERENCES public.sections(section_id);


--
-- Name: indicators indicators_survey_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_survey_source_fk FOREIGN KEY (survey_source_id) REFERENCES public.survey_source(survey_source_id);


--
-- Name: lookups lookups_lookups_groups_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.lookups
    ADD CONSTRAINT lookups_lookups_groups_fk FOREIGN KEY (lookup_group_id) REFERENCES public.lookup_groups(lookup_group_id);


--
-- Name: provinces provinces_country_fk; Type: FK CONSTRAINT; Schema: public; Owner: ndhsuser
--

ALTER TABLE ONLY public.provinces
    ADD CONSTRAINT provinces_country_fk FOREIGN KEY (country_id) REFERENCES public.countries(country_id);


--
-- PostgreSQL database dump complete
--

