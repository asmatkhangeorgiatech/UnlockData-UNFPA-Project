import json
from langchain_community.utilities.sql_database import SQLDatabase
import psycopg2
from psycopg2.extras import DictCursor
from sqlalchemy import create_engine
import pandas as pd
import textdistance
from collections import defaultdict


db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name

db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20)
   
def getProvinceList():
    province_list = [
        "National",
        "Bagmati",
        "Gandaki",
        "Karnali",
        "Koshi",
        "Lumbini",
        "Madhesh",
        "Sudurpashchim"
    ]
    return province_list

def getStopWords():
    stop_words = [
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
        'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
        'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was',
        'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
        'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
        'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on',
        'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
        'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
        'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
    ]
    return stop_words
    
def getIndicatorList():
   
    engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}')

    # Query to select indicators
    indicatorlistsql = "select indicator from indicators order by indicator_id"

    # Executing the query and storing the result in a DataFrame
    result_df = pd.read_sql_query(indicatorlistsql, engine)

    # Convert the 'indicator' column to a list
    indicator_list = result_df['indicator'].tolist()

    return indicator_list
    
# def getLookupWithGroups():
#     engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}')

#     query = "SELECT getlookupgroup(lookup_group_id) as group, lookup FROM lookups ORDER BY lookup_group_id, lookup_id"

#     # Fetching the data
#     df = pd.read_sql_query(query, engine)
#     df['lookup'] = df['lookup'].str.replace('\u2013', '-')
#     # Grouping by the 'group' column and aggregating the 'lookup' values
#     grouped = df.groupby('group')['lookup'].apply(list).reset_index()

#     # Converting the DataFrame to a list of dictionaries (JSON format)
#     result = grouped.to_dict(orient='records')

#     # Printing the JSON result
#     json_output = json.dumps(result, indent=4)
#     return json_output


# def getLookupWithGroups():
#     engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}')

#     query = "SELECT getlookupgroup(lookup_group_id) as group, lookup FROM lookups ORDER BY lookup_group_id, lookup_id"

#     # Fetching the data
#     df = pd.read_sql_query(query, engine)
#     df['lookup'] = df['lookup'].str.replace('\u2013', '-')
    
#     # Grouping by the 'group' column and aggregating the 'lookup' values
#     grouped = df.groupby('group')['lookup'].apply(list).reset_index()

#     # Converting the DataFrame to a list of dictionaries (JSON format)
#     result = grouped.to_dict(orient='records')

#     # # Generating normalization map
#     # normalization_map = defaultdict(list)
#     # for entry in result:
#     #     group = entry['group']
#     #     for value in entry['lookup']:
#     #         normalization_map[group].append(value)
    
#     # # Optional: Convert defaultdict to a regular dict
#     # normalization_map = dict(normalization_map)

#     # Printing the JSON result for both grouped lookups and normalization map
#     json_output = result
    
    
#     return json_output



def getLookupWithGroupsOfIndicator(indicator_name):
    #engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}')

    query = f"select getlookupgroup(lookup_group_id) as group, getlookup(lookup_group_id, lookup_id) as lookup from indicators_data where getindicator(indicator_id) = '{indicator_name}' and lookup_group_id is not NULL and province_id=0 order by lookup_group_id, lookup_id"

    connection = psycopg2.connect(
    host=db_host,
    user=db_user,
    password=db_password,
    dbname=db_name,
    cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
    )

    # Fetching the data
    df = pd.read_sql_query(query, connection)
    df['lookup'] = df['lookup'].str.replace('\u2013', '-')
    # Grouping by the 'group' column and aggregating the 'lookup' values
    grouped = df.groupby('group')['lookup'].apply(list).reset_index()

    # Converting the DataFrame to a list of dictionaries (JSON format)
    result = grouped.to_dict(orient='records')

    # Printing the JSON result
    json_output = json.dumps(result, indent=4)
    return json_output



# Utility Functions
# Function to check if two words are similar enough (for spell checking)
def are_similar(word1, word2, threshold=0.8):
    return textdistance.jaro_winkler(word1, word2) > threshold


def getLookupWithGroups(indicator_name):
    #engine = create_engine(f'postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}')

    query = f"select getlookupgroup(lookup_group_id) as group from indicators_data where getindicator(indicator_id) = '{indicator_name}' and lookup_group_id is not NULL and province_id=0 order by lookup_group_id, lookup_id"

    connection = psycopg2.connect(
    host=db_host,
    user=db_user,
    password=db_password,
    dbname=db_name,
    cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
    )

    # Fetching the data
    df = pd.read_sql_query(query, connection)
   # Convert the column 'column_name' to a list
    column_list = list(set(df['group']))
    

    
    return column_list