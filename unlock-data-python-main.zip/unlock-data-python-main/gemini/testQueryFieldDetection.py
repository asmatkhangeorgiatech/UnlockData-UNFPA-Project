#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 16:14:14 2024

@author: asmat
"""

from flask import Flask, request, jsonify
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
import json
import re
import pandas as pd

llm = ChatGoogleGenerativeAI(
    model="gemini-1.5-pro",
    temperature=0,
    max_tokens=None,
    timeout=None,
    max_retries=2,
    api_key="AIzaSyCv-vtQRNrCtB6PCJ0SsH3R7AQXUUmLBpc",  # Add API key here
    # other params...
) 

df = pd.read_csv('dv_data.csv')

def calc_independent_percentages(df, cell_vars, col_vars, weight):
    results = {}
    
    # Loop through each variable in col_vars to calculate percentages independently
    for col_var in col_vars:
        # Create a pivot table for the current column
        pivot_table = df.pivot_table(
            values=weight,
            index=cell_vars,
            columns=col_var,
            aggfunc='sum',
            margins=True,
            margins_name='All'
        )
        
        # Calculate row totals for each specific column, excluding 'All'
        row_totals = pivot_table.loc[:, pivot_table.columns != 'All'].sum(axis=1).drop('All')
        
        # Calculate percentages for the current column (independently)
        percentages = pivot_table.loc[:, pivot_table.columns != 'All'].div(row_totals, axis=0) * 100
        
        # Calculate overall percentage for the 'All' row
        overall_totals = pivot_table.loc['All', pivot_table.columns != 'All']
        overall_percentages = (overall_totals / overall_totals.sum() * 100).values
        
        # Insert the 'All' row correctly
        percentages.loc['All'] = overall_percentages

        # Store the result for the current column
        results[col_var] = percentages.round(1)
    
    # Combine the results for all columns
    combined = pd.concat(results, axis=1)
    
    return combined

# Specify the filename
filename = 'dv_schema.txt'

# Open the file in read mode
with open(filename, 'r') as file:
    # Read the content of the file
    content = file.read()

# Print the content
print(content)

app = Flask(__name__)

@app.route('/execute_query/', methods=['POST'])
def execute_query():
    
    # Retrieve form data and uploaded files
    # Retrieve form data and uploaded files
    query = request.form.get('query')
    # user_id = request.form.get('user_id')
    # thread_id = request.form.get('thread_id')
    print("query",query)
   
    matching_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system", 
            "You are a helpful assistant."
        ),
        ("human", """Select the most suitable filename, field, background characteristics and weight column name from the following schema for the following query. {query} in the 
         query: {query}
         schema: {schema}
         
         Output format: The response should be in JSON format [
    {{
        "filename": "filename1",
        "fields": ["dv_phy", "dv_sex", "dv_age"],
        "background_characteristics": ["ethnic_group", "age_group"],
        "weight": "dwt"
    }},
    {{
        "filename": "filename2",
        "fields": ["field1", "field2"],
        "background_characteristics": ["characteristic1", "characteristic2"],
        "weight": "weight_column2"
    }}
    ]

         Response: 
         """    
            )
    ]
        )

    print("format",matching_prompt.format(query =query,schema=content))
    # Chain the prompt with the model
    chain = matching_prompt | llm
    
    # Invoke the chain with input data and options
   
    result = chain.invoke(
        {
            "query": str(query),
            "schema": str(content),
        }
    )
    
   # Extract the matched schema details
    selected_schema = result.content
    print(f"\nSelected Schema: {selected_schema}\n")
    
    # Convert the string to a JSON object
    # Fix the output to ensure keys are in double quotes
    selected_schema_cleaned = re.sub(r'```.*?\n?', '', selected_schema).strip()  # Remove the backticks and leading newlines
    selected_schema_cleaned = selected_schema_cleaned.strip("json").strip()
    # Ensure the keys are correctly formatted with double quotes
    selected_schema_cleaned = selected_schema_cleaned.replace("field:", '"field":').replace("background_characteristics:", '"background_characteristics":')

    print(selected_schema_cleaned)
    try:
        json_object = json.loads(selected_schema_cleaned)
        cell_vars = [json_object.get("background_characteristics")]
        col_vars = [json_object.get("field")]  # You can add more columns here if needed
        weight = [json_object.get("weight")]  # You can add more columns here if needed

        # Calculate the custom table with independent percentages
        custom_table = calc_independent_percentages(df, cell_vars, col_vars, weight)
        
        df_json = custom_table.to_json(orient='records')  # 'records' format is often useful for API responses
    
        return jsonify(df_json)
        #return custom_table  # Return the JSON object as a response
    except json.JSONDecodeError as e:
        print(f"JSON decoding error: {e}")
        return jsonify({"error": "Invalid JSON format"}), 400

        
if __name__ == "__main__":
            app.run(host="0.0.0.0", port=4008)
        
        