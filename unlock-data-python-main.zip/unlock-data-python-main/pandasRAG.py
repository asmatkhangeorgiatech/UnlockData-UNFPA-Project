#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 17:35:57 2024
https://www.kdnuggets.com/build-your-own-pandasai-with-llamaindex

%pip install llama-index-llms-ollama

!pip install llama-index

@author: asmat
"""

from dotenv import load_dotenv
import os

load_dotenv()  # Load environment variables from .env file

api_key = os.getenv("OPENAI_API_KEY")

import os
os.environ["OPENAI_API_KEY"] = api_key



# from llama_index.experimental.query_engine import PandasQueryEngine

# import pandas as pd



# # Load the Excel file
# df = pd.read_excel('test.xlsx')

# query_engine = PandasQueryEngine(df=df)

# response = query_engine.query(
#     "give me a piechart that provides insight on childreen who have residence in urban?",
# )

# print(response)


##### This is another version

# import pandas as pd
# from llama_index.core import ServiceContext
# from llama_index.experimental.query_engine import PandasQueryEngine
# from llama_index.llms.ollama import Ollama
# from llama_index.embeddings.huggingface import HuggingFaceEmbedding





# llm_ollama = Ollama(model="codestral", request_timeout=120.0)

# df = pd.read_excel('test.xlsx')
# embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-small-en-v1.5")
# service_context = ServiceContext.from_defaults(llm=llm_ollama, embed_model=embed_model)
# query_engine = PandasQueryEngine(df=df, verbose=True, llm=llm_ollama,synthesize_response=True)


# response = query_engine.query(
#     "give me a piechart that provides insight on childreen who have residence in urban?",
# )

# print(response)
####################################################################

### Now try another way

from langchain_openai import ChatOpenAI
from langchain_experimental.agents import create_pandas_dataframe_agent
from llama_index.llms.ollama import Ollama
import pandas as pd

# Load your DataFrame
#df = pd.read_csv("titanic.csv")
# Load the Excel file
df = pd.read_excel('test.xlsx')

# Initialize the language model
#llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
#llm_ollama = Ollama(model="codestral", request_timeout=120.0, temperature=0)



from langchain_experimental.llms.ollama_functions import OllamaFunctions
llm_ollama = OllamaFunctions(model="codestral", request_timeout=120.0, temperature=0)


llm = ChatOpenAI(model="gpt-4-1106-preview")

#llm = ChatOpenAI(model="gpt-4o-mini")

# bulding tools
from langchain_core.tools import Tool
from langchain_experimental.utilities import PythonREPL

python_repl = PythonREPL()
# You can create the tool to pass to an agent
repl_tool = Tool(
    name="python_repl",
    description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
    func=python_repl.run,
)

from langchain_core.tools import StructuredTool
from langchain_experimental.utilities import PythonREPL

python_repl = PythonREPL()
# You can create the tool to pass to an agent
python_repl_tool = StructuredTool.from_function(
    name="python_repl",
    description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
    func=python_repl.run,
)

#llm_with_tools = llm_ollama.bind_tools([python_repl_tool])

llm_with_tools = llm.bind_tools([python_repl_tool])



# Create the Pandas DataFrame agent
agent_executor = create_pandas_dataframe_agent(
    llm_with_tools,
    df,
    agent_type="tool-calling",
    verbose=True,
    allow_dangerous_code=True
)

# Example query
response = agent_executor.invoke({"input": "give me a comparison for all attributes  on childreen who have residence in urban?"})
print(response)
