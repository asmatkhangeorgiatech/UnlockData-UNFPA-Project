#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 15:35:29 2024
This is the API for Nepal UNFPA Project.

@author: asmat
"""


from langchain.output_parsers import ResponseSchema, StructuredOutputParser
import json
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
import re
## This is another Asmat Attempt
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pymysql
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
import os
import psycopg2
from psycopg2.extras import DictCursor
from langchain_community.utilities.sql_database import SQLDatabase
from sentence_transformers import SentenceTransformer, util
from langchain_community.llms import Ollama




# Set environment variables if needed
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# Initialize the language model
llm = ChatOllama(model="yarn-mistral:7b-128k-fp16", temperature=0, host="http://localhost:11434")
#llm = Ollama(model="yarn-mistral:7b-128k-fp16", temperature=0, host="http://localhost:11434")

# Define the entities
# indicator_field = ResponseSchema(
#     name="indicator", 
#     description="""An indicator is a specific metric used to measure and track the health, economic, or demographic characteristics\
#         of a population. Indicators are used in surveys and data collection to provide insights into various aspects of public health,\
#             socioeconomic status, and population dynamics. They are crucial for assessing the performance and impact of policies\
#                 and programs, identifying trends, and making data-driven decisions.\

# The following indicators are used to gauge these aspects:

# Antenatal care (ANC) from a skilled provider
# Births assisted by a skilled provider (%)
# Births delivered in a health facility (%)
# Children age 6-23 months living with their mother fed a minimum acceptable diet (%)
# Children under age five who are stunted (%)
# Children under age five who are underweight (%)
# Children under age five who are wasted (%)
# Children who are fully vaccinated according to the national schedule (%)
# Children who are fully vaccinated against all basic antigens (%)
# Current use of a modern method of family planning (%)
# Current use of any method of family planning (%)
# Demand satisfied by modern methods of family planning (%)
# Household population with access to at least basic drinking water service (%)
# Household population with access to at least basic sanitation service (%)
# Infant mortality
# Married women age 15-49 who participate in household decisions (%)
# Median age at first birth women age 25-49 (years)
# Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
# Men age 15-49 who have heard of COVID-19 (%)
# Men age 15-49 with hypertension (%)
# Men age 15-49 with symptoms of anxiety according to international cutoffs (%)
# Men age 15-49 with symptoms of depression according to international cutoffs (%)
# Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
# Neonatal mortality
# Total Fertility Rate (number of children per woman)
# Under-five mortality
# Unmet need for family planning
# Women age 15-19 who have ever been pregnant (%)
# Women age 15-49 who achieved minimum dietary diversity (%)
# Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
# Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months (%)
# Women age 15-49 who have experienced physical violence since age 15 (%)
# Women age 15-49 who have heard of COVID-19 (%)
# Women age 15-49 with hypertension (%)
# Women age 15-49 with symptoms of anxiety according to international cutoffs (%)
# Women age 15-49 with symptoms of depression according to international cutoffs (%)
# Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
# Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
# These indicators help to monitor and evaluate the effectiveness of health and socioeconomic interventions and to inform policy decisions. """
# )

indicator_field = ResponseSchema(
    name="indicator", 
    description="""An indicator is a key metric used to assess various aspects of population health, family planning, nutrition, and socio-economic conditions. In the context of the Nepal Demographic and Health Survey, indicators are critical for evaluating the effectiveness of health programs, understanding demographic trends, and informing policy decisions.
These indicators include measures such as antenatal care coverage, vaccination rates, child and maternal mortality, nutritional status, and access to basic services like drinking water and sanitation. They provide a comprehensive overview of the population's well-being and are used to monitor progress towards national health goals and the Sustainable Development Goals (SDGs). By tracking these indicators over time, policymakers and health professionals can identify areas that require attention and allocate resources effectively to improve public health outcomes."""
)


province_field = ResponseSchema(
    name="province", 
    description="""A province is a primary administrative division within Nepal, used to organize and report data at a sub-national level in the Nepal Demographic and Health Survey. Provinces are crucial for understanding regional disparities and trends in health, demographic, and socio-economic indicators.

The provinces in Nepal are:
- Koshi
- Madhesh
- Bagmati
- Gandaki
- Lumbini
- Karnali
- Sudurpashchim

In this context, data is disaggregated by these provinces to provide insights into regional differences in areas such as fertility rates, child and maternal health, access to services, and economic conditions. Extracting the name of the province allows for targeted analysis and more effective resource allocation, ensuring that interventions are appropriately tailored to the specific needs of each region."""
)

lookup_field = ResponseSchema(
    name="lookup", 
    description="Lookups are the specific items or values within each lookup group.\
        They represent the individual elements or choices that fall under each category of \
            a lookup group.Under the lookup group Residence, the lookups might include Urban and Rural. \
                Under  the lookup group Ecological zone, the lookups are Mountain, Hill, Terai,Under the \
                    lookup group Residence, the lookups are Urban, Rural,nder the lookup group Wealth Quintile, \
                        the lookups are Lowest, Second, Middle, Fourth, Highest,Under the lookup group Age,\
                        the lookups are <5, 5-9, 10-14, 15-19,20–24, 25–29, 30–34, 35–39, 40–44, 45–49, 50–54, \
                            55–59, 60–64, 65–69, 70–74, 75–79, 80+, Under the lookup group Education, the lookups\
                                are No education, Basic education(1-8), Secondary Education(9-12), More than secondary(13 and above),\
                                    Under the lookup group of Ethnic Group, the lookups are Brahmin/Chhetri, Dalit, Janajati, Madhesi,\
                                        Muslim. LUnder the lookup group of Mother's Education, the lookups are No education,\
    Basic education, Secondary education, More than secondary. Under the lookup group of Child Sex, the lookups are Male, Female. \
        Under the lookup group of Mother's Age, the lookups are <20, 20-34, 35-49. Under the lookup group of Birth Order, \
            the lookups are 1, 2-3, 4-5, 6+. Under the lookup group of Antenatal Care Visits, the lookups are None, 1-3, 4+. \
                Under the lookup group of Sex, the lookups are Male, Female. Under the lookup group of Vaccination card, the \
                    lookups are seen, not seen or no longer has. Under the lookup group of Age Group, the lookups are 15-49,\
                        20-29, 30-39, 40-49. Under the lookup group of Age in month, the lookups are <6, 6-11, 6-8, 9-11, 12-23, \
                            12-18, 18-23, 24-35, 36-47, 48-59. For the lookup groups of birth interval in months, the\
                                lookups are <24, 24-47, 48+. Under the lookup groups of size at birth, the lookups are very small,\
   small, average or larger. under the lookup groups of  Mothers nutritional status, the lookups are thin, normal,\
       overweigth/obese. Under lookup groups of Maternity status the lookups are pregnant, not pregnant.\
           Under the lookup groups under Employment (last 12 months), the lookups are Not employeed, Employeed for cash, \
               Employeed not for cash. Under the lookup groups of Number of living children, the lookups are 0, 1-2, 3-4, 5+.\
                   Under the lookup groups of Marital status, the lookup groups are never married, never had untimate partner, \
                       Ever had intimate partner, Ever married, married/ living together, Divorced/separated/widowed,\
                           Divorced, Widowed. Under the lookup groups of Nutritional status, the lookups are Thin, Normal, \
                               Overweight, Obese, Not weighed or measured."
 
)
lookup_group_field = ResponseSchema(
    name="lookup_group", 
    description="Lookup groups are categories or classifications that help organize related items or characteristics. They act as a high-level grouping for different types of data or attributes.\
such as Ethnic group,Residence,Ecological zone,Education,Wealth quintile,Age Group,Mothers Education,Child Sex, Birth order, Mothers Age at birth, Antenatal care visits, Sex, Vaccination cardare examples of lookup groups."
)

# Schema with all entities to be extracted
ner_output_schema_parser = StructuredOutputParser.from_response_schemas(
    [indicator_field, province_field, lookup_field, lookup_group_field]
)
ner_output_schema = ner_output_schema_parser.get_format_instructions()


#### Try to use jsonformer
##########################
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig, BitsAndBytesConfig
import torch
     

# Load model directly
from transformers import AutoTokenizer, AutoModelForCausalLM

# tokenizer = AutoTokenizer.from_pretrained("NousResearch/Llama-2-7b-chat-hf")
# model = AutoModelForCausalLM.from_pretrained("NousResearch/Llama-2-7b-chat-hf")

# import torch
# from transformers import AutoTokenizer, AutoModelForCausalLM

# print("Loading model and tokenizer...")
# model_id = 'daryl149/llama-2-7b-chat-hf'

# # Check if CUDA is available
# if torch.cuda.is_available():
#     config = AutoConfig.from_pretrained(model_id)
#     config.pretraining_tp = 1
#     model = AutoModelForCausalLM.from_pretrained(
#         model_id,
#         config=config,
#         torch_dtype=torch.float16,
#         quantization_config=BitsAndBytesConfig(
#             load_in_4bit=True, 
#             bnb_4bit_quant_type="nf4", 
#             bnb_4bit_compute_dtype="float16", 
#             bnb_4bit_use_double_quant=True
#         ),
#         device_map='auto'
#     )
# else:
#     model = AutoModelForCausalLM.from_pretrained(model_id)

# tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True, use_cache=True)






# print("Loaded model and tokenizer")




from jsonformer.format import highlight_values
from langchain_experimental.llms import JsonFormer

# import os
# access_token = os.environ.get("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")
# from huggingface_hub import login

# login(token="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")


# survey = {
#     "indicaor":{"type": "string"},
#     "province":{"type": "string"},
#     "lookup_group":{"type": "string"},
#     "lookup":{"type": "string"}
#     }

# print("Loading model and tokenizer...")
# model_id = 'meta-llama/Llama-2-7b-chat-hf'
# if torch.cuda.is_available():
#     config = AutoConfig.from_pretrained(model_id)
#     config.pretraining_tp = 1
#     model = AutoModelForCausalLM.from_pretrained(
#         model_id,
#         config=config,
#         torch_dtype=torch.float16,
#         quantization_config=BitsAndBytesConfig(
#         load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype="float16", bnb_4bit_use_double_quant=True
#     ),
#         device_map='auto'
#     )
# tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True, use_cache=True)
# print("Loaded model and tokenizer")


tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-chat-hf")
model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-chat-hf")
print("loaded model successfully")

# from langchain_huggingface import HuggingFacePipeline
# from transformers import pipeline

# hf_model = pipeline(
#     "text-generation", model="NousResearch/Llama-2-7b-chat-hf",max_new_tokens=200,temperature=0.1
# )

# tokenizer = AutoTokenizer.from_pretrained("databricks/dolly-v2-12b")
# model = AutoModelForCausalLM.from_pretrained("databricks/dolly-v2-12b")
     
survey = {
"type": "object",
    "properties": {
        "indicator": {
            "type": "string",
            },
        "province": {
            "type": "string",
            },
        
        "lookup_group": {
            "type": "string",
            },
        },
        "lookup": {
            "type": "string",
            }
        
}



prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Given the text below, identify the entities according to the following categories:\
            Entities to identify: Indicator, Province, Lookup, Lookup Group\
\
            << FORMATTING >>\
            {format_instructions}\
\
            << OUTPUT >>\
            indicaor:[],\
            province:[],\
            lookup_group:[],\
            lookup:[]"
        ),
        ("human", "{input}"),
    ]
)

chain = prompt | llm
# response = chain.invoke(
#     {
#         "format_instructions": ner_output_schema,
#         "input": "How does the use of family planning methods vary by age group?",
#     }
# )




def extract_json(text):
    # Find the JSON part in the text using a regular expression
    json_match = re.search(r'\{.*?\}', text, re.DOTALL)
    if json_match:
        return json_match.group()
    else:
        raise ValueError("No JSON object found in the text")



def clean_json(text):
    # Convert the input to a string if it's not already
    if not isinstance(text, str):
        text = json.dumps(text)
    
    # Remove any unwanted SQL wrappers if present
    if text.lstrip().startswith("```json"):
        text = text.lstrip()[len("```json"):].strip()
    
    if text.rstrip().endswith("```"):
        text = text.rstrip()[:-len("```")].strip()
    
    # Remove comments (if any)
    text = re.sub(r'//.*', '', text)  # Removes single-line comments
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)  # Removes multi-line comments
    
    # Remove trailing commas before closing braces or brackets
    text = re.sub(r',\s*([}\]])', r'\1', text)
    
    # Ensure property names and string values are enclosed in double quotes
    text = re.sub(r"(\w+):", r'"\1":', text)  # Convert unquoted property names to quoted names
    text = re.sub(r"(\s\w+)\s*:", r'"\1":', text)  # Handle property names with leading whitespace

    # Attempt to load the cleaned text as JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON format: {e}")





# # Extract the JSON from the input text
# json_text = extract_json(response.content)

# # Clean and validate the extracted JSON
# try:
#     valid_json = clean_json(json_text)
#     print("Successfully cleaned and validated JSON:")
#     print(json.dumps(valid_json, indent=4))  # Print formatted JSON
# except ValueError as e:
#     print(e)




def remove_sql_wrappers(text):
    # Check if the input is a string
    if isinstance(text, str):
        # Remove the ```json wrapper from the beginning (with optional spaces)
        if text.lstrip().startswith("```json"):
            text = text.lstrip()[len("```json"):].strip()

        # Remove the ``` wrapper from the end (with optional spaces)
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-len("```")].strip()
    else:
        # If the input is a dictionary, convert it to a JSON string
        text = json.dumps(text)

    return text

def clean_invalid_json(text):
    # Remove comments (any text after // or /* */)
    text = re.sub(r'//.*', '', text)  # Removes single-line comments
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)  # Removes multi-line comments
    
    # Remove trailing commas before closing braces or brackets
    text = re.sub(r',\s*([}\]])', r'\1', text)

    return text

# # Get the cleaned text without SQL wrappers
# cleaned_text = remove_sql_wrappers(valid_json)

# # Further clean the JSON text for invalid `null` cases and general JSON format issues
# cleaned_text = clean_invalid_json(cleaned_text)

# print('cleaned text:', cleaned_text)

# # Convert JSON string to dictionary
# try:
#     extracted_entities = json.loads(cleaned_text)
#     print("Successfully decoded JSON")
#     print(extracted_entities)
# except json.JSONDecodeError as e:
#     print(f"Error decoding JSON: {e}")
#     extracted_entities = {}



# Predefined lists for entity matching
indicators_list = [
    "Antenatal care (ANC) from a skilled provider",
    "Births assisted by a skilled provider (%)",
    "Births delivered in a health facility (%)",
    "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
    "Children under age five who are stunted (%)",
    "Children under age five who are underweight (%)",
    "Children under age five who are wasted (%)",
    "Children who are fully vaccinated according to the national schedule (%)",
    "Children who are fully vaccinated against all basic antigens (%)",
    "Current use of a modern method of family planning (%)",
    "Current use of any method of family planning (%)",
    "Demand satisfied by modern methods of family planning (%)",
    "Household population with access to at least basic drinking water service (%)",
    "Household population with access to at least basic sanitation service (%)",
    "Infant mortality",
    "Married women age 15-49 who participate in household decisions (%)",
    "Median age at first birth women age 25-49 (years)",
    "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
    "Men age 15-49 who have heard of COVID-19 (%)",
    "Men age 15-49 with hypertension (%)",
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Men age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Neonatal mortality",
    "Total Fertility Rate (number of children per woman)",
    "Under-five mortality",
    "Unmet need for family planning",
    "Women age 15-19 who have ever been pregnant (%)",
    "Women age 15-49 who achieved minimum dietary diversity (%)",
    "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
    "Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)",
    "Women age 15-49 who have experienced physical violence since age 15 (%)",
    "Women age 15-49 who have heard of COVID-19 (%)",
    "Women age 15-49 with hypertension (%)",
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
    "Antenatal care (ANC) from a skilled provider",
    "Births assisted by a skilled provider (%)",
    "Children who are fully vaccinated against all basic antigens (%)",
    "Children who are fully vaccinated according to the national schedule (%)",
    "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
    "Women age 15-49 who achieved minimum dietary diversity (%)",
    "Household population with access to at least basic sanitation service (%)",
    "Married women age 15-49 who participate in household decisions (%)",
    "Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)",
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
    "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Men age 15-49 with symptoms of depression according to international cutoffs (%)",
    "Women age 15 and above with hypertension (%)",
    "Men age 15 and above with hypertension (%)"
]

province_list = [
    "Bagmati",
    "Gandaki",
    "Karnali",
    "Koshi",
    "Lumbini",
    "Madhesh",
    "Sudurpashchim"
]

lookups_list = [
    "Brahmin/Chhetri",
    "Dalit",
    "Janajati",
    "Madhesi",
    "Muslim",
    "Urban",
    "Rural",
    "Mountain",
    "Hill",
    "Terai",
    "No education",
    "Basic education (1–8)",
    "Secondary (9–12)",
    "More than secondary (13 and above)",
    "Lowest",
    "Second",
    "Middle",
    "Fourth",
    "Highest",
    "<5",
    "5–9",
    "10–14",
    "15–19",
    "20–24",
    "25–29",
    "30–34",
    "35–39",
    "40–44",
    "45–49",
    "50–54"
]

lookup_groups_list = [
    "Ethnic group",
    "Residence",
    "Ecological zone",
    "Education",
    "Wealth quintile",
    "5-Year Age Group",
    "Mothers Education",
    "Child Sex",
    "Birth order",
    "Mothers Age at birth",
    "Antenatal care visits",
    "Sex",
    "Vaccination card"
]

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np



###### For Matching Purposes #############
# Load the pre-trained sentence transformer model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Encode predefined lists into vectors
indicator_vectors = model.encode(indicators_list, convert_to_tensor=True)
province_vectors = model.encode(province_list, convert_to_tensor=True)
lookup_vectors = model.encode(lookups_list, convert_to_tensor=True)
lookup_group_vectors = model.encode(lookup_groups_list, convert_to_tensor=True)

def match_entities(extracted_entities):
    matched_entities = {
        "Indicators": [],
        "Provinces": [],
        "Lookups": [],
        "Lookup_groups": []
    }

    def get_matches(entity, vectors, list_items):
        if not entity:
            return []
        # Encode the entity
        entity_vector = model.encode(entity, convert_to_tensor=True)
        # Compute cosine similarities
        similarities = util.pytorch_cos_sim(entity_vector, vectors)[0]
        # Find all indices where similarity is 0.7 or higher
        matched_indices = [i for i, sim in enumerate(similarities) if sim >= 0.7]
        return [(list_items[i], similarities[i].item()) for i in matched_indices]

    for entity_type, entity_list in extracted_entities.items():
        for entity in entity_list:
            if entity_type == "indicator":
                matches = get_matches(entity, indicator_vectors, indicators_list)
                matched_entities["Indicators"].extend([match[0] for match in matches])
            elif entity_type == "province":
                matches = get_matches(entity, province_vectors, province_list)
                matched_entities["Provinces"].extend([match[0] for match in matches])
            elif entity_type == "lookup":
                matches = get_matches(entity, lookup_vectors, lookups_list)
                matched_entities["Lookups"].extend([match[0] for match in matches])
            elif entity_type == "lookup_group":
                matches = get_matches(entity, lookup_group_vectors, lookup_groups_list)
                matched_entities["Lookup_groups"].extend([match[0] for match in matches])

    return matched_entities








# Match entities with the predefined lists
def convert_to_lists(extracted_entities):
    converted_entities = {}
    for key, value in extracted_entities.items():
        if value is None:
            # Handle None values as empty lists
            converted_entities[key] = []
        elif isinstance(value, list):
            # If it's already a list, use it as is
            converted_entities[key] = value
        else:
            # Convert single values to a list
            converted_entities[key] = [value]
    return converted_entities



# converted_entities = convert_to_lists(extracted_entities)
# print('converted entities',converted_entities)

# matched_entities = match_entities(converted_entities)
# print('matched entities',matched_entities)




# # Extract values from the dictionary
# indicator_names = matched_entities.get('indicators', [])
# province_names = matched_entities.get('provinces', [])
# lookup_group_names = matched_entities.get('lookup_groups', [])
# lookup_names = matched_entities.get('lookups', [])

# Helper function to format lists for SQL IN clause
def format_for_sql(names_list):
    if names_list:
        return ', '.join(f"'{name}'" for name in names_list)
    return ''  # Return an empty string if the list is empty



####### Now we EW MKING API ####################
# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name

db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20
)
# # Initialize FastAPI
# app = FastAPI()


app = FastAPI()

# Allow all origins (useful for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

class QueryRequest(BaseModel):
    query: str

# Define a route to handle query requests
@app.post("/execute_query")
async def execute_query(query_request: QueryRequest):
    r_data = query_request.dict()
    try:
        
        # Original query from request
        original_query = r_data['query']
        print("I am here")
        prompt = f"""
        You job is to identify the  based on the natural language query given below according to the following categories. If the relevant information is not available in the given query, leave that entity as empty:\
        Use a step-by-step porcess, In the first step, find the the relevant infomation about each entity, then in next step use the relevant information for each entity, to identify the enity, Entities to identify: Indicator, Province, Lookup, Lookup Group\
            For identifying the entities from a given user query text, you will consult the instructions.
            {ner_output_schema}
            
            Query:
            {original_query}    
            You must respond using JSON format:
                """

        json_former = JsonFormer(
            pipeline=hf_model,
            json_schema=survey
        )

        results = json_former.predict(prompt)
        print(results)
        
        

        # response = chain.invoke(
        #     {
        #         "format_instructions": ner_output_schema,
        #         "input": original_query,
        #     }
        # )
        
        # # Extract the JSON from the input text
        # json_text = extract_json(response.content)
        
        # # Clean and validate the extracted JSON
        # try:
        #     valid_json = clean_json(json_text)
        #     print("Successfully cleaned and validated JSON:")
        #     print(json.dumps(valid_json, indent=4))  # Print formatted JSON
        # except ValueError as e:
        #     print(e)

        # # Get the cleaned text without SQL wrappers
        # cleaned_text = remove_sql_wrappers(valid_json)

        # # Further clean the JSON text for invalid `null` cases and general JSON format issues
        # cleaned_text = clean_invalid_json(cleaned_text)

        # print('cleaned text:', cleaned_text)

        # # Convert JSON string to dictionary
        # try:
        #     extracted_entities = json.loads(cleaned_text)
        #     print("Successfully decoded JSON")
        #     print(extracted_entities)
        # except json.JSONDecodeError as e:
        #     print(f"Error decoding JSON: {e}")
        #     extracted_entities = {}
        
        
        
        # converted_entities = convert_to_lists(extracted_entities)
        # print('converted entities',converted_entities)

        # matched_entities = match_entities(converted_entities)
        # print('matched entities',matched_entities)




        # # Extract values from the dictionary
        # indicator_names = matched_entities.get('indicators', [])
        # province_names = matched_entities.get('provinces', [])
        # lookup_group_names = matched_entities.get('lookup_groups', [])
        # lookup_names = matched_entities.get('lookups', [])
        
        
        # # Construct SQL conditions with handling for empty lists
        # indicator_condition = f"i.indicator IN ({format_for_sql(indicator_names)})" if indicator_names else "1=1"
        # province_condition = f"p.province IN ({format_for_sql(province_names)})" if province_names else "1=1"
        # lookup_group_condition = f"lg.lookup_group IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
        # lookup_condition = f"l.lookup IN ({format_for_sql(lookup_names)}) AND lg.lookup_group_id = l.lookup_group_id" if lookup_names else "1=1"

        # # Construct the final SQL query using f-strings
        # sql_query = f"""
        # WITH filtered_data AS (
        #     SELECT 
        #         id.* 
        #     FROM 
        #         indicators_data id
        #     LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
        #     LEFT JOIN provinces p ON id.province_id = p.province_id
        #     LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
        #     LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
        #     WHERE 
        #         {indicator_condition} AND
        #         ({province_condition}) AND
        #         ({lookup_group_condition}) AND
        #         ({lookup_condition})
        # )
        # SELECT 
        #     i.indicator,
        #     COALESCE(p.province, 'National') AS province,
        #     COALESCE(lg.lookup_group, 'N/A') AS lookup_group,
        #     COALESCE(l.lookup, 'N/A') AS lookup,
        #     id.indicator_data AS value,
        #     id.survey_source_id,
        #     id.year
            
        # FROM 
        #     filtered_data id
        # LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
        # LEFT JOIN provinces p ON id.province_id = p.province_id
        # LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
        # LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
        # ORDER BY 
        #     i.indicator,
        #     p.province,
        #     lg.lookup_group,
        #     l.lookup;
        # """

        # print(sql_query)
        
        # generated_sql_query = sql_query
        
        
        # connection = psycopg2.connect(
        # host=db_host,
        # user=db_user,
        # password=db_password,
        # dbname=db_name,
        # cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
        # )
        
        # with connection.cursor() as cursor:
        #     cursor.execute(generated_sql_query)
        #     result = cursor.fetchall()

        # # Convert result to DataFrame
        # result_df = pd.DataFrame(result)

        # # Convert DataFrame to the desired JSON format
        # result_json = {
        #     "sql_query": generated_sql_query,
        #     "dataframe": {
        #         "headers": list(result_df.columns),
        #         "data": result_df.values.tolist()
        #     }
        # }
        
        result_json={}
        # Return the result as JSON
        return result_json

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=4001)
