#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 14:21:57 2024

This file is for training NER Spacy model.

# install any necessary packages
pip install -U spacy
pip install spacy_transformers


To train the model
python -m spacy train /home/asmat/multiagent/spacy_NER/config/config.cfg  --output /home/asmat/multiagent/spacy_NER/trained_models/output  --paths.train /home/asmat/multiagent/spacy_NER/trained_models/train_data.spacy  --paths.dev /home/asmat/multiagent/spacy_NER/trained_models/test_data.spacy --gpu-id 0"""

# Import required libraries and install any necessary packages
import spacy
from spacy.tokens import DocBin
from tqdm import tqdm
import json


# Load the annotated data from a JSON file
cv_data = json.load(open('/home/asmat/multiagent/spacy_NER/annotations_dataset/annotations.json','r'))

# Display the number of items in the dataset
print(len(cv_data))

# Display the first item in the dataset
print(cv_data[0])

# Filter out None values and convert to the required format
filtered_data = [
    {"text": entry[0], "annotations": {"entities": entry[1]["entities"]}}
    for entry in cv_data
    if entry is not None
]






# This is my change
import spacy
from spacy.tokens import Doc, DocBin
from spacy.training import Example

def create_docbin(annotated_data, nlp):
    """Create a DocBin object from annotated data."""
    doc_bin = DocBin()

    for item in annotated_data:
        text = item["text"]
        annotations = item["annotations"]

        doc = nlp.make_doc(text)
        example = Example.from_dict(doc, annotations)
        doc_bin.add(example.reference)

    return doc_bin

# Load a blank spaCy model (you can use a pre-trained model if needed)
nlp = spacy.blank("en")



# Split the annotated data into training and testing sets
from sklearn.model_selection import train_test_split
train, test = train_test_split(filtered_data, test_size=0.05)

# Display the number of items in the training and testing sets
len(train), len(test)

# Open a file to log errors during annotation processing
file = open('/home/asmat/multiagent/spacy_NER/trained_models/train_file.txt','w')

# Create spaCy DocBin objects for training and testing data
# Create DocBin object
db = create_docbin(train, nlp)

# # Save DocBin object to file
# output_file = "train.spacy"
# doc_bin.to_disk(output_file)


# db = get_spacy_doc(file, train)
db.to_disk('/home/asmat/multiagent/spacy_NER/trained_models/train_data.spacy')

db = create_docbin(test, nlp)
#db = get_spacy_doc(file, test)
db.to_disk('/home/asmat/multiagent/spacy_NER/trained_models/test_data.spacy')

# Close the error log file
file.close()