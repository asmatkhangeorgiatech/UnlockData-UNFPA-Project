#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 18:57:34 2024
For testing the model Spacy NER version 3

@author: asmat
"""
# Import the spaCy library
import spacy

# Load the trained spaCy NER model from the specified path
nlp = spacy.load('/home/asmat/multiagent/spacy_NER/trained_models/output/model-last')

text = "What is the national prevalence of thinness among women in the 30-34 age group who belong to the education?"
# Process the extracted text using the loaded spaCy NER model
doc = nlp(text)

# Iterate through the named entities (entities) recognized by the model
for ent in doc.ents:
  # Print the recognized text and its corresponding label
  print(ent.text, "  ->>>>  ", ent.label_)
