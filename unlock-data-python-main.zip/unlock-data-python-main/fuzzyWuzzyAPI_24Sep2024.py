#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 17:21:24 2024

Cross-Attention mechanoism

@author: asmat
"""
import re
import nltk
from nltk.corpus import wordnet 
from difflib import SequenceMatcher
from langchain_community.utilities.sql_database import SQLDatabase
import psycopg2
from psycopg2.extras import DictCursor
import pandas as pd
# nltk.download('punkt') as it is already installed 
# nltk.download('wordnet') if once installed comment it 
from langchain.output_parsers import ResponseSchema, StructuredOutputParser
import json

## This is another Asmat Attempt
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from fastapi.middleware.cors import CORSMiddleware

from sentence_transformers import SentenceTransformer, util

from llama_index.experimental.query_engine import PandasQueryEngine
from llama_index.llms.ollama import Ollama
from langchain_community.chat_models import ChatOllama

from sqlalchemy import create_engine
import warnings



import torch
from transformers import T5Tokenizer, T5ForConditionalGeneration, BertTokenizer, BertModel
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import string
from nltk.corpus import wordnet
import string
# from llama_index.llms.groq import Groq
from llama_index.core.llms import ChatMessage

from mfunctions import getLookupWithGroups

# Ensure you have NLTK resources
import nltk
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')
nltk.download('punkt_tab')

# Define the small phrase and list of paragraphs
phrase = "age at first maternity in bagmati province in everest  area"

# llm = Groq(model="llama3-70b-8192", api_key="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")


indicators = {
    "Women age 15-49 who have experienced physical violence since age 15 (%)": [
        "Women 15-49 who have suffered physical violence since age 15",
        "Females aged 15-49 who have faced physical abuse since age 15",
        "Women age 15-49 who have encountered physical violence since 15",
        "Females 15-49 subjected to physical violence since turning 15",
        "Women aged 15-49 who have been victims of physical violence since 15",
        "Females age 15-49 experiencing physical abuse since age 15",
        "Women 15-49 who have undergone physical assault since age 15",
        "Females aged 15-49 who have been affected by physical violence since 15",
        "Women age 15-49 who have endured physical abuse since turning 15",
        "Females 15-49 suffering from physical violence since age 15",
        "Women aged 15-49 who have been subjected to physical abuse since 15",
        "Females aged 15-49 who have experienced physical assault since age 15",
        "Women age 15-49 encountering physical abuse since age 15",
        "Females 15-49 exposed to physical violence since turning 15",
        "Women 15-49 who have endured physical violence since age 15",
        "Females aged 15-49 who have been affected by physical abuse since 15",
        "Women age 15-49 who have experienced physical harm since age 15",
        "Females 15-49 facing physical violence since age 15",
        "Women aged 15-49 who have suffered physical assault since turning 15",
        "Females 15-49 who have faced physical harm since age 15",
        "Women experiencd beating"
    ],
    "Current use of a modern method of family planning (%)": [
        "Current use of a modern contraceptive method",
        "Active use of a modern family planning method",
        "Present use of a modern birth control method",
        "Current application of a modern contraception method",
        "Active practice of a modern method for family planning",
        "Current utilization of a modern family planning technique",
        "Present use of a modern method for birth control",
        "Active modern method for family planning in use",
        "Ongoing use of a modern family planning method",
        "Active use of a modern fertility regulation method",
        "Current usage of a modern birth control method",
        "Present application of a modern contraceptive method",
        "Ongoing use of a modern technique for family planning",
        "Current practice of a modern family planning measure",
        "Active implementation of a modern birth control method",
        "Present modern method for family planning being used",
        "Current deployment of a modern family planning strategy",
        "Ongoing application of a modern birth control technique",
        "Active modern contraception method currently in use",
        "Present use of a modern fertility control method",
        "Proportion of women using family planning methods",
        "Prevalence Rate for modern methods",
        "Current use of advanced contraceptive methods",
        "Usage of contemporary contraceptive methods"
    ],
    "Median age at first birth women age 25-49 (years)": [
        "Average age at first childbirth for women aged 25-49",
        "Median age of women 25-49 at their first birth",
        "Typical age at first delivery for females aged 25-49",
        "Median age at first childbearing for women aged 25 to 49",
        "Standard age of women 25-49 when they had their first child",
        "Median age of first-time mothers among women aged 25-49",
        "Average age at first pregnancy for women aged 25-49",
        "Median years at first birth for females aged 25-49",
        "Typical age of first-time childbirth for women aged 25 to 49",
        "Median age at the time of first delivery for women aged 25-49",
        "Average years at first childbirth for women aged 25-49",
        "Median age at first live birth for females aged 25-49",
        "Common age at first childbearing for women aged 25 to 49",
        "Typical years at first birth for females aged 25-49",
        "Average age of first-time mothers among women aged 25-49",
        "Median age at which women 25-49 give birth for the first time",
        "Average years of women 25-49 at their first pregnancy",
        "Median age of women at first delivery in the 25-49 age group",
        "Usual age at first childbirth for women between 25 and 49 years",
        "Typical age of females aged 25-49 when they had their first child",
        "age at first reproductive event"
    ],
    "Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)": [
        "Females 15-49 experiencing partner violence in the past year",
        "Women who faced intimate partner violence in the last 12 months",
        "Females experiencing domestic violence from a partner",
        "Women who faced violence by a husband or partner",
        "Ladies who experienced abuse by a partner in the past year",
        "Women who faced violence from a spouse in the last 12 months",
        "Females who experienced violence from an intimate partner",
        "Women facing physical violence from a partner in the past year",
        "Females with experience of domestic violence by a partner",
        "Women who suffered violence by a partner in the last year",
        "Females experiencing spousal violence in the past 12 months",
        "Women who faced abuse by their spouse in the last year",
        "Females experiencing violence by their husband or intimate partner",
        "Women who reported partner violence in the past year",
        "Females suffering domestic violence by their partner",
        "Ladies who experienced violence by their spouse or partner",
        "Women who suffered intimate partner abuse in the last year",
        "Females with reported violence from a spouse in the last year",
        "Women experiencing violence by a husband or partner in the last year",
        "Females suffering physical abuse from a partner"
    ],
    "Unmet need for family planning": [
        "Unmet family planning requirements",
        "Unfulfilled family planning needs",
        "Gaps in access to family planning",
        "Unmet contraception demands",
        "Unmet birth control needs",
        "Lack of family planning services",
        "Unmet reproductive health needs",
        "Unmet contraceptive needs",
        "Unmet family planning services",
        "Unfulfilled family planning requirements",
        "Unsatisfied demand for birth control",
        "Inadequate access to family planning",
        "Unmet needs for birth control",
        "Unmet contraception requirements",
        "Unmet family planning resources",
        "Gaps in contraceptive access",
        "Unaddressed family planning needs",
        "Unmet reproductive needs",
        "Unfulfilled birth control needs",
        "Unsatisfied need for contraceptive services",
        "need for traditional methods",
        "requirments of modern contraceptives methods"
    ],
    "Total Fertility Rate (number of children per woman)": [
        "Fertility rate (children per woman)",
        "Total number of children per woman",
        "Average number of children per female",
        "Total fertility rate per woman",
        "Number of children born per woman",
        "Average fertility rate (children per woman)",
        "Total fertility per female",
        "Children born per woman on average",
        "Fertility rate of women (children per female)",
        "Average children per woman",
        "Total number of children born per woman",
        "Average number of births per woman",
        "Fertility rate for females",
        "Average fertility rate for women",
        "Total children per woman on average",
        "Average number of offspring per woman",
        "Number of children a woman has on average",
        "Total fertility rate in women",
        "Fertility rate measured by children per woman",
        "Average number of children a female has",
        "FR",
        "reproductive rate per women",
        "child bearing rate"
    ],
    "Children who are fully vaccinated against all basic antigens (%)": [
        "Children fully immunized against basic antigens",
        "Children receiving all essential vaccines",
        "Kids immunized for basic diseases",
        "Children who completed all necessary vaccinations",
        "Children with full vaccination coverage",
        "Kids who received all basic immunizations",
        "Children protected against all basic antigens",
        "Children who completed the basic immunization schedule",
        "Fully vaccinated children against required antigens",
        "Children covered by all essential vaccines",
        "Children with complete vaccine protection",
        "Kids who received all scheduled immunizations",
        "Children vaccinated with all essential antigens",
        "Kids fully covered by basic vaccines",
        "Children fully protected by all required vaccines",
        "Children completing basic vaccine doses",
        "Children achieving full vaccination status",
        "Children with full immunization against basic diseases",
        "Kids with full antigen vaccination",
        "Children vaccinated with all necessary doses"
    ],
    "Children who are fully vaccinated according to the national schedule (%)": [
        "Children fully immunized per national guidelines",
        "Children vaccinated as per national schedule",
        "Kids completing national vaccination program",
        "Children receiving all vaccines as per government schedule",
        "Kids fully immunized according to local guidelines",
        "Children covered by national immunization plan",
        "Children completing vaccination as per national policy",
        "Kids fully vaccinated as per local health guidelines",
        "Children immunized according to national standards",
        "Children completing vaccinations per national health schedule",
        "Kids receiving full immunization as per government protocol",
        "Children achieving full vaccination based on national policy",
        "Kids fully covered under the national vaccine program",
        "Children meeting the national immunization requirements",
        "Kids with all vaccinations as per national timeline",
        "Children following the national vaccination schedule",
        "Kids fully vaccinated according to state guidelines",
        "Children completing the government-prescribed vaccines",
        "Kids immunized according to the national protocol",
        "Children adhering to national immunization guidelines"
    ],
    
    "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)": [
        "Children 6-23 months fed acceptable diet by mother",
        "Children fed minimum diet requirement",
        "Young kids fed a healthy minimum diet",
        "Children aged 6-23 months on acceptable diet",
        "Children fed required diet for 6-23 months",
        "Children receiving minimum nutritional diet",
        "Children meeting acceptable diet standards",
        "Kids aged 6-23 months getting required nutrition",
        "Children achieving the minimum acceptable diet",
        "Young children fed an adequate diet",
        "Children on a minimum acceptable diet",
        "Kids aged 6-23 months with acceptable diet",
        "Children receiving sufficient nutrition",
        "Kids living with mother on healthy diet",
        "Children receiving a balanced minimum diet",
        "Children 6-23 months fed adequately by mothers",
        "Children on a nutritionally adequate diet",
        "Kids aged 6-23 months fed proper diet",
        "Young children receiving proper nutrition",
        "Children on minimum required dietary intake"
    ],
    "Women age 15-49 who achieved minimum dietary diversity (%)": [
        "women achieving dietary diversity",
        "Females 15-49 with diverse diet",
        "Females meeting minimum diet variety",
        "Ladies attaining diverse nutritional intake",
        "Women following diverse dietary plan",
        "Females achieving minimum food diversity",
        "Ladies maintaining dietary variety",
        "Females aged 15-49 with diverse diet",
        "Females consuming diverse foods",
        "Females with sufficient dietary variety",
        "Ladies meeting nutritional diversity standards",
        "Females achieving required dietary diversity",
        "Ladies on a diverse food intake",
        "Females aged 15-49 with balanced food diversity",
        "Women maintaining balanced dietary diversity",
        "Females with a varied diet",
        "Women meeting the minimum diet variety",
        "Ladies adhering to diverse dietary standards",
        "Females with adequate food diversity",
        "Females aged 15-49 achieving diet variety"
    ],
    "Household population with access to at least basic drinking water service (%)": [
        "Households with basic drinking water access",
        "Population with basic water services",
        "Households accessing essential drinking water",
        "People with basic access to water services",
        "Household population with clean drinking water",
        "Households with basic water supply",
        "People with basic drinking water supply",
        "Households accessing basic water services",
        "Household access to clean water supply",
        "Population with essential drinking water service",
        "Households with access to potable water",
        "Households with minimum water service",
        "Population accessing basic clean water",
        "Households with adequate water supply",
        "People with access to basic drinking water",
        "Households with drinking water services",
        "Population with access to minimum water service",
        "Household access to safe drinking water",
        "Households provided with basic drinking water",
        "Population with basic water access"
    ],
    "Household population with access to at least basic sanitation service (%)": [
        "Households with basic sanitation facilities",
        "Population with basic sanitation access",
        "Households accessing essential sanitation",
        "People with basic access to sanitation services",
        "Households with sanitation services",
        "Household population with essential sanitation",
        "People with basic sanitation provision",
        "Households accessing basic sanitation facilities",
        "Households with clean sanitation facilities",
        "Household population with minimum sanitation access",
        "Households with access to adequate sanitation",
        "Households with basic hygiene services",
        "Population with sanitation facility access",
        "Households with minimum hygiene services",
        "Households provided with basic sanitation",
        "Households accessing proper sanitation services",
        "People with access to basic hygiene",
        "Household population with proper sanitation",
        "Households accessing clean sanitation services",
        "Population with access to sanitation facilities"
    ],
    "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)": [
        "women 15-49 using financial accounts",
        "Females accessing bank or mobile transactions",
        "Females using bank accounts or mobile for transactions",
        "Ladies conducting financial transactions via phone or bank",
        "Females using bank or mobile banking services",
        "Females accessing banking or mobile financial services",
        "Females 15-49 using bank or mobile financial platforms",
        "Females with active bank or mobile transactions",
        "Females conducting financial transactions in the past year",
        "Ladies using mobile phone or bank account for finance",
        "Females utilizing mobile financial services",
        "Females accessing financial services via phone or bank",
        "Females using mobile or banking services for transactions",
        "Females with mobile banking or bank accounts",
        "Ladies completing transactions through mobile or bank",
        "Females conducting banking transactions on mobile or account",
        "Females using phone or bank for financial operations",
        "Females 15-49 engaging in financial transactions",
        "Females completing financial transactions using mobile or bank",
        "Females with access to financial platforms for transactions"
    ],
    "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)": [
        "Males 14-49 using bank accounts or mobile for transactions",
        "Men using bank or mobile phone for financial services",
        "Males engaging in mobile or bank financial transactions",
        "Men accessing bank accounts or mobile banking",
        "Men performing financial transactions via mobile or bank",
        "Males using mobile phones for banking transactions",
        "Men with active financial services through bank or phone",
        "Males utilizing bank accounts or mobile platforms for finance",
        "Men who used bank or mobile financial services in the past year",
        "Males conducting financial transactions via bank or mobile",
        "Men completing financial transactions through mobile or bank",
        "Males accessing bank or mobile accounts for transactions",
        "Men utilizing mobile or banking services for financial operations",
        "Males with mobile banking or bank accounts",
        "Men handling finances through mobile or bank accounts",
        "Males using mobile or bank for financial dealings",
        "Men performing banking transactions through phone or bank",
        "Males with financial transactions in the past year via mobile or bank",
        "Men utilizing mobile banking or bank accounts for financial purposes",
        "Males engaging in mobile or bank-based financial operations"
    ],
    
    "Married women age 15-49 who participate in household decisions (%)": [
        "Married women 15-49 involved in household decisions",
        "Females actively participating in household decision-making",
        "Married women who take part in family decisions",
        "Women involved in household decision-making",
        "Ladies participating in domestic decision processes",
        "Females contributing to household decisions",
        "Married women engaged in family decisions",
        "Women who influence household decisions",
        "Females taking part in household decisions",
        "Married women participating in family decision-making",
        "Women contributing to decisions in the home",
        "Married females engaged in household decision-making",
        "Women involved in domestic decisions",
        "Females participating in family decision-making",
        "Women 15-49 making decisions within the household",
        "Married women taking part in decision-making at home",
        "Females 15-49 engaged in household decisions",
        "Married women contributing to decisions in the family",
        "Women involved in decision-making processes at home",
        "Females influencing decisions in the household"
    ],
    "Neonatal mortality": [
        "Neonatal death rate",
        "Mortality rate among newborns",
        "Deaths among neonates",
        "Rate of newborn deaths",
        "Newborn mortality rate",
        "Number of neonatal deaths per live birth",
        "Deaths of newborns in the first month",
        "Mortality of newborns",
        "Neonate death rate",
        "Newborn deaths per 1,000 live births",
        "Mortality in the neonatal period",
        "Deaths of babies in their first month",
        "Rate of deaths in the first month of life",
        "Number of deaths among newborns",
        "Deaths during the neonatal period",
        "Mortality among infants less than a month old",
        "Rate of neonatal fatalities",
        "Neonatal fatalities per 1,000 live births",
        "Infant deaths in the neonatal stage",
        "Mortality of newborns in the first 28 days"
    ],
    "Infant mortality": [
        "Infant death rate",
        "Mortality rate among infants",
        "Deaths of infants per 1,000 live births",
        "Rate of infant deaths",
        "Number of infant deaths per year",
        "Infant mortality per 1,000 live births",
        "Deaths among infants under one year",
        "Mortality of infants",
        "Rate of deaths in infants",
        "Deaths in the first year of life",
        "Number of infant deaths in the first year",
        "Infant deaths per 1,000 births",
        "Infant fatalities per 1,000 live births",
        "Rate of deaths among infants under 1 year",
        "Infant death rate in the first year",
        "Infant mortality during the first 12 months",
        "Mortality in infants under one year",
        "Rate of fatalities among infants",
        "Deaths of babies before their first birthday",
        "Mortality of children under one year"
    ],
    "Under-five mortality": [
        "Under-five death rate",
        "Mortality rate of children under five",
        "Child deaths before age five",
        "Mortality of children under five years",
        "Rate of deaths in children under five",
        "Deaths among children under five per 1,000 live births",
        "Under-five fatalities per 1,000 births",
        "Number of deaths in children under five",
        "Deaths of children under five years of age",
        "Mortality of young children under five",
        "Children dying before age five",
        "Deaths among young children under 5 years",
        "Rate of fatalities in children under five",
        "Child deaths before their fifth birthday",
        "Mortality among children under five",
        "Deaths among children under five years old",
        "Under-five child mortality rate",
        "Rate of deaths before age five",
        "Number of fatalities among children under five",
        "Mortality of children aged less than five"
    ],
    "Antenatal care (ANC) from a skilled provider": [
        "Prenatal care from a skilled provider",
        "Antenatal services by a trained provider",
        "Mothers receiving skilled antenatal care",
        "Women receiving prenatal care from a skilled professional",
        "Skilled antenatal care services",
        "Prenatal care provided by a skilled healthcare worker",
        "Women accessing skilled antenatal care",
        "Expecting mothers receiving skilled antenatal services",
        "Antenatal care administered by trained professionals",
        "Prenatal services from qualified providers",
        "Women receiving professional antenatal care",
        "Expecting mothers provided with skilled antenatal care",
        "Antenatal services by a healthcare professional",
        "Mothers accessing skilled prenatal services",
        "Skilled prenatal care for expectant mothers",
        "Women getting professional antenatal services",
        "Pregnant women receiving skilled antenatal care",
        "Prenatal care from a trained healthcare provider",
        "Expecting mothers receiving care from skilled providers",
        "Women accessing skilled prenatal healthcare"
    ],
    "Births delivered in a health facility (%)": [
        "Births occurring in a health facility",
        "Deliveries taking place in medical facilities",
        "Births delivered in hospitals or health centers",
        "Deliveries happening in a healthcare facility",
        "Babies born in health facilities",
        "Childbirths occurring in a health institution",
        "Deliveries conducted in medical institutions",
        "Births taking place in healthcare settings",
        "Babies delivered in hospitals or clinics",
        "Births taking place in medical centers",
        "Deliveries in health centers or hospitals",
        "Babies born in a health care institution",
        "Births occurring in hospitals or health facilities",
        "Deliveries happening in health care institutions",
        "Births taking place in medical facilities",
        "Childbirths delivered in health facilities",
        "Births happening in healthcare institutions",
        "Deliveries occurring in medical centers",
        "Births conducted in a healthcare facility",
        "Babies born in medical institutions"
        ],
    "Births assisted by a skilled provider (%)": [
        "Deliveries assisted by skilled healthcare professionals",
        "Births attended by a trained provider",
        "Childbirths assisted by skilled personnel",
        "Births attended by a professional healthcare provider",
        "Deliveries helped by skilled professionals",
        "Births assisted by qualified healthcare workers",
        "Childbirths assisted by trained personnel",
        "Deliveries attended by skilled providers",
        "Births helped by professional healthcare providers",
        "Deliveries assisted by skilled birth attendants",
        "Births attended by skilled medical personnel",
        "Childbirths assisted by qualified healthcare providers",
        "Deliveries attended by trained professionals",
        "Births aided by skilled healthcare providers",
        "Childbirths supported by trained medical staff",
        "Births managed by qualified healthcare professionals",
        "Deliveries attended by certified health practitioners",
        "Births helped by experienced medical providers",
        "Childbirths managed by trained professionals",
        "Deliveries overseen by skilled birth attendants"
    ],
    "Women age 15-49 who have heard of COVID-19 (%)": [
        "Females 15-49 aware of COVID-19",
        "Women familiar with COVID-19",
        "Females aged 15-49 who know about COVID-19",
        "Women who have heard of COVID-19",
        "Females informed about COVID-19",
        "Women aged 15-49 who are aware of the coronavirus",
        "Females knowledgeable about COVID-19",
        "Women 15-49 with awareness of COVID-19",
        "Females who have learned about COVID-19",
        "Women aware of the coronavirus",
        "Females with knowledge of COVID-19",
        "Women familiar with the COVID-19 pandemic",
        "Females 15-49 informed about the coronavirus pandemic",
        "Women 15-49 aware of the COVID-19 virus",
        "Females aged 15-49 who are aware of COVID-19",
        "Women who are knowledgeable about COVID-19",
        "Females informed about the COVID-19 outbreak",
        "Women who know about COVID-19",
        "Females familiar with COVID-19 information",
        "Women who have heard about the COVID-19 virus",
        "women covid"
    ],
    "Men age 15-49 who have heard of COVID-19 (%)": [
        "Males 15-49 aware of COVID-19",
        "Men who have heard of COVID-19",
        "Males aged 15-49 informed about COVID-19",
        "Men familiar with COVID-19",
        "Males who know about the coronavirus",
        "Men aged 15-49 who are aware of COVID-19",
        "Males knowledgeable about COVID-19",
        "Men who have learned about COVID-19",
        "Males 15-49 with awareness of the coronavirus",
        "Men aware of COVID-19",
        "Males informed about the COVID-19 virus",
        "Men knowledgeable about the COVID-19 pandemic",
        "Males 15-49 familiar with COVID-19",
        "Men who are aware of the coronavirus pandemic",
        "Males who know about the COVID-19 outbreak",
        "Men familiar with the COVID-19 virus",
        "Males aware of the COVID-19 virus",
        "Men informed about the coronavirus",
        "Males knowledgeable about the COVID-19 outbreak",
        "Men who have learned about the COVID-19 virus",
        "men covid"
    ],
    
    "Women age 15-19 who have ever been pregnant (%)": [
        "Females 15-19 who have ever been pregnant",
        "Women aged 15-19 with pregnancy experience",
        "Females 15-19 who have experienced pregnancy",
        "Women 15-19 who have been pregnant",
        "Teenage females 15-19 who have been pregnant",
        "Women aged 15-19 with pregnancy history",
        "Females aged 15-19 who have been pregnant",
        "Women 15-19 who have had a pregnancy",
        "Females 15-19 with a history of pregnancy",
        "Women in the 15-19 age group who have been pregnant",
        "Females aged 15-19 who have experienced pregnancy",
        "Teenage females who have been pregnant",
        "Women 15-19 who have ever had a pregnancy",
        "Females 15-19 who have been pregnant before",
        "Teen women 15-19 who have experienced pregnancy",
        "Females aged 15-19 with past pregnancies",
        "Women 15-19 who have been pregnant in the past",
        "Females 15-19 who have been pregnant previously",
        "Women aged 15-19 who have been through pregnancy",
        "Females aged 15-19 with previous pregnancy experience",
        "the first birth at or under eighteen",
        "the first birth at or under nineteen",
        "the first birth at or under seventeen",
        "the first birth at or under sixteen",
        "the first birth at or under eighteen",
        "the first birth at fifteen"
    ],
    "Children under age five who are stunted (%)": [
        "Kids under five with stunted growth",
        "Youngsters under five who are stunted in height",
        "Infants under five with growth stunting",
        "Under-five kids who are stunted",
        "Toddlers under five who have stunted growth",
        "Under-five infants with impaired growth",
        "Young children under five with height stunting",
        "Little ones under five who are short for their age",
        "Minors under five with delayed growth",
        "Under-five youngsters with height deficiencies",
        "Infants below five with stunted physical development",
        "Under-five toddlers with poor growth",
        "Young ones under five who are short-statured",
        "Minors below five suffering from stunting",
        "Under-five kids with growth retardation",
        "Infants under five with chronic stunting",
        "Youngsters under five who are severely stunted",
        "Kids under age five with growth impairments",
        "Little ones under five affected by stunted growth",
        "Young children under five with reduced height"
    ],
    "Children under age five who are wasted (%)": [
        "Kids under five with wasting",
        "Youngsters under five who are wasted in weight",
        "Under-five kids suffering from wasting",
        "Infants below five who are wasted",
        "Young children under five with low weight-for-height",
        "Under-five toddlers with severe wasting",
        "Infants under five with acute wasting",
        "Little ones under five with wasting disorder",
        "Kids under five who are thin for their height",
        "Youngsters below five suffering from wasting",
        "Minors under five with weight deficiencies",
        "Infants under five with weight-for-height wasting",
        "Under-five infants with weight loss",
        "Young children below five affected by wasting",
        "Toddlers under five with nutritional wasting",
        "Little ones under five who are undernourished and wasted",
        "Youngsters under five with weight malnutrition",
        "Minors under five with severe thinness",
        "Young children under five with extreme wasting",
        "Kids below five who are severely wasted"
    ],
    "Children under age five who are underweight (%)": [
        "Kids under five who are underweight",
        "Under-five youngsters with low weight",
        "Infants under five with underweight status",
        "Young children under age five suffering from underweight",
        "Toddlers below five who are underweight",
        "Minors under five with weight deficiency",
        "Under-five kids with low body weight",
        "Infants below five with underweight issues",
        "Little ones under five who have low weight for their age",
        "Youngsters under five with insufficient body weight",
        "Under-five toddlers who are malnourished and underweight",
        "Minors below five suffering from underweight condition",
        "Infants under five with inadequate weight",
        "Young children under age five who are undernourished",
        "Under-five infants with body weight deficiencies",
        "Little ones under five who are light for their age",
        "Minors below five with weight malnutrition",
        "Youngsters under five with low weight-for-age",
        "Infants under five who are classified as underweight",
        "Kids under five affected by underweight status"
    ],
    "Women age 15 and above with hypertension (%)": [
        "Women 15+ with high blood pressure",
        "Females aged 15 and older with hypertension",
        "Women age 15 and over with elevated blood pressure",
        "Females 15 and above suffering from hypertension",
        "Women 15 and older diagnosed with high blood pressure",
        "Females aged 15+ with high blood pressure",
        "Women over 15 with hypertension issues",
        "Females 15 and older with blood pressure problems",
        "Women aged 15 and up with hypertension",
        "Females age 15 and above with high blood pressure levels",
        "Women 15 and above with chronic hypertension",
        "Females 15+ who have hypertension",
        "Women aged 15 and older suffering from high blood pressure",
        "Females aged 15+ diagnosed with hypertension",
        "Women age 15 and over with blood pressure concerns",
        "Females 15+ with elevated blood pressure levels",
        "Women above 15 with hypertension",
        "Females age 15 and above with hypertension diagnosis",
        "Women 15 and older with elevated hypertension risk",
        "Females aged 15 and up with high blood pressure concerns"
    ],
    "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)": [
        "Women 15+ with severe disability in one domain",
        "Females aged 15 and older with significant disability",
        "Women age 15 and above with major difficulties in one domain",
        "Females 15 and above with disabilities in at least one area",
        "Women aged 15+ unable to function in one or more domains",
        "Females 15 and older with extreme difficulty in one domain",
        "Women 15 and over with severe disability in one or more areas",
        "Females aged 15+ who cannot perform in at least one domain",
        "Women age 15+ with major disability in one domain",
        "Females 15 and older with functional disability in one domain",
        "Women aged 15 and above with disabilities affecting one area",
        "Females 15+ with severe impairment in at least one domain",
        "Women 15 and older who struggle with one or more disabilities",
        "Females aged 15+ who cannot function at all in one domain",
        "Women aged 15+ with significant limitations in one area of disability",
        "Females 15+ with profound difficulties in at least one domain",
        "Women age 15 and older with functional impairments in one domain",
        "Females aged 15+ with severe functional limitations",
        "Women 15 and older with major disabilities in one or more domains",
        "Females 15+ unable to perform basic tasks in one area of disability"
    ],
    "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)": [
        "Men 15+ with severe impairment in one area",
        "Males aged 15 and older with significant functional limitation",
        "Men over 15 with major challenges in one category of ability",
        "Males age 15 and above with disabilities in at least one field",
        "Men aged 15+ unable to function in one or more aspects",
        "Males 15 and older with extreme difficulty in one realm",
        "Men 15 and over with severe restriction in one or more domains",
        "Males aged 15+ who cannot perform in at least one aspect of functionality",
        "Men age 15+ with major impairment in one sphere of ability",
        "Males 15 and older with functional challenges in one area",
        "Men aged 15 and above with limitations affecting one sector",
        "Males 15+ with severe incapacity in at least one dimension",
        "Men 15 and older who struggle with one or more functionality limitations",
        "Males aged 15+ who cannot function at all in one capacity area",
        "Men aged 15+ with significant restrictions in one functional domain",
        "Males 15+ with profound challenges in at least one field of capacity",
        "Men age 15 and older with operational impairments in one dimension",
        "Males aged 15+ with severe functional deficits",
        "Men 15 and older with major disabilities in one or more categories",
        "Males 15+ unable to perform basic tasks in one functional realm"
    ],
    "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)": [
        "Women 15-49 with anxiety symptoms as per global thresholds",
        "Females aged 15-49 experiencing anxiety based on international standards",
        "Women age 15-49 showing anxiety symptoms per global cutoffs",
        "Females 15-49 with anxiety signs based on international benchmarks",
        "Women aged 15-49 diagnosed with anxiety according to global criteria",
        "Females age 15-49 suffering from anxiety per international guidelines",
        "Women 15-49 exhibiting anxiety signs as per international thresholds",
        "Females aged 15-49 with anxiety symptoms according to worldwide standards",
        "Women age 15-49 with anxiety diagnosed based on global benchmarks",
        "Females 15-49 with anxiety symptoms according to global cutoff points",
        "Women 15-49 with anxiety indicators as per international cutoffs",
        "Females age 15-49 showing anxiety as per global standards",
        "Women aged 15-49 presenting with anxiety according to worldwide benchmarks",
        "Females aged 15-49 diagnosed with anxiety based on international cutoffs",
        "Women 15-49 suffering from anxiety per global indicators",
        "Females 15-49 with anxiety detected as per international thresholds",
        "Women age 15-49 showing signs of anxiety according to global criteria",
        "Females aged 15-49 with anxiety based on worldwide guidelines",
        "Women 15-49 exhibiting anxiety symptoms per international benchmarks",
        "Females 15-49 with anxiety diagnosis according to international standards"
    ],
    "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)": [
        "Men 15-49 with anxiety symptoms as per global thresholds",
        "Males aged 15-49 experiencing anxiety based on international standards",
        "Men age 15-49 showing anxiety symptoms per global cutoffs",
        "Males 15-49 with anxiety signs based on international benchmarks",
        "Men aged 15-49 diagnosed with anxiety according to global criteria",
        "Males age 15-49 suffering from anxiety per international guidelines",
        "Men 15-49 exhibiting anxiety signs as per international thresholds",
        "Males aged 15-49 with anxiety symptoms according to worldwide standards",
        "Men age 15-49 with anxiety diagnosed based on global benchmarks",
        "Males 15-49 with anxiety symptoms according to global cutoff points",
        "Men 15-49 with anxiety indicators as per international cutoffs",
        "Males age 15-49 showing anxiety as per global standards",
        "Men aged 15-49 presenting with anxiety according to worldwide benchmarks",
        "Males aged 15-49 diagnosed with anxiety based on international cutoffs",
        "Men 15-49 suffering from anxiety per global indicators",
        "Males 15-49 with anxiety detected as per international thresholds",
        "Men age 15-49 showing signs of anxiety according to global criteria",
        "Males aged 15-49 with anxiety based on worldwide guidelines",
        "Men 15-49 exhibiting anxiety symptoms per international benchmarks",
        "Males 15-49 with anxiety diagnosis according to international standards"
    ],
    "Women age 15-49 with symptoms of depression according to international cutoffs13 (%)":[
    "Females aged 15-49 with signs of depression based on global cutoffs (%)",
    "Women between 15 and 49 years showing depression symptoms according to global standards (%)",
    "Females 15 to 49 years old exhibiting symptoms of depression per international guidelines (%)",
    "Women aged 15-49 with indicators of depression per international benchmarks (%)",
    "Females aged 15-49 experiencing depressive symptoms according to worldwide cutoffs (%)",
    "Women in the age group 15-49 with depression symptoms as defined by international standards (%)",
    "Females aged 15-49 presenting symptoms of depression following international cutoffs (%)",
    "Women aged 15-49 displaying signs of depression per global guidelines (%)",
    "Females aged 15 to 49 with symptoms of depression by international criteria (%)",
    "Women aged 15-49 showing signs of depression according to international thresholds (%)",
    "Females 15-49 years old with symptoms of depression based on international standards (%)",
    "Women aged 15 to 49 experiencing depression symptoms per global cutoffs (%)",
    "Females 15-49 with depressive symptoms following international guidelines (%)",
    "Women in the age range 15-49 showing depression symptoms according to worldwide standards (%)",
    "Females aged 15-49 showing signs of depression per global thresholds (%)",
    "Women aged 15 to 49 experiencing symptoms of depression by global cutoffs (%)",
    "Females between 15 and 49 years with signs of depression per international criteria (%)",
    "Women aged 15-49 exhibiting symptoms of depression according to global standards (%)",
    "Females aged 15-49 presenting depressive symptoms based on international guidelines (%)",
    "Women 15-49 years old with indicators of depression according to worldwide benchmarks (%)"
    ],
    "Men age 15-49 with symptoms of depression according to international cutoffs (%)": [
        "Men 15-49 with depression symptoms as per global thresholds",
        "Males aged 15-49 experiencing depression based on international standards",
        "Men age 15-49 showing depression symptoms per global cutoffs",
        "Males 15-49 with depression signs based on international benchmarks",
        "Men aged 15-49 diagnosed with depression according to global criteria",
        "Males age 15-49 suffering from depression per international guidelines",
        "Men 15-49 exhibiting depression signs as per international thresholds",
        "Males aged 15-49 with depression symptoms according to worldwide standards",
        "Men age 15-49 with depression diagnosed based on global benchmarks",
        "Males 15-49 with depression symptoms according to global cutoff points",
        "Men 15-49 with depression indicators as per international cutoffs",
        "Males age 15-49 showing depression as per global standards",
        "Men aged 15-49 presenting with depression according to worldwide benchmarks",
        "Males aged 15-49 diagnosed with depression based on international cutoffs",
        "Men 15-49 suffering from depression per global indicators",
        "Males 15-49 with depression detected as per international thresholds",
        "Men age 15-49 showing signs of depression according to global criteria",
        "Males aged 15-49 with depression based on worldwide guidelines",
        "Men 15-49 exhibiting depression symptoms per international benchmarks",
        "Males 15-49 with depression diagnosis according to international standards"
    ],
    "Current use of any method of family planning (%)": [
        "Current use of any contraceptive method",
        "Active use of any family planning method",
        "Present use of any birth control method",
        "Current application of any contraception method",
        "Active practice of any method for family planning",
        "Current utilization of any family planning technique",
        "Present use of any method for birth control",
        "Active method for family planning in use",
        "Ongoing use of any family planning method",
        "Active use of any fertility regulation method",
        "Current usage of any birth control method",
        "Present application of any contraceptive method",
        "Ongoing use of any technique for family planning",
        "Current practice of any family planning measure",
        "Active implementation of any birth control method",
        "Present method for family planning being used",
        "Current deployment of any family planning strategy",
        "Ongoing application of any birth control technique",
        "Active contraception method currently in use",
        "Present use of any fertility control method",
        "Prevalence of contraceptive use among women of reproductive age",
        "Percentage of women practicing contraception",
        "Rate of use of family planning service",
        "Contraceptive Prevalence Rate (CPR)"
    ],
    
    "Demand satisfied by modern methods of family planning (%)": [
        "Demand met by modern family planning methods",
        "Family planning needs fulfilled by modern contraceptive techniques",
        "Satisfaction of demand using modern family planning approaches",
        "Family planning demand addressed with modern methods",
        "Modern contraceptive methods fulfilling family planning requirements",
        "Modern family planning solutions satisfying demand",
        "Contraceptive demand met through modern methods",
        "Modern birth control methods addressing family planning needs",
        "Modern family planning meeting contraceptive demand",
        "Demand for family planning fulfilled by modern methods",
        "Family planning needs satisfied with modern contraceptive techniques",
        "Modern methods covering demand for family planning",
        "Family planning demand met by modern contraceptive solutions",
        "Family planning needs addressed using modern birth control methods",
        "Satisfaction of planning demand through modern contraceptives",
        "Modern contraception satisfying demand for family planning",
        "Modern methods of birth control meeting family planning needs",
        "Contraceptive needs met by modern family planning methods",
        "Modern family planning strategies fulfilling contraceptive demand",
        "Family planning demand satisfied by modern contraceptive approaches"
    ],
    
    "Mmen age 15 and above with hypertension (%)": [
        "Men 15+ with high blood pressure",
        "Males aged 15 and older with hypertension",
        "Men age 15 and above suffering from high blood pressure",
        "Males 15+ diagnosed with hypertension",
        "Men aged 15 and over with elevated blood pressure",
        "Males aged 15+ experiencing high blood pressure",
        "Men 15 and older with hypertension",
        "Males 15+ suffering from elevated blood pressure",
        "Men age 15+ who have high blood pressure",
        "Males aged 15 and above diagnosed with hypertension",
        "Men 15 and over experiencing hypertension",
        "Males aged 15+ suffering from hypertension",
        "Men 15+ with elevated blood pressure levels",
        "Males 15 and older with high blood pressure conditions",
        "Men aged 15+ diagnosed with elevated blood pressure",
        "Males aged 15 and older experiencing hypertension",
        "Men 15+ who have been diagnosed with high blood pressure",
        "Males 15 and over suffering from high blood pressure",
        "Men aged 15+ experiencing elevated blood pressure",
        "Males aged 15 and above suffering from hypertension"
    ],
    
}

user_query = phrase

from  fuzzywuzzy import fuzz



def get_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name())
    return synonyms




######################################################################
####  Matching Province name
######################################################################
################################################################
##### Now we do matching for the provinces #####################
################################################################
import textdistance

# Province list
province_list = [
    "National",
    "Bagmati",
    "Gandaki",
    "Karnali",
    "Koshi",
    "Lumbini",
    "Madhesh",
    "Sudurpashchim"
]

# Function to check if two words are similar enough (for spell checking)
def are_similar(word1, word2, threshold=0.8):
    return textdistance.jaro_winkler(word1, word2) > threshold

# Tokenize the query by splitting into words
def tokenize_query(query):
    return query.lower().split()

# Function to find and remove matched provinces from the query
def find_and_remove_matched_provinces(query, province_list, similarity_threshold=0.9):
    query_tokens = tokenize_query(query)
    matched_provinces = []
    
    for province in province_list:
        province_tokens = province.lower().split()
        
        # Compare each token in the query with the province name
        match_found = False
        for province_token in province_tokens:
            for token in query_tokens:
                if are_similar(token, province_token, similarity_threshold):
                    matched_provinces.append(province)
                    match_found = True
                    break  # Break once a match is found for the province
            
            if match_found:
                # Remove tokens related to the matched province from the query
                query_tokens = [t for t in query_tokens if not any(are_similar(t, pt, similarity_threshold) for pt in province_tokens)]
                break  # Move to the next province once a match is found
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return matched_provinces, modified_query.strip()




#######################################################################
### Matching Lookup Groups
#######################################################################  
    
Lookup_groups = {
  "Ecological zone": [
    "Geographical zone", "Topographical area", "Region", "Natural zone", "Terrain type", 
    "Altitude zone", "Environmental zone", "Mountain region", "Hill region", "Terai region", 
    "Highland", "Lowland", "Midland", "Ecological belt", "Physical zone", 
    "Elevation zone", "Mountainous area", "Flatlands", "Hilly region", "Plains", 
    "High-altitude zone", "Valley region", "Geographic region", "Landform region", 
    "Climatic zone", "Ecological area", "Mountain belt", "Hilly zone", "Low-altitude area", 
    "Uplands", "Terrain division", "Habitat zone", "Biogeographical zone", "Geographic belt", 
    "Altitudinal belt", "Physiographic region", "Landscape zone", "Mountainous zone", 
    "Flat region", "Rolling hills", "Territorial zone", "Mountainous terrain", 
    "Low-lying area", "High elevation", "Physical region", "Geological region", 
    "Terrain region", "Ecological classification", "Geophysical zone", "Topographic division", 
    "Mountain", "Hill", "Terai","Mountain", "Highland", "Hills", "Elevated land", "Mountains", 
    "Hill", "Rolling hills", "Elevated terrain", "Mound", "Upland", 
    "Terai", "Plains", "Lowland", "Flatlands", "Low plains","flat","plateau","Everest","mount"
  ],

  "Residence": [
    "Living area", "Place of residence", "Residential area", "Housing area", "Domicile", 
    "Dwelling place", "Location", "Urban area", "Rural area", "Living location", 
    "Home location", "Urban setting", "Rural setting", "Town area", "Village area", 
    "City area", "Countryside", "Suburban area", "Residential zone", "Metropolitan area", 
    "Remote area", "Urbanized area", "Outskirts", "Urban living", "Rural living", 
    "Population center", "City living", "Rural community", "Urban community", 
    "Village setting", "Urban space", "Rural space", "Settlement area", "Urban environment", 
    "Rural environment", "Habitation zone", "Living environment", "Urban region", 
    "Rural region", "Place of living", "Cityscape", "Countryside area", "Urban district", 
    "Rural district", "Suburban setting", "Urban zone", "Rural zone", "Urbanized zone", 
    "Farmland", "Urban habitat", "Urban", "Rural",
    "Urban", "City", "Metropolitan", "Town", "Suburban",
    "Rural", "Countryside", "Remote", "Village", "Agricultural area"
  ],

  "Wealth quintile": [
    "Economic group", "Income level", "Wealth category", "Socio-economic class", "Wealth rank", 
    "Income bracket", "Financial status", "Economic status", "Income group", "Wealth tier", 
    "Affluence level", "Socio-economic tier", "Wealth division", "Income quintile", 
    "Wealth distribution", "Income tier", "Economic bracket", "Financial quintile", 
    "Economic division", "Socio-economic rank", "Wealth ranking", "Income ranking", 
    "Economic classification", "Wealth level", "Financial class", "Social class", 
    "Affluence tier", "Wealthy class", "Low-income group", "Middle-income group", 
    "Upper-income group", "Economic standing", "Income distribution", "Wealth stratification", 
    "Income stratification", "Affluence ranking", "Financial group", "Wealth percentile", 
    "Socio-economic level", "Income percentile", "Economic percentile", "Wealth percentile group", 
    "Income classification", "Financial standing", "Economic tier", "Financial ranking", 
    "Affluence category", "Income strata", "Wealth strata", 
    "Lowest", "Second", "Middle", "Fourth", "Highest",
    "Lowest", "Poorest", "Bottom tier", "Low-income", "Least wealthy", 
    "Second", "Lower middle", "Second tier", "Low to mid", "Slightly above bottom", 
    "Middle", "Middle class", "Moderate income", "Mid-tier", "Average wealth", 
    "Fourth", "Upper middle", "Fourth tier", "High-income", "Wealthier group", 
    "Highest", "Richest", "Top tier", "Wealthiest", "Upper class"
  ],

  "Age": [
    "Years of age", "Age range", "Age category", "Age group", "Age bracket", 
    "Life stage", "Age classification", "Age division", "Age cohort", "Chronological age", 
    "Demographic group", "Age band", "Age sector", "Life phase", "Age segment", 
    "Age cluster", "Age distribution", "Age strata", "Years lived", "Maturity level", 
    "Age frame", "Age period", "Year group", "Life span", "Age timeline", "Age decade", 
    "Age interval", "Age gap", "Life cycle", "Age-based group", "Life period", 
    "Generational group", "Age division range", "Age slot", "Years bracket", "Ageing group", 
    "Age-tier", "Age zone", "Life group", "Age-related group", "Age classification tier", 
    "Demographic cohort", "Age-linked group", "Life duration", "Age-related classification", 
    "Age period range", "Life span bracket", "Chronological range", "Time of life", 
    "Life group tier", 
    "<5", "Infants", "Toddlers", "Newborns", "Preschoolers", 
    "5-9", "Young children", "Early childhood", "Kids", "Primary school age", 
    "10-14", "Pre-teens", "Adolescents", "Tweenagers", "Middle childhood", 
    "15-19", "Teenagers", "Youth", "Late teens", "Adolescence", 
    "20–24", "Young adults", "Early twenties", "Youthful", "College age", 
    "25–29", "Mid-twenties", "Late twenties", "Young professionals", "Quarter-century age", 
    "30–34", "Early thirties", "Adult", "Mature", "Professional age", 
    "35–39", "Late thirties", "Mid-age", "Prime age", "Experienced adults", 
    "40–44", "Early forties", "Middle age", "Midlife", "Seasoned adults", 
    "45–49", "Late forties", "Pre-senior", "Advanced age", "Approaching fifties", 
    "50–54", "Early fifties", "Older adults", "Fifty-plus", "Mature age", 
    "55–59", "Late fifties", "Senior adults", "Near retirement", "Approaching sixties", 
    "60–64", "Early sixties", "Seniors", "Older age group", "Retirement age", 
    "65–69", "Mid-sixties", "Elderly", "Senior citizens", "Older seniors", 
    "70–74", "Early seventies", "Aged", "Elderly group", "Seventy-plus", 
    "75–79", "Late seventies", "Advanced seniors", "Very old", "Approaching eighties", 
    "80+", "Eighty-plus", "Octogenarians", "Very elderly", "Longest lived"
  ],

  "Education": [
    "Educational level", "Schooling level", "Academic level", "Level of education", 
    "Degree of education", "Education attainment", "Qualification level", "Academic achievement", 
    "Educational attainment", "School completion", "Formal education", "Scholastic level", 
    "Schooling stage", "Level of schooling", "Study level", "Grade level", "Education stage", 
    "Educational qualification", "Learning stage", "Learning level", "School stage", 
    "Academic tier", "School degree", "Level of instruction", "Education grade", 
    "Educational standing", "School qualification", "Scholarly level", "Degree of schooling", 
    "Formal learning", "Level of study", "Knowledge level", "Education classification", 
    "Education range", "Learning qualification", "Education degree", "School education", 
    "Academic grade", "Education sector", "Level of teaching", "Formal qualification", 
    "Academic classification", "Level of knowledge", "Scholarly classification", 
    "Educational rank", "Scholarly standing", "Educational range", "Academic training", 
    "Level of academic training", "Education cycle", 
    "No education", "Basic education (1-8)", "Secondary Education (9-12)", "More than secondary (13 and above)"
  ],

  "Ethnic group": [
    "Ethnicity", "Racial group", "Cultural group", "Heritage group", "Ethnic category", 
    "Racial identity", "Cultural identity", "Ethnic background", "Cultural background", 
    "Ethnic classification", "Ancestral group", "Ethnic identity", "Racial category", 
    "Cultural heritage", "Lineage group", "Tribal group", "Cultural affiliation", 
    "Ethnic community", "Racial community", "Ethnic subset", "Cultural subset", 
    "Cultural tradition", "Ethnic heritage", "Ethnic descent", "Cultural descent", 
    "Racial descent", "Cultural ethnicity", "Racial ethnicity", "Lineage", "Ancestral background", 
    "Ethnic lineage", "Cultural lineage", "Tribal identity", "Racial background", 
    "Cultural descent group", "Cultural tribe", "Ethnic tribe", "Ancestral descent", 
    "Tribal heritage", "Ethnic origin", "Cultural origin", "Ethnic roots", "Cultural roots", 
    "Racial roots", "Ethnic classification group", "Cultural origin group", 
    "Cultural identity group", "Ethnic origin group", "Ancestral identity", 
    "Brahmin/Chhetri", "Dalit", "Janajati", "Madhesi", "Muslim"
  ],
  "Mothers Education": [
    "Mother's schooling", "Maternal education", "Mother's academic background", "Mother's schooling level", 
    "Mother's academic achievement", "Mother's qualification", "Mother's study level", "Mother's learning level", 
    "Mother's degree", "Maternal academic status", "Mother's knowledge level", "Mother's educational standing", 
    "Maternal schooling", "Mother's school completion", "Mother's formal education", "Maternal qualification", 
    "Mother's literacy level", "Maternal degree", "Mother's educational background", "Mother's educational attainment", 
    "Mother's level of education", "Mother's scholastic level", "Mother's school achievement", "Mother's formal qualification", 
    "Mother's academic standing", "Mother's educational qualification", "Maternal study level", "Mother's learning achievements", 
    "Mother's formal schooling", "Mother's level of learning", "Mother's academic level", "Mother's instructional level", 
    "Mother's academic experience", "Mother's level of knowledge", "Mother's scholarly status", "Maternal education status", 
    "Mother's study experience", "Mother's schooling achievement", "Mother's academic record", "Maternal educational standing", 
    "Mother's academic training", "Mother's schooling training", "Mother's academic qualification", "Mother's learning background", 
    "Maternal scholastic standing", "Mother's literacy status", "Mother's learning record", "Mother's educational tier", 
    "Mother's academic tier", "Maternal degree status",
    "No education", "No schooling", "Uneducated", "No formal education", "Lack of education",
    "Basic education", "Elementary education", "Primary schooling", "Foundational education", "Early schooling",
    "Secondary education", "High school education", "Intermediate schooling", "Middle-level education", "Senior schooling",
    "More than secondary", "Higher education", "Tertiary education", "Post-secondary education", "College education"
  ],
  
  "Child Sex": [
    "Gender of child", "Baby's gender", "Sex of baby", "Infant's sex", "Child's gender identity", 
    "Gender classification", "Biological sex", "Infant's gender", "Newborn's sex", "Baby gender", 
    "Child's biological gender", "Infant gender", "Baby's sex", "Gender of infant", "Newborn gender", 
    "Child sex classification", "Gender of baby", "Baby's biological sex", "Infant sex classification", 
    "Gender determination", "Sex category", "Sex of infant", "Baby sex category", "Newborn's biological sex", 
    "Infant gender category", "Child gender type", "Biological gender type", "Sex identity", "Gender type", 
    "Baby sex identity", "Infant gender identity", "Gender type classification", "Infant gender identity type", 
    "Newborn gender classification", "Baby gender classification", "Sexual categorization", "Sex identification", 
    "Gender of infant", "Biological gender", "Child's gender type", "Sexual identity", "Child's sex type", 
    "Gender category", "Infant's sex identity", "Gender identification", "Gender profile", "Child's sex profile", 
    "Gender specification", "Sex classification", 
    "Male", "Boy", "Masculine", "Man", "Male child", "Son", 
    "Female", "Girl", "Feminine", "Woman", "Female child", "Daughter"
  ],
  
  "Mothers Age": [
    "Mother's age group", "Maternal age category", "Mother's age range", "Age of mother", "Maternal age bracket", 
    "Mother's age cohort", "Mother's years", "Mother's life stage", "Mother's life phase", "Mother's age classification", 
    "Age of maternal", "Maternal years of age", "Mother's chronological age", "Mother's life period", 
    "Mother's age division", "Mother's age band", "Mother's demographic group", "Mother's maturity level", 
    "Mother's age sector", "Maternal age cluster", "Mother's age timeline", "Mother's age tier", "Mother's age gap", 
    "Mother's age frame", "Mother's life duration", "Mother's life span", "Mother's life stage classification", 
    "Maternal age group", "Mother's life stage tier", "Mother's life stage range", "Mother's life cycle", 
    "Maternal age level", "Mother's age strata", "Mother's generational age", "Mother's age-based classification", 
    "Mother's maturity phase", "Mother's life stage band", "Maternal age range", "Mother's stage of life", 
    "Mother's age classification range", "Maternal stage of life", "Mother's maturity stage", 
    "Mother's age grouping", "Mother's chronological life stage", "Mother's life period grouping", 
    "Mother's age spectrum", "Mother's period of life", "Maternal life stage", 
    "<20", "Teenage mother", "Young mother", "Under 20", "Mother below 20",
    "20-34", "Young adult mother", "Mother in twenties", "Early thirties mother", "Mother between 20-34",
    "35-49", "Midlife mother", "Older mother", "Mother in late thirties", "Mother between 35-49"
  ],
  
  "Birth order": [
    "Childbirth order", "Birth sequence", "Order of births", "Position in birth sequence", "Birth ranking", 
    "Birth position", "Childbirth ranking", "Birth occurrence order", "Order of delivery", "Child delivery order", 
    "Sequence of childbirth", "Birth hierarchy", "Childbirth hierarchy", "Birthplace in family", "Place in birth sequence", 
    "Order of children", "Childbirth placement", "Order of offspring", "Birth succession", "Position in family birth", 
    "Family birth order", "Rank of birth", "Childbirth occurrence", "Birth hierarchy position", 
    "Order in family", "Birth order ranking", "Birth number", "Sequence of delivery", "Birth rank", 
    "Order of siblings", "Sequence of siblings", "Sibling birth order", "Sibling position", "Place in sibling hierarchy", 
    "Rank in family", "Birth series", "Child delivery rank", "Sibling birth rank", "Family child sequence", 
    "Order in childbirth sequence", "Birth sequence ranking", "Position of child in family", "Order of offspring birth", 
    "Birth rank in family", "Place in family birth", "Delivery order", "Birth succession order", "Sibling delivery sequence", 
    "Child delivery sequence", 
    "1", "Firstborn", "Eldest", "Oldest child", "Only child", 
    "2-3", "Middle child", "Second child", "Third child", "In-between child",
    "4-5", "Fourth child", "Fifth child", "Late birth", "Middle siblings", 
    "6+", "Sixth child", "Youngest", "Later-born child", "Last-born"
  ],

  "Antenatal care visits": [
    "Pregnancy care visits", "Maternal health visits", "Prenatal checkups", "Maternity care appointments", 
    "Pregnancy doctor visits", "Pregnancy health checkups", "Antenatal consultations", "Maternal checkups", 
    "Pregnancy medical checkups", "Pregnancy health visits", "Prenatal health visits", "Prenatal medical visits", 
    "Pregnancy care checkups", "Maternal health appointments", "Prenatal consultations", "Maternity doctor visits", 
    "Pregnancy doctor appointments", "Antenatal medical checkups", "Maternal care visits", "Pregnancy appointments", 
    "Pregnancy health consultations", "Maternal health care visits", "Prenatal visits", "Antenatal checkups", 
    "Pregnancy health consultations", "Maternal care appointments", "Pregnancy health checkups", "Maternity consultations", 
    "Antenatal care consultations", "Pregnancy doctor checkups", "Pregnancy health appointments", "Prenatal care visits", 
    "Maternal health care consultations", "Pregnancy care consultations", "Prenatal health appointments", "Maternity health visits", 
    "Pregnancy medical consultations", "Maternal care checkups", "Pregnancy medical appointments", "Pregnancy health care visits", 
    "Pregnancy consultations", "Pregnancy medical visits", "Pregnancy care appointments", "Pregnancy health checkups", 
    "Maternal care consultations", "Antenatal health consultations", "Maternal medical consultations", 
    "Antenatal health visits", "Prenatal health checkups", 
    "None", "No visits", "Zero", "None attended", "No checkups",
    "1-3", "Few visits", "Limited visits", "1-3 checkups", "Minimal antenatal care",
    "4+", "Frequent visits", "Multiple checkups", "More than 4", "More than four checkups"
  ],
  "Sex": [
    "Gender", "Biological sex", "Sex identity", "Sexual identity", "Gender classification", 
    "Gender category", "Biological gender", "Gender type", "Sex categorization", "Sex category", 
    "Gender identity", "Sexual classification", "Gender determination", "Sex specification", 
    "Gender division", "Sexual type", "Gender profile", "Sexual profile", "Gender distinction", 
    "Sexual distinction", "Gender type classification", "Sex classification", "Sex type", 
    "Gender differentiation", "Sexual identity type", "Sexual categorization", "Gender differentiation type", 
    "Sexual profile type", "Biological sex classification", "Gender identity type", "Sexual identity profile", 
    "Biological gender identity", "Gender differentiation category", "Sexual identity classification", 
    "Gender categorization type", "Biological sex profile", "Gender category classification", 
    "Sexual type identity", "Sexual gender type", "Gender classification type", "Sexual profile classification", 
    "Gender identity profile", "Sexual identity categorization", "Gender identification", "Gender profile classification", 
    "Gender distinction category", "Sexual differentiation category", "Sexual identity type classification", 
    "Gender type categorization", "Biological gender type",
    "Male", "Man", "Boy", "Masculine", "Male gender", 
    "Female", "Woman", "Girl", "Feminine", "Female gender"
  ],

  "Seen": [
    "Observed", "Detected", "Viewed", "Spotted", "Noticed", "Found", "Perceived", 
    "Witnessed", "Sighted", "Caught sight of", "Glanced at", "Identified", "Spied", 
    "Recognized", "Checked", "Acknowledge", "Realized", "Looked at", "Gazed upon", "Monitored", 
    "Not observed", "Missed", "Overlooked", "Invisible", "Unnoticed", 
    "Not detected", "Unspotted", "Unseen", "Unobserved", "Not found", 
    "Not acknowledged", "Not perceived", "Ignored", "Overpassed", "Passed by", 
    "Not sighted", "Disappeared", "Not present", "Absent", "Missing", 
    "Gone", "Vanished", "No longer present", "Unperceived", "Hidden", 
    "Not recognized", "Lost", "Hidden from view", "Out of sight", "Escaped attention"
  ],
  "Age group (15-49)": [
    "Age bracket", "Age classification", "Age range", "Age cohort", "Age category", "Age demographic", "Age spectrum", 
    "Age division", "Age set", "Age class", "Age group type", "Age range bracket", "Age grouping", "Age range group", 
    "Age span", "Age distinction", "Age segmentation", "Age scale", "Age framework", "Age period", "Age strata", 
    "Age band", "Age interval", "Age stage", "Age spectrum group", "Life stage group", "Age gap", "Age cohort category", 
    "Life cycle group", "Age level", "Generational group", "Life period group", "Age period range", "Age span category", 
    "Age classification range", "Age tier", "Generational band", "Life phase group", "Life stage period", "Age segmentation type", 
    "Age period segment", "Life span range", "Generational range", "Age classification group", "Life phase classification", 
    "Age gap group", "Age rank", "Generational category", "Age step", "Age level grouping",
    "15-49", "Reproductive age", "Fertile age", "Age 15-49", "Mid-age",
    "20-29", "Young adult", "Twenties", "Age 20-29", "Early adulthood",
    "30-39", "Thirties", "Middle age", "Age 30-39", "Prime adulthood",
    "40-49", "Forties", "Pre-retirement age", "Age 40-49", "Late adulthood"
  ],
  
  "Age in month": [
    "Age in months", "Infant age group", "Age by month", "Monthly age range", "Child age in months", "Age by month category", 
    "Monthly age group", "Infant monthly age", "Baby age in months", "Child's age in months", "Age range in months", 
    "Month age group", "Monthly age division", "Infant age classification", "Age group by months", "Monthly age band", 
    "Child's monthly age", "Baby's age in months", "Monthly age spectrum", "Infant age range", "Monthly cohort", 
    "Monthly age category", "Age classification in months", "Infant month-age group", "Baby's month age group", "Monthly age gap", 
    "Monthly age stage", "Infant month age range", "Monthly age framework", "Baby's monthly classification", "Child's monthly classification", 
    "Monthly age grouping", "Monthly age scale", "Monthly age strata", "Monthly age segmentation", "Monthly age distinction", 
    "Baby's age classification", "Child's age in months classification", "Baby's age segmentation", "Infant's age by months", 
    "Monthly life stage", "Monthly growth phase", "Infant monthly range", "Child age cohort in months", "Monthly life period", 
    "Infant monthly category", "Monthly span", "Child's monthly span", "Monthly tier", "Monthly developmental stage",
    "<6", "Less than six months", "Under six months", "Infant", "Early infancy",
    "6-11", "Late infancy", "Six to eleven months", "Infant late stage", "Age six to eleven months",
    "6-8", "Six to eight months", "Mid-infant stage", "Six-eight months", "Middle infancy",
    "9-11", "Nine to eleven months", "Late infant months", "Infant final stage", "Nine-eleven months",
    "12-23", "One to two years", "Toddler stage", "Age 12-23 months", "One to two years old",
    "12-18", "One to one-and-a-half years", "Early toddlerhood", "Twelve to eighteen months", "One to one and a half years",
    "18-23", "One-and-a-half to two years", "Late toddlerhood", "Eighteen to twenty-three months", "One and a half to two years",
    "24-35", "Two to three years", "Early childhood", "Age two to three", "Two to three years old",
    "36-47", "Three to four years", "Mid-childhood", "Age three to four", "Three to four years old",
    "48-59", "Four to five years", "Pre-school age", "Age four to five", "Four to five years old"
  ],
  
  "Birth interval in months": [
    "Months between births", "Spacing between births", "Birth spacing", "Time between births", "Birth gap", 
    "Birth interval period", "Birth interval length", "Time between pregnancies", "Months between pregnancies", 
    "Birth interval timing", "Birth spacing period", "Birth gap in months", "Interval between births", "Birth spacing interval", 
    "Pregnancy interval", "Birth interval measurement", "Interval period between births", "Childbirth spacing", 
    "Time gap between children", "Birth interval duration", "Birth period gap", "Pregnancy spacing", "Months between children", 
    "Birth time interval", "Spacing of pregnancies", "Childbirth gap", "Birth interval months", "Spacing of children", 
    "Inter-birth period", "Birth timing", "Interval period for births", "Pregnancy gap", "Childbearing interval", 
    "Birth time gap", "Interval of pregnancies", "Pregnancy gap in months", "Childbirth timing", "Interval between pregnancies", 
    "Inter-pregnancy period", "Time span between births", "Pregnancy spacing length", "Inter-birth timing", 
    "Interval period between pregnancies", "Time between childbearing", "Childbirth interval measurement", 
    "Pregnancy timing", "Pregnancy interval period", "Pregnancy spacing duration", "Time interval between childbirths", 
    "Childbirth interval duration", 
    "<24", "Less than two years", "Short birth interval", "Under 24 months", "Less than 24 months",
    "24-47", "Two to four years", "Moderate birth interval", "Twenty-four to forty-seven months", "Two to four years apart",
    "48+", "Four or more years", "Long birth interval", "Forty-eight months or more", "Four years or more"
  ],
  
  "Size at birth": [
    "Birth size", "Newborn size", "Infant size at birth", "Baby's size at birth", "Birth weight category", 
    "Size of baby at birth", "Newborn birth size", "Infant birth size", "Size classification at birth", 
    "Birth size category", "Birth weight", "Newborn's size", "Infant weight at birth", "Baby's birth size", 
    "Birth weight classification", "Baby's weight at birth", "Infant size classification", "Newborn weight", 
    "Size at delivery", "Size classification of newborn", "Baby's size", "Infant size classification", "Newborn size category", 
    "Infant weight category", "Baby's birth weight", "Newborn birth weight", "Newborn weight classification", 
    "Birth size type", "Newborn weight category", "Infant size type", "Birth weight type", "Baby's size classification", 
    "Newborn size classification", "Infant's birth size", "Newborn size type", "Infant's size category", "Newborn weight type", 
    "Birth size measurement", "Newborn size measurement", "Size measurement at birth", "Newborn weight measurement", 
    "Birth size record", "Infant size record", "Newborn size standard", "Birth weight record", "Infant birth weight type", 
    "Size of infant at birth", "Infant size type", "Baby's birth size type", "Newborn birth weight type",
    "Very small", "Low birth weight", "Tiny", "Underweight", "Significantly small",
    "Small", "Slightly underweight", "Smaller than average", "Low weight", "Smaller size",
    "Average or larger", "Normal weight", "Healthy weight", "Larger size", "Heavier birth weight"
  ],
  
  "Mothers nutritional status": [
    "Maternal nutritional state", "Mother's health status", "Maternal nourishment status", "Mother's nutrition level", 
    "Mother's health and nutrition", "Maternal nourishment condition", "Mother's dietary status", "Maternal nutrition", 
    "Mother's physical health", "Mother's body condition", "Maternal health condition", "Mother's dietary condition", 
    "Mother's nutritional condition", "Maternal nutrition status", "Mother's physical condition", "Maternal nourishment", 
    "Mother's nourishment state", "Mother's diet status", "Maternal nutrition condition", "Mother's nutrition status", 
    "Maternal dietary health", "Mother's dietary health", "Maternal nutritional level", "Mother's health and nourishment", 
    "Mother's physical nutrition", "Maternal health and nutrition", "Mother's physical nourishment", "Mother's nourishment level", 
    "Mother's diet level", "Maternal physical health", "Mother's nutritional health", "Maternal nourishment level", 
    "Maternal health and nourishment", "Mother's dietary level", "Mother's nourishment status", "Maternal diet level", 
    "Mother's physical nourishment level", "Mother's physical nutrition condition", "Mother's nutrition condition", 
    "Mother's nourishment and diet", "Mother's nutrition level status", "Mother's physical nourishment state", 
    "Maternal nourishment status", "Mother's dietary health status", "Mother's nutrition and health", 
    "Mother's nourishment and health", "Mother's diet and health", "Mother's nutrition health status", 
    "Maternal nourishment and diet",
    "Thin", "Underweight", "Slim", "Skinny", "Malnourished",
    "Normal", "Healthy", "Fit", "Well-nourished",
    "Overweight/Obese", "Heavy", "Fat", "Obese", "Above normal weight"
  ],
  "Maternity status": [
    "Maternal status", "Motherhood status", "Pregnancy condition", "Motherhood condition", "Pregnancy state", 
    "Maternal condition", "Motherhood state", "Maternity condition", "Pregnancy classification", "Motherhood classification", 
    "Pregnancy status", "Maternal classification", "Maternity state", "Motherhood period", "Maternal period", 
    "Pregnancy period", "Maternal status classification", "Maternity status type", "Pregnancy status type", 
    "Motherhood status type", "Maternity status level", "Maternal level", "Pregnancy level", "Motherhood level", 
    "Pregnancy classification type", "Motherhood status classification", "Maternal state classification", 
    "Maternity classification", "Pregnancy classification level", "Motherhood classification level", "Pregnancy type", 
    "Maternal status record", "Motherhood record", "Pregnancy record", "Maternity record", "Maternal condition classification", 
    "Motherhood condition type", "Maternity condition level", "Pregnancy period classification", "Maternal status level type", 
    "Motherhood status level type", "Maternity state type", "Motherhood state type", "Pregnancy state type", 
    "Maternal period classification", "Maternity period record", "Motherhood period record", "Pregnancy period record", 
    "Maternal state record",
    "Pregnant", "Expecting", "Carrying child", "With child", "Gestating",
    "Not pregnant", "Not expecting", "Without child", "Not carrying", "Not gestating"
  ],
  
  "Employment (last 12 months)": [
    "Work status (last 12 months)", "Job status (past year)", "Employment status (last year)", "Occupation status (past 12 months)", 
    "Work activity (last year)", "Job activity (past 12 months)", "Employment activity (past year)", "Labor status (last year)", 
    "Work history (past 12 months)", "Job history (last year)", "Employment history (past year)", "Work record (last year)", 
    "Job record (past 12 months)", "Employment record (last year)", "Work classification (past year)", "Job classification (last 12 months)", 
    "Employment classification (past year)", "Work status classification (last year)", "Job classification type (past 12 months)", 
    "Employment type (last year)", "Work activity classification (past 12 months)", "Job activity type (last year)", 
    "Employment activity type (past year)", "Labor classification (last 12 months)", "Work record classification (past year)", 
    "Job record type (last 12 months)", "Employment record type (last year)", "Work type (last 12 months)", 
    "Job type (past year)", "Employment type classification (last year)", "Work history classification (past 12 months)", 
    "Job history type (last year)", "Employment history type (last year)", "Work classification record (last 12 months)", 
    "Job classification record (last year)", "Employment classification record (last year)", "Labor history (past year)", 
    "Work status record (last 12 months)", "Job status record (last year)", "Employment status record (last year)", 
    "Labor record (last year)", "Work history record (last 12 months)", "Job history record (last year)", "Employment history record (last year)", 
    "Work classification type (last 12 months)", "Job classification level (last year)", "Employment classification level (last year)", 
    "Labor classification record (last year)", "Work level (last 12 months)", "Job level (last year)", "Employment level (last year)",
    "Not employed", "Unemployed", "Without a job", "Jobless", "Out of work",
    "Employed for cash", "Working for wages", "Paid employment", "Cash-earning job", "Salaried work",
    "Employed not for cash", "Unpaid employment", "Voluntary work", "Unpaid job", "Non-cash employment"
  ],
  "Number of living children": [
    "Living children count", "Number of surviving children", "Children alive count", "Count of living children", 
    "Surviving children number", "Number of living offspring", "Living offspring count", "Surviving children total", 
    "Count of surviving offspring", "Children still alive count", "Number of surviving dependents", "Living children tally", 
    "Surviving children tally", "Number of live children", "Count of live offspring", "Surviving offspring total", 
    "Living children total", "Surviving children record", "Number of living progeny", "Living progeny count", 
    "Surviving progeny count", "Living dependents count", "Surviving dependents tally", "Count of living progeny", 
    "Surviving progeny number", "Number of live offspring", "Count of surviving progeny", "Living dependents total", 
    "Surviving offspring number", "Count of live progeny", "Number of live dependents", "Count of living offspring", 
    "Living children classification", "Living children level", "Number of surviving children type", "Count of living progeny type", 
    "Living dependents number", "Number of live children record", "Living children status", "Surviving children classification", 
    "Living children classification type", "Living progeny classification", "Surviving children level", 
    "Surviving progeny classification", "Living offspring classification", "Surviving offspring classification", 
    "Living children type", "Surviving children type", "Living dependents type", "Surviving dependents type",
    "0", "None", "Zero", "No children", "Childless",
    "1-2", "One to two", "Small family", "Few children", "Low number of children",
    "3-4", "Three to four", "Medium-sized family", "Average number of children", "Moderate number of children",
    "5+", "Five or more", "Large family", "Many children", "High number of children"
  ],

  "Marital status": [
    "Relationship status", "Marriage status", "Civil status", "Family status", "Conjugal status", 
    "Partnership status", "Marital classification", "Marital condition", "Marriage condition", "Marital state", 
    "Marriage state", "Partnership classification", "Relationship classification", "Marital period", "Marriage period", 
    "Conjugal condition", "Civil condition", "Family condition", "Civil status classification", "Relationship type", 
    "Partnership type", "Marriage classification", "Marital status level", "Relationship status level", 
    "Conjugal status level", "Family status level", "Marriage status classification", "Civil status level", 
    "Partnership status classification", "Marital state type", "Marital classification type", "Relationship state", 
    "Marriage state type", "Conjugal state", "Civil state", "Family state", "Civil classification type", 
    "Family classification", "Partnership classification level", "Marriage level", "Marital condition level", 
    "Relationship level", "Marriage condition type", "Marital status record", "Marriage status record", 
    "Relationship status record", "Conjugal status record", "Family status record", "Marriage period classification", 
    "Partnership state type", "Civil status type", "Family condition type", 
    "Never married", "Single", "Unmarried", "Not married", "Without a partner",
    "Never had intimate partner", "No intimate partner", "Not in a relationship", "No partner", "Without intimate partner",
    "Ever had intimate partner", "Had a partner", "In a relationship before", "Had an intimate relationship", "Had a partner before",
    "Ever married", "Was married", "Married in the past", "Formerly married", "Previously married",
    "Married/living together", "Married and cohabiting", "In a marriage and living together", "Spouse living together", "Partnered and living together",
    "Divorced/separated/widowed", "Separated", "Formerly married and now alone", "Single after separation", "Widowed",
    "Divorced", "Legally separated", "Marriage dissolved", "Not in a marriage anymore", "Formerly married and separated",
    "Widowed", "Lost spouse", "Spouse passed away", "No longer married", "Bereaved"
  ],
  "Nutritional status": [
    "Health status", "Nourishment status", "Nutrition level", "Physical health", "Body condition", 
    "Nutrition condition", "Health and nutrition status", "Dietary status", "Nutritional state", 
    "Body nourishment", "Physical nourishment", "Health condition", "Body nutrition level", 
    "Nourishment condition", "Health and nourishment", "Dietary condition", "Nutrition and health", 
    "Body health status", "Nourishment and diet", "Health level", "Diet status", "Thin", 
    "Underweight", "Slim", "Skinny", "Malnourished", "Normal", "Healthy", 
    "Fit", "Well-nourished", "Overweight", "Heavy", "Fat", "Obese", "Above normal weight", 
    "Not weighed or measured", "Unmeasured", "Unrecorded", "Not assessed", "Untracked", 
    "Non-measured", "Uncalculated", "Not evaluated", "Body mass index", "BMI", "Nutritional balance", 
    "Healthful nutrition", "Dietary health status", "Nutrition profile", "Physical state", 
    "Well-being", "Nutritional assessment", "Body weight status", "Dietary level"
  ]
  }

   





######################### NER job finished.####################################

def format_for_sql(names_list):
    if names_list:
        return ', '.join(f"'{name}'" for name in names_list)
    return ''  # Return an empty string if the list is empty

# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name

db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20)
    
    
similarity_threshold=0.8    
 # Function to check if a token matches a phrase token considering misspellings
def is_similar(word, phrase_tokens):
     # Compare each word with the tokens in phrase_tokens using difflib
     for phrase_token in phrase_tokens:
         similarity = difflib.SequenceMatcher(None, word, phrase_token).ratio()
         if similarity > similarity_threshold:
             return True
     return False

import difflib
from nltk.tokenize import word_tokenize

###################### Let us start API business now #####################
##########################################################################
app = FastAPI()

# Allow all origins (useful for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Let us say I create a panda frame agent
# Import necessary packages
#langchain_experimental.agents.create_pandas_dataframe_agent
from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain.agents.agent_types import AgentType
from langchain.agents import AgentExecutor
import ollama



# def convert_json(input_json):
#     # Initialize an empty list to hold the transformed data
#     transformed_data = []

#     # Extract headers and data rows from the input JSON
#     headers = input_json['dataframe']['headers']
#     data_rows = input_json['dataframe']['data']

#     # Get the index positions for each relevant column
#     province_idx = headers.index('province')
#     lookup_group_idx = headers.index('lookup_group')
#     background_characteristics_idx = headers.index('Background characteristics')
#     value_idx = headers.index('value')
#     indicator_idx = headers.index('indicator')
#     indicatorid_idx = headers.index('indicator_id')

#     # Create a dictionary for the first item in the list
#     main_entry = {
#         "indicator_id": None,
#         "indicator": None,
#         "National": {},
#         "Province": {}
#     }
    
#     # Set indicator name and ID
#     if data_rows:
#         main_entry["indicator"] = data_rows[0][indicator_idx]
#         main_entry["indicator_id"] = data_rows[0][indicatorid_idx]
    
#     # Iterate through each row in the data
#     for row in data_rows:
#         province = row[province_idx]
#         lookup_group = row[lookup_group_idx]
#         background_characteristic = row[background_characteristics_idx]
#         value = row[value_idx]

#         if province == "National":
#             # Initialize the lookup group in the National section if not present
#             if lookup_group:
#                 if lookup_group not in main_entry["National"]:
#                     main_entry["National"][lookup_group] = {}
#                 main_entry["National"][lookup_group][background_characteristic] = value
#             else:
#                 main_entry["National"]["Total"] = value

#         else:
#             # Initialize the province if it does not exist
#             if province not in main_entry["Province"]:
#                 main_entry["Province"][province] = {"Total": None}

#             # If it's a new lookup group for this province, initialize it
#             if lookup_group:
#                 if lookup_group not in main_entry["Province"][province]:
#                     main_entry["Province"][province][lookup_group] = {}
#                 main_entry["Province"][province][lookup_group][background_characteristic] = value
#             else:
#                 main_entry["Province"][province]["Total"] = value

#     # Remove empty keys in both National and Province sections
#     if "National" in main_entry:
#         if "" in main_entry["National"]:
#             del main_entry["National"][""]

#     for province in list(main_entry["Province"].keys()):
#         if "" in main_entry["Province"][province]:
#             del main_entry["Province"][province][""]

#     # Add the main entry to the list of transformed data
#     transformed_data.append(main_entry)

#     return transformed_data


##########################################################################
### An alternate way
##########################################################################

def move_total_to_top(d):
    """Ensure 'Total' key is placed at the top of the given dictionary, if it exists and is not None."""
    if 'Total' in d and d['Total'] is not None:
        # Get the 'Total' key-value pair
        total_value = d.pop('Total')
        # Rebuild the dictionary with 'Total' as the first entry
        return {'Total': total_value, **d}
    elif 'Total' in d:
        # Remove 'Total' if it is None
        d.pop('Total')
    return d

def replace_unicode_with_dash(d):
    """Recursively replace \u2013 (en-dash) with a regular dash in dictionary keys and values."""
    new_dict = {}
    for key, value in d.items():
        # Replace \u2013 in the key
        new_key = key.replace("\u2013", "-") if isinstance(key, str) else key
        
        if isinstance(value, dict):
            # Recursively process nested dictionaries
            new_dict[new_key] = replace_unicode_with_dash(value)
        elif isinstance(value, str):
            # Replace \u2013 with dash in string values
            new_dict[new_key] = value.replace("\u2013", "-")
        else:
            # For non-string values, just copy as is
            new_dict[new_key] = value

    return new_dict

def remove_empty_sections(d):
    """Recursively remove sections from the dictionary if all values are None or empty."""
    clean_dict = {}
    for key, value in d.items():
        if isinstance(value, dict):
            # Recursively clean nested dictionaries
            cleaned_value = remove_empty_sections(value)
            if cleaned_value:  # Add only non-empty dictionaries
                clean_dict[key] = cleaned_value
        elif value is not None:
            # Add non-null values
            clean_dict[key] = value
    return clean_dict

def convert_json(input_json):
    # Initialize an empty list to hold the transformed data
    transformed_data = []

    # Extract headers and data rows from the input JSON
    headers = input_json['dataframe']['headers']
    data_rows = input_json['dataframe']['data']

    # Get the index positions for each relevant column
    province_idx = headers.index('province')
    lookup_group_idx = headers.index('lookup_group')
    background_characteristics_idx = headers.index('Background characteristics')
    value_idx = headers.index('value')
    indicator_idx = headers.index('indicator')
    indicatorid_idx = headers.index('indicator_id')

    # Create a dictionary for the first item in the list
    main_entry = {
        "indicator_id": None,
        "indicator": None,
        "National": {
            "Total": None  # Add a place to store National total value
        },
        "Province": {}
    }
    
    # Set indicator name and ID
    if data_rows:
        main_entry["indicator"] = data_rows[0][indicator_idx]
        main_entry["indicator_id"] = data_rows[0][indicatorid_idx]
    
    # Iterate through each row in the data
    for row in data_rows:
        province = row[province_idx]
        lookup_group = row[lookup_group_idx]
        background_characteristic = row[background_characteristics_idx]
        value = row[value_idx]

        if province == "National":
            # Initialize the lookup group in the National section if not present
            if lookup_group:
                if lookup_group not in main_entry["National"]:
                    main_entry["National"][lookup_group] = {}
                main_entry["National"][lookup_group][background_characteristic] = value
            else:
                main_entry["National"]["Total"] = value  # Set the National total

        else:
            # Initialize the province if it does not exist
            if province not in main_entry["Province"]:
                main_entry["Province"][province] = {"Total": None}

            # If it's a new lookup group for this province, initialize it
            if lookup_group:
                if lookup_group not in main_entry["Province"][province]:
                    main_entry["Province"][province][lookup_group] = {}
                main_entry["Province"][province][lookup_group][background_characteristic] = value
            else:
                main_entry["Province"][province]["Total"] = value  # Set the province total

    # Move 'Total' to the top in the "National" section
    if "National" in main_entry:
        main_entry["National"] = move_total_to_top(main_entry["National"])

    # Move 'Total' to the top for each province in the "Province" section
    for province in main_entry["Province"]:
        main_entry["Province"][province] = move_total_to_top(main_entry["Province"][province])

    # Remove empty sections (no numerical data) from the "National" and "Province" sections
    main_entry["National"] = remove_empty_sections(main_entry["National"])
    main_entry["Province"] = remove_empty_sections(main_entry["Province"])

    # Remove "Province" key if it's empty
    if not main_entry["Province"]:
        main_entry.pop("Province")

    # Remove "National" key if it's empty
    if not main_entry["National"]:
        main_entry.pop("National")

    # Replace any \u2013 with regular dashes in the entire structure
    main_entry = replace_unicode_with_dash(main_entry)

    # Add the main entry to the list of transformed data
    transformed_data.append(main_entry)

    return transformed_data

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# Load pre-trained Sentence-BERT model
model = SentenceTransformer('all-MiniLM-L6-v2')

def get_embedding(text):
    # Generate embedding for the input text
    return model.encode(text, convert_to_numpy=True).reshape(1, -1)

def compute_similarity(embedding1, embedding2):
    # Compute cosine similarity between two embeddings
    return cosine_similarity(embedding1, embedding2)[0][0]

import difflib

def extract_first_sentence(text):
    """Extract the first sentence from the given text."""
    end_punctuation = ('.')
    for punct in end_punctuation:
        if punct in text:
            return text.split(punct, 1)[0] + punct
    return text  # Return the whole text if no sentence-ending punctuation is found

def is_partial_match(response, phrases, threshold=0.7):
    """Check if the first sentence of the response partially matches any of the phrases."""
    first_sentence = extract_first_sentence(response)
    
    for phrase in phrases:
        matcher = difflib.SequenceMatcher(None, phrase.lower(), first_sentence.lower())
        match_ratio = matcher.ratio()
        print("Match ratio:", match_ratio)
        if match_ratio >= threshold:
            return True
    return False

# List of phrases to match
phrases_to_check = [
    "The query is unclear.",
    "The query is not related to any indicator."
]


class QueryRequest(BaseModel):
    query: str
   

# Define a route to handle query requests
@app.post("/execute_query")
async def execute_query(query_request: QueryRequest):
    r_data = query_request.dict()
    try:
        query_text = r_data['query']
        original_query = query_text
        
        ### Step 1: Evaluate if the query makes sense ###
        while True:
            # Define the evaluation query
            evaluation_query = f"""
            You are an expert assessment guru, known for your sharp judgment and insightful analysis. 
            First, evaluate whether the query is clear, logical, and well-structured. If it contains minor spelling or grammatical errors, provide a corrected version and reply with: 
            "The query is unclear and cannot be processed, but perhaps what you're asking is: [corrected query]."
            If the query is flawless and makes sense, simply reply: "The query is crystal clear."
            Maintain a concise and authoritative tone. Do not include any other details in your response.
            Question: {query_text}
            Answer:
            """
    
            # Use LLM to evaluate the query
            try:
                eval_result = ollama.chat(
                    model='llama3.1:8b-instruct-fp16',
                    messages=[{"role": 'user', 'content': evaluation_query}],
                    options={'temperature': 0, "num_ctx": 32768},
                    stream=False
                )                
                # eval_result = ollama.chat(
                #     model='qwen2.5:32b',
                #     messages=[{"role": 'user', 'content': evaluation_query}],
                #     options={'temperature': 0, "num_ctx": 32768},
                #     stream=False
                # )
            except Exception as e:
                # Handle any exceptions that occur during the API call
                return {
                    "query": query_text,
                    "sql_query": None,
                    "dataframe": [],
                    "response": f"An error occurred: {str(e)}"
                }
    
            # Check the evaluation result
            response_content = eval_result['message']['content'].strip()
            if "crystal clear" in response_content.lower():
                # Query is clear, exit the loop
                break
            
        
            elif "unclear" in response_content.lower():
                # Extract the corrected query from the response
                if "perhaps what you're asking is:" in response_content.lower():
                    start_index = response_content.lower().find("perhaps what you're asking is:") + len("perhaps what you're asking is:")
                    corrected_query = response_content[start_index:].strip()
                    query_text = corrected_query
                else:
                    # Handle cases where the expected format is not met
                    return {
                        "query": query_text,
                        "sql_query": None,
                        "dataframe": [],
                        "response": "The query is unclear, but the suggested correction format was not found."
                    }
            else:
                # Handle unexpected responses
                return {
                    "query": query_text,
                    "sql_query": None,
                    "dataframe": [],
                    "response": "Unexpected response from evaluation service."
                }
            
            
            
            
        ### Step 2: Check if the query contains an indicator ###
        indicator_query = f"""
    You are an expert in matching queries with health and demographic indicators from the Nepal Demographic and Health Survey (NDHS). Your task is to:
    
    1. Analyze the user's query to find a semantic match with any indicator from the provided list.
    
    2. If a match is found:
        - **Indicator**: Identify and return the name of the matched indicator in the format: `Indicator: [Matched Indicator Name]`.
    
    3. If no exact match is found but there is a semantically similar indicator:
        - **Suggested Indicator**: Suggest the name of the most relevant indicator in the format: `Suggested Indicator: [Suggested Indicator Name]`.
        - **Modified Query**: Provide a modified version of the user’s query with the suggested indicator to improve the match.
        - Provide a brief explanation for the suggestion.
    
    4. If no match or similar indicator is found:
        - Respond with: "There is no indicator mentioned in the query that is related to the Nepal Demographic and Health Survey report. Please try again."
    
    ### Context:
    The Nepal Demographic and Health Survey (NDHS) provides key insights into health and demographic indicators across Nepal. It focuses on areas like child health, maternal health, nutrition, and other health-related factors across various provinces.
    
    ### List of Indicators:
    - "Women age 15-49 who have experienced physical violence since age 15 (%)"
    - "Current use of a modern method of family planning (%)"
    - "Median age at first birth women age 25-49 (years)"
    - "Women age 15-49 who have experienced violence by a husband or intimate partner in the last 12 months (%)"
    - "Unmet need for family planning"
    - "Total Fertility Rate (number of children per woman)"
    - "Children who are fully vaccinated against all basic antigens (%)"
    - "Children who are fully vaccinated according to the national schedule (%)"
    - "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)"
    - "Women age 15-49 who achieved minimum dietary diversity (%)"
    - "Household population with access to at least basic drinking water service (%)"
    - "Household population with access to at least basic sanitation service (%)"
    - "Women age 15-49 who use a bank account or used a mobile phone for financial transactions in the last 12 months (%)"
    - "Men age 15-49 who use a bank account or used a mobile phone for financial transactions in the last 12 months (%)"
    - "Married women age 15-49 who participate in household decisions (%)"
    - "Neonatal mortality"
    - "Infant mortality"
    - "Under-five mortality"
    - "Antenatal care (ANC) from a skilled provider"
    - "Births delivered in a health facility (%)"
    - "Births assisted by a skilled provider (%)"
    - "Women age 15-49 who have heard of COVID-19 (%)"
    - "Men age 15-49 who have heard of COVID-19 (%)"
    - "Women age 15-19 who have ever been pregnant (%)"
    - "Children under age five who are stunted (%)"
    - "Children under age five who are wasted (%)"
    - "Children under age five who are underweight (%)"
    - "Women age 15 and above with hypertension (%)"
    - "Women age 15+ with disability in at least one domain (%)"
    - "Men age 15+ with disability in at least one domain (%)"
    - "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)"
    - "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)"
    - "Women age 15-49 with symptoms of depression according to international cutoffs (%)"
    - "Men age 15-49 with symptoms of depression according to international cutoffs (%)"
    - "Current use of any method of family planning (%)"
    - "Demand satisfied by modern methods of family planning (%)"
    - "Men age 15 and above with hypertension (%)"
    
    ### Question: {query_text}
    
    ### Output Format:
    - If a match is found:
        - Indicator: [Matched Indicator Name]
    - If no exact match is found:
        - Suggested Indicator: [Suggested Indicator Name]
        - Modified Query: [Modified version of the query with the suggested indicator]
        - Explanation: [Brief reason for suggesting the indicator]
    - If no match or suggestion:
        - "There is no indicator mentioned in the query that is related to the Nepal Demographic and Health Survey report. Please try again."
    
    ### Answer:
"""






        # indicator_result = ollama.chat(
        #     model='qwen2.5:32b',
        #     messages=[{"role": 'user', 'content': indicator_query}],
        #     options={'temperature': 0.2,"num_ctx": 32768},
        #     stream=False
        # )

        
        # Use LLM to check for an indicator
        indicator_result = ollama.chat(
            model='llama3.1:8b-instruct-fp16',
            messages=[{"role": 'user', 'content': indicator_query}],
            options={'temperature': 0.2,"num_ctx": 32768},
            stream=False
        )
        print("Indicator Result",indicator_result['message']['content'])
        
        # Extract the first sentence from the response
        response_content = indicator_result['message']['content']
        first_sentence_match = re.match(r'[^.!?]*[.!?]', response_content)
        first_sentence = first_sentence_match.group(0).strip() if first_sentence_match else ""
        
        # Check if "no" is in the first sentence
        if "no" in first_sentence.lower():
            # Build the result_json dictionary
            result_json = {
                "query": query_text,
                "sql_query": None,
                "dataframe": [],
                "response": str(indicator_result['message']['content'])
            }
            return result_json
            
       ### Now NER Model Started ###
       ### First, find the indicator
        best_match_score = -1  # Start with -1 as cosine similarity ranges from -1 to 1
        best_indicator = None
        best_matching_phrase = None
        
        query_embedding = get_embedding(query_text)
        
        for indicator, phrases in indicators.items():
            for phrase in phrases:
                phrase_embedding = get_embedding(phrase)
                match_score = compute_similarity(query_embedding, phrase_embedding)
                
                if match_score > best_match_score:
                    best_match_score = match_score
                    best_indicator = indicator
                    best_matching_phrase = phrase
        
        matched_indicators = [best_indicator]
        print(f"Best matching indicator: {best_indicator} with score {best_match_score}")
        print(f"Best matching phrase: {best_matching_phrase}")

        

        user_query_tokens = word_tokenize(query_text.lower())
        phrase_tokens = set(word_tokenize(best_matching_phrase.lower()))
        # Remove tokens from the user query if they match (or are similar to) tokens in the best matching phrase
        filtered_query_tokens = [token for token in user_query_tokens if not is_similar(token, phrase_tokens)]
    
        # Reconstruct the user query without the best matching phrase (including handling minor misspellings)
        modified_query = ' '.join(filtered_query_tokens)

        user_query_tokens = word_tokenize(modified_query.lower())
        phrase_tokens = set(word_tokenize(matched_indicators[0].lower()))
        # Remove tokens from the user query if they match (or are similar to) tokens in the best matching phrase
        filtered_query_tokens = [token for token in user_query_tokens if not is_similar(token, phrase_tokens)]
    
        # Reconstruct the user query without the best matching phrase (including handling minor misspellings)
        modified_query = ' '.join(filtered_query_tokens)

       
        
        
        
        # Find matched provinces
        matched_provinces, modified_query = find_and_remove_matched_provinces(modified_query, province_list)

        
      
        
       
        lookup_with_groups = getLookupWithGroups(matched_indicators[0])
        
        
        # Initialize variables to track the best match
        best_match_score = 0
        best_lookup_group = None
        best_matching_phrase = None
        
        # Iterate through lookup groups defined in lookup_with_groups
        for lookup_group in lookup_with_groups:
            if lookup_group in Lookup_groups:
                phrases = Lookup_groups[lookup_group]
                for phrase in phrases:
                    # Compute match score using fuzz.token_set_ratio
                    match_score = fuzz.token_set_ratio(modified_query, phrase)
                    if match_score > best_match_score:
                        best_match_score = match_score
                        best_lookup_group = lookup_group
                        best_matching_phrase = phrase
        
        # Output the best match if score is greater than 90
        if best_match_score > 80:
           
            matched_lookup_groups = [best_lookup_group]
        else:
            print("No matching group found with score > 90")
            matched_lookup_groups = []
                
        
        print("Matched Lookup Groups:")
        for group in matched_lookup_groups:
            print(group)
        matched_lookups = []
        print("\nMatched Lookups:")
        for lookup in matched_lookups:
            print(lookup)
            
        
        # Create a dictionary with the specified keys and lists as values
        matched_entities = {
            'indicators': matched_indicators,
            'provinces': matched_provinces,
            'lookup_groups': matched_lookup_groups,
            'lookups': matched_lookups
        }


        # Extract values from the dictionary
        indicator_names = matched_entities.get('indicators', [])
        province_names = matched_entities.get('provinces', [])
        lookup_group_names = matched_entities.get('lookup_groups', [])
        lookup_names = matched_entities.get('lookups', [])


       

        
        
        # Construct SQL conditions with handling for empty lists
        indicator_condition = f"getindicator(id.indicator_id) IN ({format_for_sql(indicator_names)})" if indicator_names else "1=1"
        province_condition = f"getprovince(id.province_id) IN ({format_for_sql(province_names)})" if province_names else "1=1"
        lookup_group_condition = f"getlookupgroup(id.lookup_group_id) IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
        lookup_condition = f"getlookup(id.lookup_group_id, id.lookup_id) IN ({format_for_sql(lookup_names)})" if lookup_names else "1=1"

       
        sql_query = f"""
            WITH filtered_data AS (
                SELECT 
                    id.*
                FROM 
                    indicators_data id
                WHERE 
                    {indicator_condition} AND
                    ({province_condition}) AND
                    ({lookup_group_condition}) 
            )
            SELECT 
                id.indicator_id AS Indicator_ID,
                getindicator(id.indicator_id) AS Indicator,
                getindicatortype(id.indicator_id) AS Type,
                getprovince(id.province_id) as Province,
                COALESCE(getlookupgroup(id.lookup_group_id), '') AS Lookup_Group,
                COALESCE(getlookup(id.lookup_group_id, id.lookup_id), '') AS "Background characteristics",
                id.indicator_data AS Value,
                getindicatordefinition(id.indicator_id) AS Definition,
                getindicatorkeywords(id.indicator_id) AS Keywords,
                getindicatorsample(id.indicator_id) AS Sample,
                getindicatorsamplesummary(id.indicator_id) AS Summary,
                getindicatorbackgroundcharacteristicssummary(id.indicator_id) AS Background,
                getsurveysource(id.survey_source_id) AS Survey_Source,
                id.year AS Year
            FROM 
                filtered_data id
            ORDER BY 
                id.indicator_id,
                id.province_id,
                id.lookup_group_id,
                id.lookup_id;
    """

        
        
        
        print(sql_query)

        generated_sql_query = sql_query


       # Attempt to connect using psycopg2
        try:
            connection = psycopg2.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                dbname=db_name,
                cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
            )
            print("Connected using psycopg2")
            
            # Create a cursor object
            cursor = connection.cursor()
            
            # Execute a SQL query
            cursor.execute(generated_sql_query)
            
            # Fetch all rows from the executed query
            records = cursor.fetchall()
            # Get the column names
            column_names = [desc[0] for desc in cursor.description]
            
            # Convert the records to a DataFrame
            result_df = pd.DataFrame(records, columns=column_names)
        
            # # Execute your SQL query
            # result_df = pd.read_sql_query(generated_sql_query, connection)
            connection.close()
            print("Query executed successfully with psycopg2")
            
        
        except Exception as e:
            print(f"psycopg2 connection failed: {e}")
        
            # Fall back to SQLAlchemy
            try:
                # Create SQLAlchemy engine
                engine = create_engine(f'postgresql://{db_user}:{db_password}@{db_host}/{db_name}')
                print("Connected using SQLAlchemy")
        
                # Suppress specific pandas warning
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", message="pandas only supports SQLAlchemy connectable")
                    result_df = pd.read_sql_query(generated_sql_query, engine)
        
                print("Query executed successfully with SQLAlchemy")
                
        
            except Exception as e:
                print(f"SQLAlchemy connection also failed: {e}")

       
        
       
        
        # Display the DataFrame to check headers
        # pd.set_option('display.max_columns', None)
        # pd.set_option('max_colwidth', None)
        # print(result_df['province'])
        
       
       

        
        
        # Check if the DataFrame is empty
        if result_df.empty:
            print("The DataFrame is empty. No conversion performed.")
            output_json = {"message": "The DataFrame is empty. No data to process."}
        else:
            # Create input JSON
            input_json = {
                "dataframe": {
                    "headers": list(result_df.columns),
                    "data": result_df.values.tolist()
                }
            }
            
            # Convert the JSON
            output_json = convert_json(input_json)
            
            print("Output JSON", output_json)
        
        # # Display the DataFrame to check headers
        # pd.set_option('display.max_columns', None)
        # pd.set_option('max_colwidth', None)
        # # print(result_df['province'])
        # print("Result df",result_df.head(2))
        # # Pretty-print the JSON data
        # pretty_json = json.dumps(output_json, indent=4, sort_keys=False)
        # print(pretty_json)
        
        # print(pretty_json)
        
        
        description = """The **Nepal Demographic and Health Survey (NDHS)** is a comprehensive national health survey designed to gather essential data on various health and demographic indicators. It covers topics such as maternal health, family planning, child health, and nutrition, providing data from different provinces, regions, and demographic groups to assess health outcomes and track progress. The NDHS is critical for informing health policies and planning targeted interventions in Nepal. 
        Data is collected through interviews and surveys, primarily focused on women of reproductive age, their children, and households. The main objective is to provide national estimates on fertility, family planning, maternal health, and child mortality rates, as well as other health-related behaviors and outcomes.
        The dataset includes the following columns:
        - **indicator_id**: A unique numeric identifier assigned to each health indicator, helping distinguish between various indicators.
        - **indicator**: The name of the health indicator being measured (e.g., "Maternal Mortality" or "Contraceptive Use"), specifying the health issue addressed.
        - **type**: The format of the data (e.g., "percent," "count," "rate"), guiding interpretation of values.
        - **province**: Geographic area where data was collected, enabling regional health analysis.
        - **lookup_group**: Broad demographic categories (e.g., age, education) used for grouping and comparing subpopulations.
        - **Background characteristics**: Subcategories within lookup_group, providing detailed demographic information (e.g., age range, education level).
        - **value**: The measured value for each indicator, such as percentage or count, representing the magnitude of health issues within specific demographics.
        - **definition**: Detailed explanation of the health indicator, ensuring clear understanding of what is measured.
        - **keywords**: Key terms summarizing health topics (e.g., "family planning," "maternal health"), facilitating dataset search and categorization.
        - **sample**: The population surveyed, such as "All women age 15-49," clarifying the focus and representativeness of the data. 

        """
       
        
       
            

        

        narration_query = f""" You are a professional and expert data analyst with strong experience in evaluating queries and providing detailed, logical insights. 
    Your responses are always concise, comprehensive, and well-organized. 
    When providing feedback or corrections, you are polite and constructive, ensuring that the user understands any issues in a helpful manner. 
    You value clarity and precision, and aim to deliver coherent explanations or corrections with minimal unnecessary details.
        Based on the 2022 Nepal Demographic and Health Survey (NDHS), analyze the query and generate a detailed narrative explaining the relevant insights.
    
        Ensure that the response is concise, focused yet comprehensive, well-coherent, and clearly and cleanly addresses the question provided with convincing style.
        Answer the question as truthfully as possible and preferably using the provided Json, and if the Json is empty, say "I don't know"
        Description: {description}
        Json: {output_json}
        
        Question: {query_text}
        
        Answer:
        """
        


           
        result = ollama.chat(
            model='llama3.1:8b-instruct-fp16',
            messages=[{"role": 'user', 'content': narration_query}],
            options={'temperature': 0.2,"num_ctx": 32768,"max_tokens": 32768},
            stream=False)

        # result = ollama.chat(
        #     model='qwen2.5:32b', 
        #     messages=[{"role": 'user', 'content': narration_query}],
        #     options={'temperature': 0.2,"num_ctx": 32768,"max_tokens": 32768},
        #     stream=False)
        
        response = result['message']['content']
        
        # messages = [
        # ChatMessage(role="user", content=query),
        # ]
        # response = str(llm.chat(messages))
        
     

            # messages = [
            # ChatMessage(role="user", content=query),
            # ]
            # response = str(llm.chat(messages))+"Please try again." # Append "Please try again" to the response
          
        
       
         
        # Build the result_json dictionary
        result_json = {
            "query": original_query,
            "sql_query": generated_sql_query,
            "dataframe": output_json,
            "response": str(response)
        }

        
        
        # Return the result as JSON
        return result_json

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=4000)

