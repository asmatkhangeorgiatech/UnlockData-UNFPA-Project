import json
from mfunctions import *

province_list = getProvinceList()
print("\n\n\nProvince List: \n",province_list,"\n\n")

STOP_WORDS = set(getStopWords())
print("Stop words: \n",STOP_WORDS,"\n\n")

indicator_list = getIndicatorList()
print("Indicators List: \n",indicator_list,"\n\n")

# lookup_with_groups = getLookupWithGroups()
# print("Lookup and Groups: \n", lookup_with_groups, "\n\n")

lookup_with_groups_indicator = getLookupWithGroupsOfIndicator("Married women age 15-49 who participate in household decisions (%)")
print("Lookup and Groups for TRF: \n", lookup_with_groups_indicator, "\n\n")

lookup_with_groups = getLookupWithGroups("Married women age 15-49 who participate in household decisions (%)")
print("Lookup and Groups for TRF: \n", lookup_with_groups, "\n\n")