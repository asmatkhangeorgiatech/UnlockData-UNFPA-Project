

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 17:26:18 2024
We need to make an SQl agent that works primarity with open source models as llm
and have prompts and examples and history if possible.

This is the lastest one for the demo.

@author: asmat
"""
from dotenv import load_dotenv
import os

load_dotenv()  # Load environment variables from .env file

api_key = os.getenv("OPENAI_API_KEY")

import os
os.environ["OPENAI_API_KEY"] = api_key

from langchain_openai import ChatOpenAI
#llm_codestral = ChatOpenAI(model="gpt-4-1106-preview")


# First we need to database
from langchain_community.utilities import SQLDatabase




import pymysql
import pandas as pd
from sqlalchemy import create_engine
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
from langchain import LLMChain
from langchain_community.utilities.sql_database import SQLDatabase

# Initialize the language model
llm_codestral = ChatOllama(model="codestral", temperature=0, host="http://localhost:11434")



#from langchain_community.agent_toolkits import create_sql_agent



from langchain.chains import LLMChain
#from langchain.prompts import render_template
from flask import Flask, request, jsonify, render_template
from langchain.agents import ZeroShotAgent, AgentExecutor
#from langchain.agents.agent_toolkits import SQLDatabaseToolkit
#from langchain.agents.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit


#from langchain.tools.sql import InfoSqlTool, ListTablesSqlTool, QueryCheckerTool, QuerySqlTool
from langchain_core.language_models.base import BaseLanguageModel


SQL_PREFIX = """You are an agent designed to interact with a SQL database.
Given an input question, create a syntactically correct {dialect} query based on schema {schema} to run, then look at the results of the query and return the answer.
Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most {top_k} results using the LIMIT clause.
You can order the results by a relevant column to return the most interesting examples in the database.
Never query for all the columns from a specific table, only ask for the few relevant columns given the question.
You have access to tools for interacting with the database.
Only use the below tools.
Only use the information returned by the below tools to construct your final answer.
You MUST double check your query before executing it. If you get an error while executing a query, rewrite the query and try again.

DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database.



If the question does not seem related to the database, just return "I don't know" as the answer."""
SQL_SUFFIX = """Begin!

Question: {input}
Thought: I should look at the tables in the database to see what I can query.
{agent_scratchpad}"""

# Initialize the database object
# Create the SQLDatabase instance from the URI


# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name


sql_db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20
)
toolkit = SQLDatabaseToolkit(db=sql_db, llm=llm_codestral)

def create_sql_agent(llm: BaseLanguageModel, toolkit: SQLDatabaseToolkit, args: dict = None):
    if args is None:
        args = {}
    prefix = args.get("prefix", SQL_PREFIX)
    suffix = args.get("suffix", SQL_SUFFIX)
    input_variables = args.get("inputVariables", ["input", "agent_scratchpad"])
    top_k = args.get("topK", 10)
    
    formatted_prefix = f"{prefix.format(dialect=toolkit.dialect, top_k=top_k,schema =sql_db.get_table_info())}"
    
    tools = toolkit.get_tools()
    prompt = ZeroShotAgent.create_prompt(
            tools,
            prefix=formatted_prefix,
            suffix=suffix,
            input_variables=input_variables,
        )
    # prompt = ZeroShotAgent.create_prompt(toolkit.get_tools(), {
    #     "prefix": formatted_prefix,
    #     "suffix": suffix,
    #     "inputVariables": input_variables,
    # })
    
    chain = LLMChain(prompt=prompt, llm=llm)
    agent = ZeroShotAgent(
        llm_chain=chain,
        allowed_tools=[tool.name for tool in toolkit.get_tools()]
    )
    
    return AgentExecutor.from_agent_and_tools(
        agent=agent,
        tools=toolkit.get_tools(),
        return_intermediate_steps=True,
        verbose=True,
        handle_parsing_errors=True
    )

# Example usage
# from langchain.llms import HuggingFaceEndpoint

# llm = HuggingFaceEndpoint(
#     huggingfacehub_api_token="your_api_key_here",
#     repo_id="mistralai/Mixtral-8x7B-Instruct-v0.1",
#     temperature=0.8,
#     max_length=150
# )





print(sql_db.dialect)
print(sql_db.get_usable_table_names())

#sql_db = SqlDatabase(/* your database config */)

# executor = create_sql_agent(llm_codestral, toolkit, { "topK": 5 })

# result = executor.invoke({
#     "input": "How many women in rural areas are using any method of family planning??",
# })

# print(f"Got output {result.output}")


from langchain.chains import create_sql_query_chain

chain = create_sql_query_chain(llm_codestral, sql_db)
response = chain.invoke({"question": "How many women in rural areas are using any method of family planning?"})
response