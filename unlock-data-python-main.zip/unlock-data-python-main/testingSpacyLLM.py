
from spacy_llm.util import assemble
import torch




# Ensure the model and components are using CPU
if torch.cuda.is_available():
    print("GPU detected but using CPU.")
else:
    print("Using CPU.")

nlp = assemble("config.cfg")
doc = nlp("what is unmet need of family planning comparing urban and rural areas at national level")
print([(ent.text, ent.label_) for ent in doc.ents])