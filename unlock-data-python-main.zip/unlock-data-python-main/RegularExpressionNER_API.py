#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 18:40:59 2024

This is the final API for NEPAL UFPA PRoject, the latest one

@author: asmat
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 11:19:51 2024

HEre we are using RegularExpression for matching.

@author: asmat
"""

import re
import nltk
from nltk.corpus import wordnet 
from difflib import SequenceMatcher
from langchain_community.utilities.sql_database import SQLDatabase
import psycopg2
from psycopg2.extras import DictCursor
import pandas as pd
# nltk.download('punkt') as it is already installed 
# nltk.download('wordnet') if once installed comment it 
from langchain.output_parsers import ResponseSchema, StructuredOutputParser
import json

## This is another Asmat Attempt
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from fastapi.middleware.cors import CORSMiddleware

from sentence_transformers import SentenceTransformer, util

from llama_index.experimental.query_engine import PandasQueryEngine
from llama_index.llms.ollama import Ollama
from langchain_community.chat_models import ChatOllama

from sqlalchemy import create_engine
import warnings

# To print all the list, i.e. Indicator list, province list and lookup group with lookup list
from mfunctions import getProvinceList, getStopWords, getIndicatorList, getLookupWithGroups, getLookupWithGroupsOfIndicator
from mfunctions import are_similar




# Initialize the language model
#llm = Ollama(model="codestral", temperature=0, host="http://localhost:11434")
llm = Ollama(model="yarn-mistral:7b-128k-fp16", temperature=0, host="http://localhost:11434")
#llm = ChatOllama(model="codestral", temperature=0, host="http://localhost:11434")
#llm = Ollama(model="mistral:7b-instruct-fp16", temperature=0, host="http://localhost:11434")

#########################################################
##### First do matching for indicator ###################
#########################################################
    




# indicator_list = [
#         "Total Fertility Rate (number of children per woman)",
#         "Median age at first birth women age 25-49 (years)",
#         "Women age 15-19 who have ever been pregnant",
#         "Current use of any method of family planning",
#         "Current use of a modern method of family planning",
#         "Demand satisfied by modern methods of family planning",
#         "Unmet need for family planning",
#         "Neonatal mortality",
#         "Infant mortality",
#         "Under-five mortality",
#         "Antenatal care (ANC) from a skilled provider",
#         "Births delivered in a health facility",
#         "Births assisted by a skilled provider",
#         "Children who are fully vaccinated against all basic antigens",
#         "Children who are fully vaccinated according to the national schedule",
#         "Children under age five who are stunted",
#         "Children under age five who are wasted",
#         "Children under age five who are underweight",
#         "Children age 6-23 months living with their mother fed a minimum acceptable diet",
#         "Women age 15-49 who achieved minimum dietary diversity",
#         "Household population with access to at least basic drinking water service",
#         "Household population with access to at least basic sanitation service",
#         "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months",
#         "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months",
#         "Married women age 15-49 who participate in household decisions",
#         "Women age 15-49 who have experienced physical violence since age 15",
#         "Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months",
#         "Women age 15-49 who have heard of COVID-19",
#         "Men age 15-49 who have heard of COVID-19",
#         "Women age 15 and above with hypertension",
#         "Men age 15 and above with hypertension",
#         "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability",
#         "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability",
#         "Women age 15-49 with symptoms of anxiety according to international cutoffs",
#         "Men age 15-49 with symptoms of anxiety according to international cutoffs",
#         "Women age 15-49 with symptoms of depression according to international cutoffs",
#         "Men age 15-49 with symptoms of depression according to international cutoffs"
# ]

indicators_with_percentage_list = getIndicatorList()
# Create a new list with percentage signs removed
indicator_list = [indicator.replace('(%)', '').strip() for indicator in indicators_with_percentage_list]



#print("Indicators List: \n",indicator_list,"\n\n")
# indicators_with_percentage_list = [
#         "Total Fertility Rate (number of children per woman)",
#         "Median age at first birth women age 25-49 (years)",
#         "Women age 15-19 who have ever been pregnant (%)",
#         "Current use of any method of family planning (%)",
#         "Current use of a modern method of family planning (%)",
#         "Demand satisfied by modern methods of family planning (%)",
#         "Unmet need for family planning",
#         "Neonatal mortality",
#         "Infant mortality",
#         "Under-five mortality",
#         "Antenatal care (ANC) from a skilled provider",
#         "Births delivered in a health facility (%)",
#         "Births assisted by a skilled provider (%)",
#         "Children who are fully vaccinated against all basic antigens (%)",
#         "Children who are fully vaccinated according to the national schedule (%)",
#         "Children under age five who are stunted (%)",
#         "Children under age five who are wasted (%)",
#         "Children under age five who are underweight (%)",
#         "Children age 6-23 months living with their mother fed a minimum acceptable diet (%)",
#         "Women age 15-49 who achieved minimum dietary diversity (%)",
#         "Household population with access to at least basic drinking water service (%)",
#         "Household population with access to at least basic sanitation service (%)",
#         "Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
#         "Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)",
#         "Married women age 15-49 who participate in household decisions (%)",
#         "Women age 15-49 who have experienced physical violence since age 15 (%)",
#         "Women age 15-49 who have ever had a husband or intimate partner who has experienced violence by any husband/intimate partner in the last 12 months (%)",
#         "Women age 15-49 who have heard of COVID-19 (%)",
#         "Men age 15-49 who have heard of COVID-19 (%)",
#         "Women age 15 and above with hypertension (%)",
#         "Men age 15 and above with hypertension (%)",
#         "Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
#         "Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)",
#         "Women age 15-49 with symptoms of anxiety according to international cutoffs (%)",
#         "Men age 15-49 with symptoms of anxiety according to international cutoffs (%)",
#         "Women age 15-49 with symptoms of depression according to international cutoffs (%)",
#         "Men age 15-49 with symptoms of depression according to international cutoffs (%)"
   
    
#     ]


def custom_tokenize(text):
    # Regular expression to match words, numbers, and special numeric patterns
    token_pattern = r'\b(?:\d+\+|\d+-\d+|\d+|\w+)\b'
    return re.findall(token_pattern, text)




from fuzzywuzzy import fuzz

STOP_WORDS = set(getStopWords())
# # Define stop words
# STOP_WORDS = set([
#     'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
#     'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
#     'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'is', 'are', 'was',
#     'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and',
#     'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
#     'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on',
#     'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
#     'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
#     'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
# ])





### This method is finding indicator using  sentence transformer
from sentence_transformers import SentenceTransformer, util
from sklearn.metrics.pairwise import cosine_similarity
import nltk
from nltk.corpus import wordnet

# Load the sentence transformer model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Function to calculate cosine similarity using sentence transformers
def calculate_cosine_similarity(vector1, vector2):
    return cosine_similarity([vector1], [vector2])[0][0]



nltk.download('wordnet')

from nltk.corpus import wordnet

def get_synonyms(word):
    """
    Find synonyms of a given word using WordNet.

    Args:
    - word (str): The word to find synonyms for.

    Returns:
    - set: A set of synonyms for the given word.
    """
    synonyms = []

    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.append(lemma.name())

    return set(synonyms)





import textdistance
import nltk
from nltk.corpus import wordnet





# Function to remove matched parts from the query, accounting for synonyms and misspellings
def remove_matched_parts(query, indicator, similarity_threshold=0.8):
    # Tokenize the query
    query_tokens = query.lower().split()
   
    # Tokenize the matched indicator
    indicator_tokens = set(indicator.lower().split())
    
    # Get synonyms for each token in the indicator
    indicator_synonyms = set()
    for token in indicator_tokens:
        indicator_synonyms.update(get_synonyms(token))
    indicator_tokens.update(indicator_synonyms)
    
    # Remove matched tokens or their synonyms (or similar words) from the query
    filtered_tokens = []
    for token in query_tokens:
        if not any(are_similar(token, ind_token, similarity_threshold) for ind_token in indicator_tokens):
            filtered_tokens.append(token)
    
    query_tokens = filtered_tokens
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return modified_query.strip()




# Function to process query and indicators using sentence transformers
def process_query_with_transformer(query, indicators, similarity_threshold=0.3):
    # Convert query and indicators into vectors using the sentence transformer
    query_vec = model.encode(query)
    indicator_vectors = model.encode(indicators)

    highest_similarity = similarity_threshold
    percentage_indicators_index = -1
    for i, indicator in enumerate(indicators):
        sim = util.pytorch_cos_sim(query_vec, indicator_vectors[i]).item()
        if sim > highest_similarity:
            highest_similarity = sim
            percentage_indicators_index=i
            
    
    # # Pick elements from the indicators list using the indices
    # matched_indicators = [indicators_with_percentage_list[i] for i in percentage_indicators_index]
    matched_indicators = indicators_with_percentage_list[percentage_indicators_index]
    # Remove matched indicator phrases from the query using tokens and synonyms
    modified_query = remove_matched_parts(query, matched_indicators)
    
    

    return matched_indicators, modified_query



# Function to remove stop words from a text
def remove_stop_words(text):
    tokens = text.lower().split()  # Tokenize and convert to lowercase
    filtered_tokens = [word for word in tokens if word not in STOP_WORDS]  # Filter out stop words
    return " ".join(filtered_tokens)






################################################################
##### Now we do matching for the provinces #####################
################################################################
import textdistance

province_list = getProvinceList()
# province_list = [
#     "National",
#     "Bagmati",
#     "Gandaki",
#     "Karnali",
#     "Koshi",
#     "Lumbini",
#     "Madhesh",
#     "Sudurpashchim"
# ]



# Function to find and remove matched provinces from the query
def find_and_remove_matched_provinces(query, province_list, similarity_threshold=0.8):
    query_tokens = query.lower().split()
    matched_provinces = []
    
    for province in province_list:
        province_tokens = province.lower().split()
        
        for token in query_tokens:
            if any(are_similar(token, province_token, similarity_threshold) for province_token in province_tokens):
                matched_provinces.append(province)
                
                # Remove all tokens related to the matched province from the query
                query_tokens = [t for t in query_tokens if not any(are_similar(t, province_token, similarity_threshold) for province_token in province_tokens)]
                break  # Move to the next province once a match is found
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return matched_provinces, modified_query.strip()




#########################################################################
##### Let us smatch for lookup groups only. ##############################
#########################################################################
# Define your lookup groups as a nested JSON
lookup_groups = getLookupWithGroups()
lookup_groups_list = [item['group'] for item in lookup_groups]

# Function to find and remove matched provinces from the query
def find_and_remove_matched_lookup_groups(query, lookup_groups_list, similarity_threshold=0.8):
    query_tokens = query.lower().split()
    matched_lookup_groups = []
    
    for lookup_group in lookup_groups_list:
        lookup_group_tokens = lookup_group.lower().split()
        
        for token in query_tokens:
            if any(are_similar(token, lookup_group_token, similarity_threshold) for lookup_group_token in lookup_group_tokens):
                matched_lookup_groups.append(lookup_group)
                
                # Remove all tokens related to the matched province from the query
                query_tokens = [t for t in query_tokens if not any(are_similar(t, lookup_group_token, similarity_threshold) for lookup_group_token in lookup_group_tokens)]
                break  # Move to the next province once a match is found
    
    # Reconstruct the modified query from the remaining tokens
    modified_query = " ".join(query_tokens)
    return matched_lookup_groups, modified_query.strip()

############################################################################
################# Let us match lookup group based on lookup ################
############################################################################
import json
from fuzzywuzzy import fuzz
from fuzzywuzzy import fuzz
from nltk.corpus import wordnet
import nltk
from fuzzywuzzy import fuzz
from nltk.corpus import wordnet
from nltk.corpus import stopwords
import nltk
import string

nltk.download('stopwords')
# Ensure NLTK resources are downloaded
nltk.download('wordnet')


def normalize_text(text):
    """Normalize text by converting to lowercase, stripping punctuation, and removing stop words."""
    
    
    # Convert to lowercase
    text = text.lower()
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    
    words = text.split()
    filtered_words = [word for word in words if word not in STOP_WORDS]
    return ' '.join(filtered_words)

def get_synonyms(word):
    """Retrieve synonyms for a given word."""
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name())
    return synonyms


def find_best_match(token, lookups):
    """Find the best match for a token from a list of lookups using fuzzy matching and synonyms."""
    token_normalized = normalize_text(token)
    
    # Create an extended token list with synonyms
    extended_tokens = set([token_normalized])
    extended_tokens.update(get_synonyms(token_normalized))
    
    best_match = None
    highest_ratio = 0
    
    for lookup in lookups:
        for extended_token in extended_tokens:
            ratio = fuzz.ratio(extended_token, lookup)
            if ratio > highest_ratio:
                highest_ratio = ratio
                best_match = lookup

    return best_match if highest_ratio > 70 else None

def find_matched_groups_and_lookups(text, lookup_groups):
    """Find and return matched lookup groups and lookups based on fuzzy matching and synonyms."""
    
    # Tokenize and normalize text
    filtered_tokens = custom_tokenize(text)
    
    filtered_tokens = [token for token in filtered_tokens if token.lower() not in STOP_WORDS]
    
    matched_lookup_groups = set()
    matched_lookups = set()

    for group in lookup_groups:
        group_name = group['group']
        lookups = [lookup for lookup in group.get('lookup', [])]
        print("lookups", group_name,lookups)

        for token in filtered_tokens:
            # Check for the best match for the token
            matched_lookup = find_best_match(token, lookups)
            if matched_lookup:
                matched_lookups.add(matched_lookup)
                matched_lookup_groups.add(group_name)
                #break  # No need to check further tokens once a match is found

    return list(matched_lookup_groups), list(matched_lookups)

# Define your lookup groups as a nested JSON
# lookup_groups = getLookupWithGroups()


# lookup_groups_json = '''
# {
#   "lookup_groups": [
#     {
#       "group": "Ecological zone",
#       "lookups": [
#         "Mountain",
#         "Hill",
#         "Terai"
#       ]
#     },
#     {
#       "group": "Residence",
#       "lookups": [
#         "Urban",
#         "Rural"
#       ]
#     },
#     {
#       "group": "Wealth Quintile",
#       "lookups": [
#         "Lowest",
#         "Second",
#         "Middle",
#         "Fourth",
#         "Highest"
#       ]
#     },
#     {
#       "group": "Age",
#       "lookups": [
#         "<5",
#         "5-9",
#         "10-14",
#         "15-19",
#         "20–24",
#         "25–29",
#         "30–34",
#         "35–39",
#         "40–44",
#         "45–49",
#         "50–54",
#         "55–59",
#         "60–64",
#         "65–69",
#         "70–74",
#         "75–79",
#         "80+"
#       ]
#     },
#     {
#       "group": "Education",
#       "lookups": [
#         "No education",
#         "Basic education (1-8)",
#         "Secondary Education (9-12)",
#         "More than secondary (13 and above)"
#       ]
#     },
#     {
#       "group": "Ethnic Group",
#       "lookups": [
#         "Brahmin/Chhetri",
#         "Dalit",
#         "Janajati",
#         "Madhesi",
#         "Muslim"
#       ]
#     },
#     {
#       "group": "Mothers Education",
#       "lookups": [
#         "No education",
#         "Basic education",
#         "Secondary education",
#         "More than secondary"
#       ]
#     },
#     {
#       "group": "Child Sex",
#       "lookups": [
#         "Male",
#         "Female"
#       ]
#     },
#     {
#       "group": "Mother's Age",
#       "lookups": [
#         "<20",
#         "20-34",
#         "35-49"
#       ]
#     },
#     {
#       "group": "Birth Order",
#       "lookups": [
#         "1",
#         "2-3",
#         "4-5",
#         "6+"
#       ]
#     },
#     {
#       "group": "Antenatal Care Visits",
#       "lookups": [
#         "None",
#         "1-3",
#         "4+"
#       ]
#     },
#     {
#       "group": "Sex",
#       "lookups": [
#         "Male",
#         "Female"
#       ]
#     },
#     {
#       "group": "Seen",
#       "lookups": [
#         "Seen",
#         "Not seen or no longer has"
#       ]
#     },
#     {
#       "group": "Age Group",
#       "lookups": [
#         "15-49",
#         "20-29",
#         "30-39",
#         "40-49"
#       ]
#     },
#     {
#       "group": "Age in Month",
#       "lookups": [
#         "<6",
#         "6-11",
#         "6-8",
#         "9-11",
#         "12-23",
#         "12-18",
#         "18-23",
#         "24-35",
#         "36-47",
#         "48-59"
#       ]
#     },
#     {
#       "group": "Birth Interval in Months",
#       "lookups": [
#         "<24",
#         "24-47",
#         "48+"
#       ]
#     },
#     {
#       "group": "Size at Birth",
#       "lookups": [
#         "Very small",
#         "Small",
#         "Average or larger"
#       ]
#     },
#     {
#       "group": "Mother's Nutritional Status",
#       "lookups": [
#         "Thin",
#         "Normal",
#         "Overweight/Obese"
#       ]
#     },
#     {
#       "group": "Maternity Status",
#       "lookups": [
#         "Pregnant",
#         "Not pregnant"
#       ]
#     },
#     {
#       "group": "Employment (Last 12 Months)",
#       "lookups": [
#         "Not employed",
#         "Employed for cash",
#         "Employed not for cash"
#       ]
#     },
#     {
#       "group": "Number of Living Children",
#       "lookups": [
#         "0",
#         "1-2",
#         "3-4",
#         "5+"
#       ]
#     },
#     {
#       "group": "Marital Status",
#       "lookups": [
#         "Never married",
#         "Never had intimate partner",
#         "Ever had intimate partner",
#         "Ever married",
#         "Married/living together",
#         "Divorced/separated/widowed",
#         "Divorced",
#         "Widowed"
#       ]
#     },
#     {
#       "group": "Nutritional Status",
#       "lookups": [
#         "Thin",
#         "Normal",
#         "Overweight",
#         "Obese",
#         "Not weighed or measured"
#       ]
#     }
#   ]
# }
# '''


# # Accessing 'lookup_groups' directly from the dictionary
# lookup_groups = json.loads(lookup_groups_json)['lookup_groups']





######################### NER job finished.####################################

def format_for_sql(names_list):
    if names_list:
        return ', '.join(f"'{name}'" for name in names_list)
    return ''  # Return an empty string if the list is empty

# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name

db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20)
    
    
    




###################### Let us start API business now #####################
##########################################################################
app = FastAPI()

# Allow all origins (useful for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Let us say I create a panda frame agent
# Import necessary packages
#langchain_experimental.agents.create_pandas_dataframe_agent
from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain.agents.agent_types import AgentType
from langchain.agents import AgentExecutor
import ollama



def convert_json(input_json):
    # Initialize an empty list to hold the transformed data
    transformed_data = []

    # Extract headers and data rows from the input JSON
    headers = input_json['dataframe']['headers']
    data_rows = input_json['dataframe']['data']

    # Get the index positions for each relevant column
    province_idx = headers.index('province')
    lookup_group_idx = headers.index('lookup_group')
    background_characteristics_idx = headers.index('Background characteristics')
    value_idx = headers.index('value')
    indicator_idx = headers.index('indicator')
    indicatorid_idx = headers.index('indicator_id')

    # Create a dictionary for the first item in the list
    main_entry = {
        "indicator_id": None,
        "indicator": None,
        "National": {},
        "Province": {}
    }
    
    # Set indicator name and ID
    if data_rows:
        main_entry["indicator"] = data_rows[0][indicator_idx]
        main_entry["indicator_id"] = data_rows[0][indicatorid_idx]
    
    # Iterate through each row in the data
    for row in data_rows:
        province = row[province_idx]
        lookup_group = row[lookup_group_idx]
        background_characteristic = row[background_characteristics_idx]
        value = row[value_idx]

        if province == "National":
            # Initialize the lookup group in the National section if not present
            if lookup_group:
                if lookup_group not in main_entry["National"]:
                    main_entry["National"][lookup_group] = {}
                main_entry["National"][lookup_group][background_characteristic] = value
            else:
                main_entry["National"]["Total"] = value

        else:
            # Initialize the province if it does not exist
            if province not in main_entry["Province"]:
                main_entry["Province"][province] = {"Total": None}

            # If it's a new lookup group for this province, initialize it
            if lookup_group:
                if lookup_group not in main_entry["Province"][province]:
                    main_entry["Province"][province][lookup_group] = {}
                main_entry["Province"][province][lookup_group][background_characteristic] = value
            else:
                main_entry["Province"][province]["Total"] = value

    # Remove empty keys in both National and Province sections
    if "National" in main_entry:
        if "" in main_entry["National"]:
            del main_entry["National"][""]

    for province in list(main_entry["Province"].keys()):
        if "" in main_entry["Province"][province]:
            del main_entry["Province"][province][""]

    # Add the main entry to the list of transformed data
    transformed_data.append(main_entry)

    return transformed_data






class QueryRequest(BaseModel):
    query: str

# Define a route to handle query requests
@app.post("/execute_query")
async def execute_query(query_request: QueryRequest):
    r_data = query_request.dict()
    try:
        
        # Original query from request
        query_text = r_data['query']
        
       

        matched_indicators, modified_query = process_query_with_transformer(query_text, indicator_list)

        modified_query = remove_stop_words(modified_query)
        print("Modified Query:", modified_query)

        print("Matched Indicators:",matched_indicators)
        
        
        
        # Find matched provinces
        matched_provinces, modified_query = find_and_remove_matched_provinces(modified_query, province_list)

        
        print("After province Modified Query:", modified_query)
        # Output matched provinces
        print("Matched Provinces:", matched_provinces)
        
        # # Output matched provinces or default to "National" if none are matched
        # if not matched_provinces:
        #     matched_provinces = ["National"] # Default to National if no provinces are matched
        print("After Matched Provinces:", matched_provinces)

        # Now we get two sets of lookups, one from indicator anem and other from query
        # matched = getLookupWithGroupsOfIndicator(matched_indicators)
        # print("matched",matched)
        # Find matched lookup groups and lookups
        # #matched_lookup_groups, matched_lookups = find_matched_groups_and_lookups(modified_query, lookup_groups)
        # matched_lookup_groups, matched_lookups = find_and_remove_matched_lookup_groups(modified_query, lookup_groups_list, similarity_threshold=0.8)

        # Assuming the two functions return the same structure for matched_lookup_groups
        matched_lookup_groups1, removed_query = find_and_remove_matched_lookup_groups(modified_query, lookup_groups_list, similarity_threshold=0.8)
        matched_lookup_groups2, matched_lookups2 = find_matched_groups_and_lookups(modified_query, lookup_groups)
        
        # Union of both matched_lookup_groups lists
        matched_lookup_groups = matched_lookup_groups1 + matched_lookup_groups2

        # Output matched lookup groups and lookups
        print("Matched Lookup Groups:")
        for group in matched_lookup_groups:
            print(group)
        matched_lookups = []
        print("\nMatched Lookups:")
        for lookup in matched_lookups:
            print(lookup)
            
        
        # Create a dictionary with the specified keys and lists as values
        matched_entities = {
            'indicators': matched_indicators,
            'provinces': matched_provinces,
            'lookup_groups': matched_lookup_groups,
            'lookups': matched_lookups
        }


        # Extract values from the dictionary
        indicator_names = matched_entities.get('indicators', [])
        province_names = matched_entities.get('provinces', [])
        lookup_group_names = matched_entities.get('lookup_groups', [])
        lookup_names = matched_entities.get('lookups', [])


        # Construct SQL conditions with handling for empty lists
        indicator_condition = f"i.indicator = '{indicator_names}'" if indicator_names else "1=1"
        province_condition = f"p.province IN ({format_for_sql(province_names)})" if province_names else "1=1"
        lookup_group_condition = f"lg.lookup_group IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
        lookup_condition = f"l.lookup IN ({format_for_sql(lookup_names)}) AND lg.lookup_group_id = l.lookup_group_id" if lookup_names else "1=1"

        #Construct the final SQL query using f-strings
        # sql_query = f"""
        # WITH filtered_data AS (
        #     SELECT 
        #         id.* 
        #     FROM 
        #         indicators_data id
        #     LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
        #     LEFT JOIN provinces p ON id.province_id = p.province_id
        #     LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
        #     LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
        #     WHERE 
        #         {indicator_condition} AND
        #         ({province_condition}) AND
        #         ({lookup_group_condition}) 
                
        # )
        # SELECT 
        #         i.indicator_id AS Indicator_ID,
        #         i.indicator AS Indicator,
        #         COALESCE(p.province, 'National') AS Province,
        #         COALESCE(lg.lookup_group, '') AS Lookup_Group,
        #         COALESCE(l.lookup, '') AS Lookup,
        #         id.indicator_data AS Value,
        #         i.indicator_type AS Type,
        #         i.indicator_definition AS Definition,
        #         i.keywords AS Keywords,
        #         i.indicator_sample AS Sample,
        #         i.sample_summary as Summary,
        #         i.background_characteristics_summary AS Background,
        #         id.survey_source_id AS Survey_Source_ID,
        #         id.year AS Year                      
        # FROM 
        #     filtered_data id
        # LEFT JOIN indicators i ON id.indicator_id = i.indicator_id
        # LEFT JOIN provinces p ON id.province_id = p.province_id
        # LEFT JOIN lookup_groups lg ON id.lookup_group_id = lg.lookup_group_id
        # LEFT JOIN lookups l ON id.lookup_id = l.lookup_id AND lg.lookup_group_id = l.lookup_group_id
        # ORDER BY 
        #     i.indicator,
        #     p.province,
        #     lg.lookup_group,
        #     l.lookup;
        # """
        
        # Construct SQL conditions with handling for empty lists
        indicator_condition = f"getindicator(id.indicator_id) = '{indicator_names}'" if indicator_names else "1=1"
        province_condition = f"getprovince(id.province_id) IN ({format_for_sql(province_names)})" if province_names else "1=1"
        lookup_group_condition = f"getlookupgroup(id.lookup_group_id) IN ({format_for_sql(lookup_group_names)})" if lookup_group_names else "1=1"
        lookup_condition = f"getlookup(id.lookup_group_id, id.lookup_id) IN ({format_for_sql(lookup_names)})" if lookup_names else "1=1"

       
        sql_query = f"""
            WITH filtered_data AS (
                SELECT 
                    id.*
                FROM 
                    indicators_data id
                WHERE 
                    {indicator_condition} AND
                    ({province_condition}) AND
                    ({lookup_group_condition}) 
            )
            SELECT 
                id.indicator_id AS Indicator_ID,
                getindicator(id.indicator_id) AS Indicator,
                getindicatortype(id.indicator_id) AS Type,
                getprovince(id.province_id) as Province,
                COALESCE(getlookupgroup(id.lookup_group_id), '') AS Lookup_Group,
                COALESCE(getlookup(id.lookup_group_id, id.lookup_id), '') AS "Background characteristics",
                id.indicator_data AS Value,
                getindicatordefinition(id.indicator_id) AS Definition,
                getindicatorkeywords(id.indicator_id) AS Keywords,
                getindicatorsample(id.indicator_id) AS Sample,
                getindicatorsamplesummary(id.indicator_id) AS Summary,
                getindicatorbackgroundcharacteristicssummary(id.indicator_id) AS Background,
                getsurveysource(id.survey_source_id) AS Survey_Source,
                id.year AS Year
            FROM 
                filtered_data id
            ORDER BY 
                getindicator(id.indicator_id),
                CASE 
                    WHEN id.province_id IS NOT NULL THEN getprovince(id.province_id)
                    ELSE 'National'
                END,
                COALESCE(getlookupgroup(id.lookup_group_id), ''),
                COALESCE(getlookup(id.lookup_group_id, id.lookup_id), '');
        """

        
        
        
        print(sql_query)

        generated_sql_query = sql_query


       # Attempt to connect using psycopg2
        try:
            connection = psycopg2.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                dbname=db_name,
                cursor_factory=DictCursor  # Use DictCursor to get results as dictionaries
            )
            print("Connected using psycopg2")
            
            # Create a cursor object
            cursor = connection.cursor()
            
            # Execute a SQL query
            cursor.execute(generated_sql_query)
            
            # Fetch all rows from the executed query
            records = cursor.fetchall()
            # Get the column names
            column_names = [desc[0] for desc in cursor.description]
            
            # Convert the records to a DataFrame
            result_df = pd.DataFrame(records, columns=column_names)
        
            # # Execute your SQL query
            # result_df = pd.read_sql_query(generated_sql_query, connection)
            connection.close()
            print("Query executed successfully with psycopg2")
            
        
        except Exception as e:
            print(f"psycopg2 connection failed: {e}")
        
            # Fall back to SQLAlchemy
            try:
                # Create SQLAlchemy engine
                engine = create_engine(f'postgresql://{db_user}:{db_password}@{db_host}/{db_name}')
                print("Connected using SQLAlchemy")
        
                # Suppress specific pandas warning
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", message="pandas only supports SQLAlchemy connectable")
                    result_df = pd.read_sql_query(generated_sql_query, engine)
        
                print("Query executed successfully with SQLAlchemy")
                
        
            except Exception as e:
                print(f"SQLAlchemy connection also failed: {e}")

       
        
       
        
        # Display the DataFrame to check headers
        # pd.set_option('display.max_columns', None)
        # pd.set_option('max_colwidth', None)
        # print(result_df['province'])
        
       
       
        
        
        # Adding context directly to the query_text
        context = (
            "Context: The Nepal Demographic and Health Survey (NDHS) provides "
            "comprehensive insights into various health and demographic indicators across Nepal's provinces. "
            "This particular survey focuses on indicators such as child health, maternal health, nutrition, and more. "
            "Using the provided data, the following query is aimed at retrieving information about specific indicators "
            "related to the demographic and health-related dimensions within Nepal. "
        )
        
        print('I am after context')

        
        
        # I have input json and would like to convert it
        input_json = {
            "dataframe": {
                "headers": list(result_df.columns),
                "data": result_df.values.tolist()
            }
        }
        
        # Convert the JSON
        #print("Input json", input_json)
        output_json = convert_json(input_json)
        
        print("Output Jason",output_json)
        # Pretty-print the JSON data
        pretty_json = json.dumps(output_json, indent=4, sort_keys=True)
        
        print(pretty_json)
        
        
        example1_json = [
            {
                "indicator_id": 26,
                "indicator": "Women age 15-49 who have experienced physical violence since age 15 (%)",
                "National": {
                    "Total": None
                },
                "Province": {
                    "Lumbini": {
                        "Total": 23.4,
                        "Residence": {
                            "Rural": 27.5,
                            "Urban": 20.5
                        }
                    }
                }
            }
        ]
        
        example2_json = [
            {
                "indicator_id": 26,
                "indicator": "Women age 15-49 who have experienced physical violence since age 15 (%)",
                "National": {
                    "Total": None,
                    "Education": {
                        "Basic education (1-8)": 26.3,
                        "More than secondary (13 and above)": 4.3,
                        "No education": 35.5,
                        "Secondary (9-12)": 12.4
                    }
                },
                "Province": {}
            }
        ]
        
        example3_json = [
            {
                "indicator_id": 26,
                "indicator": "Women age 15-49 who have experienced physical violence since age 15 (%)",
                "National": {
                    "Total": 22.5,
                    "Ecological zone": {
                        "Hill": 16.2,
                        "Mountain": 15.6,
                        "Terai": 27.6
                    },
                    "Education": {
                        "Basic education (1-8)": 26.3,
                        "More than secondary (13 and above)": 4.3,
                        "No education": 35.5,
                        "Secondary (9-12)": 12.4
                    },
                    "Ethnic group": {
                        "Brahmin/Chhetri": 14.3,
                        "Dalit": 30.3,
                        "Janajati": 18.4,
                        "Madhesi": 33.3,
                        "Muslim": 42.3
                    },
                    "Marital status": {
                        "Divorced/separated/widowed": 47.3,
                        "Ever had intimate partner": 9.0,
                        "Ever married": 27.0,
                        "Married/living together": 26.0,
                        "Never had intimate partner": 6.1,
                        "Never married": 6.6
                    },
                    "Residence": {
                        "Rural": 23.7,
                        "Urban": 21.9
                    },
                    "Wealth quintile": {
                        "Fourth": 23.1,
                        "Highest": 12.5,
                        "Lowest": 23.8,
                        "Middle": 25.4,
                        "Second": 28.0
                    }
                },
                "Province": {}
            }
        ]
        
        # query = f"""
        # **Objective:**  
        # You are an AI language model specializing in data analysis. You have access to a pandas dataframe containing rich, structured data relevant to the task at hand. Your goal is to analyze the data, generate detailed answers to input queries, and provide clear, cohesive explanations with meaningful insights. All facts, figures, and observations must be strictly derived from the provided dataframe.
        
        # **Task Instructions:**
        
        # 1. **Analyze the Data:**
        #    - Thoroughly examine the dataframe, focusing on all relevant fields including `Background Characteristics`, `Sample`, `Indicator Type`, `Summary`, `Background Characteristics Summary`, and `Survey Source`.
        
        
        # 2. **Evaluate and Compare:**
        #    - **Check JSON Sections:** Begin by checking the `Result JSON` section to identify which values are available.
        #    - **National vs. Provincial Comparison:**
        #      - **Compare Totals:** First, compare the total values for `National` and each province. Identify which has the highest and lowest values.
        #    - **Nested Analysis:**
        #      - **National Section Analysis:** 
        #        - After comparing totals, delve into the `National` section of the `Result JSON`. Compare values based on further bifurcations such as `Ecological zone`, `Residence`, `Education`, etc., if available.
        #      - **Provincial Sections Analysis:**
        #        - Similarly, analyze each province section. Compare values within each province based on further bifurcations, respecting the hierarchy in the `Result JSON`.
        #      - **Background Characteristics:** Discuss the results based on `Background Characteristics` as detailed in the dataframe. Analyze and compare within these characteristics rather than making general comparisons.
        #    - **If No Province or National Data Provided:** If the query does not specify province or national data:
        #      - **National Comparison:** Compare the indicator values first on the basis of the `National` data within all `Background Characteristics`.
        #      - **Province Comparison:** Next, compare the indicator values on the basis of each `Province` within its own `Background Characteristics`, if the values are available in the `Result JSON`.
        #    - **Classify the Output:** Classify the output value (e.g., indicator value) as low, medium, or high based on the available data.
        #    - **Discuss Factors:** Discuss factors influencing these values, particularly if they are low, and suggest improvements or actions.
        #    - **Provide Broader Insights:** Offer additional insights on how the indicator's value and dimensions may impact the broader context, such as social well-being, economic stability, or policy decisions.
        
        # 3. **Conclude with Insight:**
        #    - Provide a thoughtful conclusion that emphasizes the significance of the indicator within the larger context.
        #    - Highlight the importance of monitoring trends and making informed decisions based on this data.
        
        # 4. **Instructions for Using JSON Result:**
        #    - **Compare Totals:** Begin by comparing the total values across `National` and provinces to determine which has the highest and lowest values.
        #    - **Hierarchical Analysis:**
        #      - **National Section:** Analyze the `National` section by comparing values and discussing further levels of detail (e.g., `Ecological zone`, `Residence`, `Education`) if data is available.
        #      - **Provincial Sections:** Similarly, analyze each provincial section. Discuss values and further levels of detail based on the `Result JSON`, such as `Ecological zone`, `Residence`, etc.
        #      - **Respect Hierarchy:** Follow the hierarchical structure in the `Result JSON`. Stop at any level where data is not available, but delve deeper into available data respecting the hierarchy.
        #    - **Data Fields:** Use fields inside the JSON result, such as `Total`, `Residence`, `Ecological zone`, etc., to provide detailed comparisons and analyses.
        #    - **Narration:** Narrate insights based on the available data, making sure to compare relevant sections and fields as described in the JSON result. Avoid comparing values across sections or fields that are not directly related.
        #    - **Background Characteristics Summary:** Use the `Background Characteristics Summary` from the dataframe to provide a detailed analysis based on the specific characteristics listed.
        
        # **Input Data:**
        
        # - **Context:**  
        #   `{context}`
        
        # - **Dataframe:**  
        #   `{result_df}`
        
        # - **Results_Json:**  
        #   `{output_json}`
        
        # - **Query:**  
        #   `{query_text}`
        
        
        
        
        
        # ** Examples **
        # ### Example 1:
        #     Results_Json: 
        #         {example1_json}
                
           
        #     Response:
        #         The indicator 'Women age 15-49 who have experienced physical violence since age 15 (%)' does not have a reported national total, but specific data is available for the Lumbini Province.

        #         Within Lumbini Province, the overall percentage of women who have experienced physical violence since the age of 15 is 23.4%. This indicates a significant portion of the female population in this age group has been subjected to physical violence.
                
        #         The data further breaks down by residence, revealing that women in rural areas of Lumbini are more affected, with a reported rate of 27.5%. In contrast, women living in urban areas report a lower incidence of 20.5%. This contrast suggests that rural women in Lumbini are more vulnerable to physical violence compared to their urban counterparts.
                
        #         In summary, while national-level data is unavailable, the figures from Lumbini Province highlight the challenges faced by women in rural areas, where the prevalence of physical violence is notably higher than in urban settings. This underscores the need for focused interventions in rural areas to address and reduce the incidence of physical violence against women.
                
       
                        
        # ### Example 2:
        #     Results_Json: 
        #         {example2_json}               
        #     Response:
        #     The indicator "Women age 15-49 who have experienced physical violence since age 15 (%)" provides insight into the experiences of women across different educational backgrounds at the national level. However, the overall national rate is not provided in this dataset.

        #     Education levels reveal significant differences in the prevalence of physical violence. Women with no education report the highest incidence, with 35.5% having experienced physical violence since the age of 15. This is followed by women with Basic education (grades 1-8), who report a rate of 26.3%. Women with Secondary education (grades 9-12) experience a notably lower rate of 12.4%. The lowest rate is observed among women with More than secondary education (grade 13 and above), where only 4.3% have reported experiencing physical violence.
            
        #     These figures highlight a clear correlation between higher educational attainment and reduced rates of physical violence. Women with no or minimal education appear to be significantly more vulnerable to physical violence, while those with higher education levels experience a much lower incidence. This pattern underscores the protective role that education can play in reducing the likelihood of physical violence against women.
            
        #     The dataset does not provide information on the provincial distribution of these experiences, limiting the analysis to the educational dimension.
         

        


                   
        # **Output**
        # Provide a comprehensive and clear response based on the data available in Result_Json, dataframe in the context. dont try to make up data from your own resources.
        # Response:
        # """
        
        
        query = f"""
            <context>
            {context}
            </context>
       
            <objective>
            You are an AI language model specializing in explaining the data. You have access to a pandas dataframe containing rich, structured data relevant to the task at hand and also directly the values in Result.
            
            Identify and explain the most important data points from the dataframe and the Result that are directly related to the query based on the context. Break down complex concepts into simple terms, and provide clear explanations of how these data points answer the query. Offer context and examples where needed to enhance understanding.
            </objective>
        
            <organization>
                Structure the output in a way that is easy to follow: begin with a simple introduction of the  context. Then explain the query for easy comprehension with help of context. Present the findings in a logical order, using headings or sections like "Context","Query Explained","Main Insights," "Simple Comparisons," and "Trends and Patterns",and "Final Thoughts".
            </organization>
        
            <style>
                Use plain language and avoid technical jargon. If technical terms are necessary, ensure they are explained in a way that is easy to understand. Use visuals, such as bullet points, simple charts, or diagrams, to help convey the information clearly.
            </style>
        
            <tone>
                Maintain a friendly, informative, and approachable but professional tone. The goal is to educate and inform without overwhelming the audience. Be encouraging and positive, making the analysis feel accessible to everyone.
            </tone>
        
            <audience>
                The audience is the general public, including individuals who may have little to no background in survey reports. The response should be inclusive, ensuring that anyone, regardless of their knowledge level, can understand and appreciate the insights provided.
            </audience>
        
            <relevance>
                Focus on the aspects of the data that are most relevant and interesting to a general audience. Ensure that the output is practical, engaging, and directly related to the query, providing clear and actionable takeaways.
            </relevance>
        
            <examples>
                <example>
                    Query: "How many women age 15-49 who have experienced physical violence since age 15 in Lumbani?"
                    Response: " The indicator 'Women age 15-49 who have experienced physical violence since age 15 (%)' does not have a reported national total, but specific data is available for the Lumbini Province. Within Lumbini Province, the overall percentage of women who have experienced physical violence since the age of 15 is 23.4%. This indicates a significant portion of the female population in this age group has been subjected to physical violence. The data further breaks down by residence, revealing that women in rural areas of Lumbini are more affected, with a reported rate of 27.5%. In contrast, women living in urban areas report a lower incidence of 20.5%. This contrast suggests that rural women in Lumbini are more vulnerable to physical violence compared to their urban counterparts. In summary, while national-level data is unavailable, the figures from Lumbini Province highlight the challenges faced by women in rural areas, where the prevalence of physical violence is notably higher than in urban settings. This underscores the need for focused interventions in rural areas to address and reduce the incidence of physical violence against women."
                </example>
                <example>
                    Query: "What are the most popular products sold last month?"
                    Response: "Last month, the most popular products were smartphones and laptops, accounting for 40% of all sales. Smartphones, in particular, saw a 20% increase in sales compared to the previous month, likely due to the launch of new models. For example, the XYZ smartphone was the best-seller, with 5,000 units sold."
                </example>
                <example>
                    Query: "How does the average income in different regions compare?"
                    Response: "The average income varies significantly across regions. In the northern region, the average income is $50,000, while in the southern region, it is $35,000. This difference could be attributed to the higher concentration of industries in the north. For instance, the tech sector in the north pays significantly higher salaries compared to the agricultural sector predominant in the south."
                </example>
            </examples>
            
            <input>
            The input is a natural language query, dataframe, Result and context containing relevant data that needs to be analyzed to answer the natural language query.
            Query:
                {query_text}
            Dataframe:
                {result_df}
            Result:
                {output_json}
                
            </input>

            <output>
                Generate a clear and easily understandable answer to the natural language query by analyzing the provided dataframe. The output should include key insights, simple comparisons, and any significant trends or patterns observed in the data. The explanation should be straightforward and accessible to the general public.
                Response:
            </output>
            
            """

        
        result = ollama.chat(
            model='codestral', 
            messages=[{"role": 'user', 'content': query}],
            options={'temperature': 0},
            stream=False)
        
        response = result['message']['content']
        
        result_json = {
            "query": query_text,
            "sql_query": generated_sql_query,
            "dataframe": pretty_json,
            "response": str(response)
        } 
        
        
        # Return the result as JSON
        return result_json

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=4000)
