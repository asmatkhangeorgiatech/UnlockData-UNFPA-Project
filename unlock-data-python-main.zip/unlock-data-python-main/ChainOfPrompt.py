#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Wed Aug 21 16:25:20 2024

@author: asmat
"""
from pydantic import BaseModel
import pymysql
import pandas as pd
from sqlalchemy import create_engine
from langchain_community.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
from langchain import LLMChain
from langchain_community.utilities.sql_database import SQLDatabase


# Initialize the language model
llm_codestral = ChatOllama(model="codestral", temperature=0, host="http://localhost:11434")

# Database credentials
db_host = "localhost"
db_user = "ndhsuser"
db_password = "ndsh1234"
db_name = "ndhsdb"  # Replace this with the actual database name


# Initialize the database object
# Create the SQLDatabase instance from the URI
db = SQLDatabase.from_uri(
    f"postgresql+psycopg2://{db_user}:{db_password}@{db_host}/{db_name}",
    sample_rows_in_table_info=20
)

schema = db.get_table_info()


generation_template="""
You are an expert in Sql code generation. You task is to do first Named Entity Recognition to extract four entities and then based on the 
entities values we will pick an sql template, fill it appropraiately to generetae the required sql code. For this purpoe, use a step-by-step process.
1. First, clarify the query.
2. Second, based on calrified query, identify Indicator name, the Province name, the lookup_group name, and lookup name.
3. Third, select the sql template to fill.

# To clarify the question asked in a summarized manner:
Use the concepts below to get a clarified query statement.

Identify Key Details: Focus on the main elements of the query or question, such as the entities involved (e.g., tables, columns) and the specific conditions or filters.

Simplify Language: Use clear and concise language to explain the main goal or requirement. Avoid technical jargon if possible.

Specify Requirements: Clearly outline what is needed, including any specific conditions, filters, or desired outputs.

Provide Examples: Include a brief example if it helps illustrate the query or requirement more effectively.

#Identify four entities:
Based on the four lists, you can identify the matching indicator, province, lookyp_group, and lookup.

## List of Indicators:
Antenatal care (ANC) from a skilled provider
Births assisted by a skilled provider (%)
Births delivered in a health facility (%)
Children age 6-23 months living with their mother fed a minimum acceptable diet (%)
Children under age five who are stunted (%)
Children under age five who are underweight (%)
Children under age five who are wasted (%)
Children who are fully vaccinated according to the national schedule (%)
Children who are fully vaccinated against all basic antigens (%)
Current use of a modern method of family planning (%)
Current use of any method of family planning (%)
Demand satisfied by modern methods of family planning (%)
Household population with access to at least basic drinking water service (%)
Household population with access to at least basic sanitation service (%)
Infant mortality
Married women age 15-49 who participate in household decisions (%)
Median age at first birth women age 25-49 (years)
Men age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
Men age 15-49 who have heard of COVID-19 (%)
Men age 15-49 with hypertension (%)
Men age 15-49 with symptoms of anxiety according to international cutoffs (%)
Men age 15-49 with symptoms of depression according to international cutoffs (%)
Men age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)
Neonatal mortality
Total Fertility Rate (number of children per woman)
Under-five mortality
Unmet need for family planning
Women age 15-19 who have ever been pregnant (%)
Women age 15-49 who achieved minimum dietary diversity (%)
Women age 15-49 who have and use a bank account or used a mobile phone for financial transactions in the last 12 months (%)
Women age 15-49 who have ever had a husband or intimate partner who have experienced violence by any husband/intimate partner in the last 12 months (%)
Women age 15-49 who have experienced physical violence since age 15 (%)
Women age 15-49 who have heard of COVID-19 (%)
Women age 15-49 with hypertension (%)
Women age 15-49 with symptoms of anxiety according to international cutoffs (%)
Women age 15-49 with symptoms of depression according to international cutoffs (%)
Women age 15+ who have a lot of difficulty or cannot do at all in at least one domain of disability (%)

## list of Provinces:
Bagmati
Gandaki
Karnali
Koshi
Lumbini
Madhesh
Sudurpashchim
    
## List of Lookups:
Brahmin/Chhetri
Dalit
Janajati
Madhesi
Muslim
Urban
Rural
Mountain
Hill
Terai
No education
Basic education (1–8)
Secondary (9–12)
More than secondary (13 and above)
Lowest
Second
Middle
Fourth
Highest
<5
5–9
10–14
15–19
20–24
25–29
30–34
35–39
40–44
45–49
50–54
    
## List of Lookup Groups:
Ethnic group
Residence
Ecological zone
Education
Wealth quintile
5-Year Age Group
Mothers Education
Child Sex
Birth order
Mothers Age at birth
Antenatal care visits
Sex
Vaccination card


# Sql Template
```sql    
 SELECT
    indicator_id,
    getindicator(indicator_id) AS indicator,
    CASE
        WHEN province_id IS NULL THEN 'National'
        ELSE getprovince(province_id) || ' Province'
    END AS province,
    COALESCE(getlookupgroup(lookup_group_id), '') AS "Group",
    COALESCE(getlookup(lookup_group_id, lookup_id), '') AS "Group Type",
    indicator_data AS "Value"
FROM
    indicators_data
WHERE
    province_id IS NULL
    AND lookup_group_id IS NULL;
```
This query selects various fields from the indicators_data table, including calculated values for indicator, province, Group, and Group Type, while filtering rows where both province_id and lookup_group_id are NULL.
Modify this template to suit your needs.

## query:
    {query}
    Based on the text query above, adapt a step-by-step procedure to use the sql template provided to get the final sql query to fecth data to resolve the natural language query.

## Output:
"""  
query = 'What percentage of women are using traditional methods of family planning?'
 
generation_prompt_template = PromptTemplate(
    input_variables=["query"],
    template=generation_template
)

generation_chain = LLMChain(llm=llm_codestral, prompt=generation_prompt_template)

generation_query = generation_chain.run(query=query)
print(generation_query)


